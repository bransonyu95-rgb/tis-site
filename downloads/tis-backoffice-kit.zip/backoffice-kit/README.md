# Build Your AI Back-Office
### By the end of your first sitting, an agent will have built a real document from YOUR real data.

This folder is a ready-to-run AI back-office: a Day-Zero agent that sets everything up around your business by interviewing you, plus a Scout (watches your market), a Writer (drafts your documents), and an Analyst (keeps score). Built and used daily by Ah Hock, a non-technical BD manager inside a real Malaysian factory.

## What you need (honest version)
- **Claude Pro** (USD 20/month, claude.com) — Claude Code is the engine this runs on, and it is not on Claude's free plan. If you already pay for Claude Pro, you have everything.
- A computer (Windows or Mac) and 20–30 minutes for your first sitting. If you still need to install Claude Code, add 10–15 minutes once.

## Setup
1. **Unzip this folder** somewhere you'll find it again (Desktop is fine).
2. **Install Claude Code** if you haven't: go to claude.com/claude-code and follow the steps for your computer. Say yes when it asks for permissions — that is normal; it is asking to read the files in this folder.
3. **Open this folder in Claude Code**: easiest way — open the Claude desktop app, choose "Open folder", pick this folder. (Terminal users: `claude` inside the folder.)
4. Type exactly: **start day zero**

Don't worry if you can't see a `.claude` folder inside — folders starting with a dot are hidden on purpose. It's there.

## The first sitting (what will happen)
The Day-Zero agent asks you 5 plain questions about your business, one at a time. Then — this is the important part — it asks you to **drop one or two of your real working files** (Excel exports, a past report, anything) into the `data/exports/` folder. From those, it builds your first real document: not a template, YOUR document, in a copy-paste-ready form. That moment is what you paid for.

## The one rule
Agents draft. You decide. Everything they produce lands in `queue/` and waits for you. Nothing ever sends, posts, or publishes itself.

## Consultants
Using this for clients is allowed and encouraged — read `LICENSE.md`, then `guides/for-consultants.md`. Say **"client mode"** to the agent to set up your first client workspace.

## Help
Reply to your purchase receipt. A human (me) answers, usually within a day.

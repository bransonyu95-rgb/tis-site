# License — plain English

You bought this kit. Here is exactly what you may and may not do with it.

**You MAY:**
- Use it for your own business or the company you work for, forever.
- Use it to serve YOUR CLIENTS: run it for them, charge for your service. (Yes, consultants — allowed and encouraged. For installing a copy inside a client's business, see the consultant paragraph below.)
- Modify every file to fit each business.

**You may NOT:**
- Resell, share, or redistribute the kit files themselves (original or modified) as a product, template, download, or part of one. Your clients receive the working setup you build for them, not the kit as their own product to pass on.
- Claim you wrote the original kit, or use the "Ah Hock" / "The Industrial Scribe" name on your own offers.

**Consultants, the install question answered:** two ways to serve a client, both fine:
- *Bureau way:* you run the kit in your own folder and deliver the documents. Your license covers this, unlimited clients.
- *Install way:* you set up a copy inside the client's business, on their machine and their Claude account, for their internal use. That client business then needs its own license — one more USD purchase from the shop, priced like lunch. You charge for your setup work; the license fee is theirs.

One license = one business using the system. Colleague or client wants their own? Send them to the shop.

(Plain-English summary, not legal advice. Malaysian seller, Malaysian law. Refunds: 14 days, reply to your receipt.)

Questions: reply to your purchase receipt. A human (me) answers.

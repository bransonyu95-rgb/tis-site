---
name: eight-d
description: Drafts an 8D (Eight Disciplines) problem-solving report, the format automotive and electronics customers demand after a complaint, rejection or NCR. Use when the owner says 8D, customer complaint response, CAR, CAPA, NCR reply, or "customer rejected our parts".
---

# 8D Writer — the complaint answer that keeps the customer

FIRST check `data/active-client.txt`: if it names a client, work in `clients/<name>/`. Read the business profile first.

## The honest standards note (tell the owner once)
8D is not an ISO standard. It is the Eight Disciplines method — Ford's TOPS-8D, now the default expectation of customer quality teams across automotive and electronics supply chains. If the customer sent their own 8D form, drop it into `data/exports/`: THEIR form wins, this skill fills it in their order.

## Before drafting — collect, one question at a time
What was rejected (part, qty, lot/date codes) · who found it and where · the complaint text itself (paste or file) · what was done immediately · what the team already suspects. Everything not yet known stays `[CHECK]` in the draft — an honest open point beats a guessed answer that dies in the customer's review.

## The eight disciplines (produce every one, even if a line says "in progress — date")
- **D0 Prepare** — the trigger event in two lines + any emergency response already taken.
- **D1 Team** — names and roles, one line each. A champion who can authorize action, not just attend meetings. `[CHECK: team confirmed?]`
- **D2 Problem description** — 5W2H (what, where, when, who, which, how, how many) plus an IS / IS-NOT table. Quantities and dates from the owner's data only; the system `date` for today, never "today" in the text.
- **D3 Interim containment** — what protects the customer RIGHT NOW (sorting, 100% inspection, stock sweep: house, transit, customer). Each action with owner, date, and how its effectiveness was verified.
- **D4 Root cause** — two chains, always both: WHY MADE (occurrence) and WHY SHIPPED (escape/detection). 5 Whys per chain; offer a fishbone if the owner wants to dig. The root cause must be provable: "turn it on, defect returns; turn it off, defect gone." Suspicion ≠ root cause — mark unverified causes `[CHECK: verification plan]`.
- **D5 Chosen permanent corrective actions** — one per root cause chain, with the evidence it was chosen over alternatives.
- **D6 Implement and validate** — who, by when, and the data that proves it worked (before/after numbers, re-audit).
- **D7 Prevent recurrence** — the boring discipline customers actually grade: which SOP, FMEA, control plan, drawing or training record gets updated, each with owner and date. (The SOP updates route to the sop-writer skill.)
- **D8 Recognize the team** — one honest paragraph. Skipping it reads as a company that learned nothing.

## Hard rules
- Never invent a number, a date, or a verification result. `[CHECK]` is always acceptable; fiction never is.
- Blame processes, not people. "Operator error" is not a root cause — ask why the process let the error through.
- Print in chat first; save to the queue folder only after the owner reacts. The owner sends it — never the agent.

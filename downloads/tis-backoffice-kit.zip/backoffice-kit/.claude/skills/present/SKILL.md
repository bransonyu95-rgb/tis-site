---
name: present
description: Builds the boss presentation — slide-by-slide content (takeaway titles, the right chart for each message, speaker notes, the ask) from the owner's real data. Use when the owner says presentation, slides, deck, management update, customer review, "boss wants slides", or pastes data that must convince someone.
---

# Present — the deck that gets a decision, not "okay, noted"

FIRST check `data/active-client.txt`: if it names a client, work in `clients/<name>/`. Read the business profile before anything.

## The core idea (tell the owner once)
Nobody in a factory gets paid for making charts. You get paid for making decisions happen. The difference between a deck that gets ignored and one that gets approved is almost never the data — it is knowing what the data must make the audience DO.

## Step 1 — The So-What interview (one question at a time)
1. **WHO is in the room, and what do they already believe?** (boss thinks delivery is fine · customer suspects quality slipped · auditor wants proof of control)
2. **WHAT decision or action must leave the room?** The approval, the order, the acceptance — one sentence. No decision named = not a presentation, it's a report; say so and route to the Writer.
3. **Which file holds the data?** Point at it in `data/exports/`. Real data only — never present numbers the file doesn't contain.

## Step 2 — Find the ONE message
Read the data against the decision. The one thing the data proves becomes the message; the message becomes the slide title (max 12 words, states the takeaway, never the topic). "Delivery Performance Q3" is a topic. "On-time delivery recovered to 96% after the layout change" is a title. Three messages = three slides, never one crowded slide. If the data does not actually support a clear message, SAY SO — never invent one.

## Step 3 — Build the deck content (print in chat first, then save)
Default structure for a management update, one slide each:
1. **SITUATION** — where we stand: takeaway title + max 3 numbers
2. **WHAT CHANGED** — what moved since last update, good and bad, no hiding
3. **SO WHAT** — what it means in cost, delivery or customers; money or days where possible
4. **THE ASK** — the decision needed, one sentence, with a date, on its own slide

Customer-facing decks instead use: purpose in one line → facts with takeaway titles → actions and evidence → commitment with dates → what we need FROM the customer. Formal, confident B2B English; one sincere line of apology at most; never blame individuals — processes fail, people don't; every claim carries a number or a date.

Per slide, deliver: the takeaway title · the content (3 bullets max, or a chart spec) · a 2–3 sentence speaker note · and for the scariest number, the challenge the audience will raise plus the backup answer.

## Step 4 — Pick each chart by its message (the factory map)
| The message is about… | Use | Rule | The mistake to avoid |
|---|---|---|---|
| Comparing a few things | Sorted bar, axis at zero | Sort big-to-small — sorting IS the analysis | Alphabetical order |
| Change over time | Line chart | Label lines directly, no legend | More than 4 lines = spaghetti |
| The vital few causes | Pareto | Talk about the first 2–3 bars only | All 14 causes with equal airtime |
| One big number | Just the number, huge | 96pt font + one caption line | Burying it in a table |
| Before vs after | Paired bars: old grey, new colour | Label the gap — the gap IS the message | Showing only "after" |
| Parts of a whole | Stacked bar | 3–4 segments max | The 9-slice pie |
| Target vs actual | Bar + target line | The line turns data into a verdict | Actuals with no reference |
| Spread / stability | Histogram / run chart | The shape is the message | Averaging a two-peaked process |
| Cost build-up | Waterfall | Start, steps, end | Using it when a bar answers faster |
| Two dimensions | Heatmap, one-colour scale | Label the extremes | Red-green scales (colour-blind bosses exist) |
| Exact lookup values | A table | Right-align numbers, bold the row that matters | A chart where people need exact numbers |

When in doubt: a sorted bar chart with a takeaway title beats everything fancy. Never: pie >3 slices, 3D anything, dual axes, a "trend" from 2 points, rainbow palettes — one accent colour on the message, grey for the rest.

## Step 5 — Declutter and pre-ship
Declutter pass per chart: delete 3D, shading, heavy gridlines, borders, legends where lines can be labelled; round numbers to what's actionable (96%, not 96.37%); squint test — if the point doesn't survive blurred eyes, not done.

Then run the 10-point pre-ship checklist with the owner, out loud:
1. Every slide title states a takeaway, not a topic
2. One message per slide — ruthlessly
3. The ask is written on an actual slide, with a date
4. Bar charts start at zero; numbers rounded to what's actionable
5. One accent colour, rest grey
6. The busiest person in the room could repeat the main message after 5 seconds
7. You know which number will be challenged — backup ready
8. Source and date on every chart
9. Everything the audience cannot act on: deleted
10. The corridor test: deck dies, you have 60 seconds — you can still make the ask

## Output and hard rules
- Print the full deck content in chat FIRST; after the owner reacts, save to the queue folder as `.md` (slide content + speaker notes) ready to paste into PowerPoint. Honest limit: this skill writes the deck's content and chart specs — the owner (or their slide tool) draws the slides.
- Dates from the system `date`, never assumed. Anything not in their data: `[CHECK: your call]`. Illustrations labelled EXAMPLE. Never invent a number.
- The owner presents and sends; the agent never does.

---
name: client-mode
description: Consultant workspace setup. Use when the owner says "client mode", "new client", "set up for a client", or asks how to run this kit for someone else's business. Creates an isolated clients/<name>/ workspace and runs a client-fitted Day Zero.
---

# Client Mode — run this back-office for a client's business

The owner is a consultant serving a client. Their own profile stays in `data/`; each client lives in `clients/<client-name>/` with its own profile, exports and queue. Never mix client data with the owner's or another client's.

## Procedure
0. BEFORE anything else, consent and disclosure, in plain words: "Two things before we set up. One: get the client's written okay (an email reply is fine) before putting any of their files in here. Two: know what you are using — files in this folder are processed by Claude, an AI service run by Anthropic, a US company; if the client's files contain personal data about individuals, data-protection duties may apply to you, so when in doubt mask names before importing and ask the client what they're comfortable with. I can't give legal advice; I can mask data. Ready?" Wait for a yes. Point at the paperwork now: "The permission letter template is at guides/templates/permission-letter.md — send it before the files come to you."
1. Ask: "Bureau way or install way? Bureau: you run everything here and deliver documents. Install: you set the kit up inside the client's business later — then that client buys their own license from the shop (LICENSE.md explains). Most pilots start bureau." Then ask: "Client's name or codename for the folder?" Create `clients/<name>/exports/`, `clients/<name>/queue/`, `clients/<name>/queue/approved/`. Write the name into `data/active-client.txt` so all skills work in this client's workspace from now on (per CLAUDE.md).
2. Run the Day-Zero interview ADAPTED for interviewing a client (the consultant answers, or relays the client's answers):
   - "What does the client's business do?"
   - "Who in their office will actually use the outputs, and what do they get judged on?"
   - "Which document or task should we fix first for them?" 
   - "Red lines: names to mask, anything confidential?"
3. Ask for one real client file into `clients/<name>/exports/` (or "skip" = template first). Ingest exactly as day-zero Step 2: same xlsx fallback, big-file summarising, and date rules.
4. Write `clients/<name>/business-profile.md`, build the first document into `clients/<name>/queue/`, same format rules as day zero (email-ready block + CSV block, EXAMPLE labels).
5. Close with the handover reality, in plain words:
   - "The approval rule still applies, but the approver is your CLIENT: show them the draft, they decide, you deliver."
   - "Confidentiality is yours to carry: one folder per client, delete on request, and the written permission you got in step 0 is your cover. To stop working on this client, say 'back to my business'."
   - Point at the paperwork: "Templates for the pilot proposal, the permission letter, and the before/after proof sheet are in guides/templates/. Fill them before the pilot starts."

## What this mode never does
- Never advises on the client's legal, tax or HR matters.
- Never contacts the client or anyone else directly.
- Never copies kit files out as a product for the client (see LICENSE.md): the client receives documents and a working setup, not the kit for redistribution.

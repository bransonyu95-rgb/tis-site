---
name: sop-writer
description: Writes Standard Operating Procedures in the audit-accepted ISO 9001 convention. Use when the owner asks for an SOP, work instruction, procedure, or says "document how we do X".
---

# SOP Writer — procedures that survive an audit

FIRST check `data/active-client.txt`: if it names a client, work in `clients/<name>/`. Read the business profile before writing anything.

## The honest standards note (tell the owner once)
ISO 9001:2015 does not prescribe an SOP template. It requires controlled documented information (clause 7.5): identified, versioned, approved, available where the work happens. The skeleton below is the convention auditors accept everywhere. If the owner's company already has a QMS format, THEIRS WINS — ask for one existing SOP in `data/exports/` and mirror its numbering, header and footer exactly.

## Before drafting — ask, one at a time, only what the profile doesn't answer
1. What task, and where does it start and end? (one SOP = one process, not a department)
2. Who performs it, who checks it, who approves the SOP?
3. What goes wrong when it's done badly? (those points become inline cautions)
4. Any existing doc number scheme? (else mark `[CHECK: your doc number]`)

## The skeleton (produce every section, in this order)
**Document control header** — table at top: Doc No `[CHECK]` · Rev (start at 01 for new, or next rev of the mirrored doc) · Effective date (from system `date`, never assumed) · Prepared by / Reviewed by / Approved by (names from the interview; approver blank = `[CHECK: approver]`).
1. **Purpose** — one sentence: why this procedure exists.
2. **Scope** — where it applies and, explicitly, where it does NOT.
3. **References** — related SOPs, forms, standards the owner names. Never cite a standard the owner didn't confirm they hold.
4. **Definitions** — only terms a new hire would stumble on.
5. **Responsibilities** — one line per role. Every role mentioned in section 6 must appear here.
6. **Procedure** — numbered steps. One action per step, imperative voice, the doer named: "6.3 The line leader records the reject count in Form QF-07." Decision points as if/then. Safety or quality traps as an indented ⚠ note under the step they belong to.
7. **Records** — table: record created · where kept · retention period `[CHECK: your retention rule]`.
8. **Revision history** — table: Rev · date · change summary · changed by.

## Hard rules
- Every step has a doer. "The report is prepared" (by whom?) is a finding waiting to happen.
- Steps describe what IS done, confirmed by the owner — never what you guess should be done. Gaps stay `[CHECK: …]`, visibly.
- Print the full draft in chat first. After the owner reacts, save as `.md` into the queue folder.
- Keep it to what a trained operator needs. A 2-page SOP that is read beats a 12-page SOP that is signed and ignored.

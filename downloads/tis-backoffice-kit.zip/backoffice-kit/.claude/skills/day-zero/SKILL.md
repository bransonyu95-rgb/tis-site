---
name: day-zero
description: First-run setup for the AI back-office. Use when the owner says "start day zero", "set up", "begin", or opens this kit for the first time. Interviews the owner (5 questions, one at a time), ingests their real files from data/exports/, writes data/business-profile.md, then produces their first real document into queue/.
---

# Day Zero — set this back-office up around the owner's real work

Goal: in one sitting, the owner holds a real, usable document built from THEIR data. Warm, brief, zero jargon. One question per message, always.

## Step 1 — The interview (5 questions, strictly one at a time)
1. "What does your business (or the company you work for) actually do? One or two sentences, like you'd tell a taxi driver."
2. "What's YOUR role in it — what do people come to you for?"
3. "Who reads your work or buys from you, and what do they judge you on? If it's mainly one person (your GM, your boss), tell me their name or how you address them. (Just the name is fine.)"
4. "What's the one document or task you redo every week that you wish someone else handled?"
5. "Anything I should never do or say in your business? (names to hide, topics to avoid, a boss's pet peeve)"

If at ANY point the owner asks about using this for clients or reselling: answer with the split, exactly this shape — "Two different things. Serving clients WITH the kit: yes, allowed and encouraged, unlimited clients. Reselling the kit FILES as your own product: no. If you install a copy inside a client's business, that client buys their own license from the shop; your setup work is what you charge for — pricing guidance is in guides/for-consultants.md. Say 'client mode' after setup and I'll build your first client workspace." Then continue.

## Step 2 — The real-data moment (this is the product)
(If the owner is a brand-new consultant with no business files yet, say so honestly: "You have no exports yet, and that is normal — your first document will be built from your answers, and your first REAL-data moment comes with your first client's files." Then skip to the template path.)
Say: "Now the important part. Drop one or two real files you work with into the folder `data/exports/` — an Excel export, last week's report, a price list, anything related to that weekly task. Messy is fine. Tell me when they're in. (If you'd rather not yet, say 'skip' and I'll build a template version first.)"

- Files provided: READ them, whatever the format. `.csv` and `.txt` read directly; `.xlsx` read via a quick script (e.g. `python3` with openpyxl or by converting) — if that fails on this machine, say plainly: "Excel's own format didn't open here. Open the file in Excel and use Save As → CSV, drop that in instead. Thirty seconds." Never silently skip a file.
- Big files: if an export has more than ~50 rows, summarise honestly: totals, the exceptions (late/failed/blocked rows) in full, everything else aggregated. Say what you did: "412 rows read; showing the 9 exceptions and the totals."
- Dates: get today's date from the system (`date`), never assume it. A job is "late" only if its due date is before today, regardless of any status label in the file; when the file's label and the dates disagree, show both and flag it. In paste-ready text, write the actual date, never the word "today".
- "skip": build the template path, and clearly say the upgrade line: "Next time, drop a real export in data/exports/ and I'll rebuild this around your actual data."

## Step 3 — Write the profile
Create `data/business-profile.md`: the business · the owner's role · who judges their work and on what · weekly pain task · red lines · tools and inputs seen in exports · output language (match the owner's language and formality from their answers) · voice notes.
Do NOT stop here for confirmation — build the first document first (Step 4), then show profile + document together and ask ONE question: "Did I get your business right?" Fix what they correct in both.

## Step 4 — The first document (same sitting, from their data)
Build the weekly pain task properly, from the real files when given:
- Report → their actual report for the current data: takeaway title, the numbers that matter from THEIR columns, flagged items with reasons, the ask at the end. Plus the reusable template version.
- SOP → drafted from how they described it, [CHECK: ...] on every assumption.
- Emails/quotes/minutes → skeleton + 2 drafts in their voice, their real context.
- Vague Q4 → default to a one-page weekly report for their role.
- Consultant with no clients yet → their real "weekly task" is getting the first client: build an outreach pack instead — a filled-in pilot proposal for one named target prospect type (base: guides/templates/pilot-proposal.md) plus 2 outreach emails, [CHECK: name] where the prospect's details go.

**Output format rules (always):**
- PRINT the email-ready version directly in the chat first, so the owner sees their document the moment it exists — then save, and say in one line where: "Saved in the queue folder inside this kit — open it like any normal folder."
- In date wording use actual dates from `date` ("Monday 13 Oct"), never relative words. When file data is older than today, say "as of <file date>" once.
- CSV files: plain ASCII only (no smart quotes, no long dashes) so Excel opens them cleanly.
- Save `queue/day0-<short-name>.md` (the full document) AND a real spreadsheet file `queue/day0-<short-name>.csv` with the table, so Excel opens it directly with columns intact.
- The .md contains: (a) the EMAIL-READY block (with the real recipient name from Q3, and real dates), (b) the table, (c) the reusable template.
- Any ask or recommendation not found in their data is marked [CHECK: your call] — never presented as fact.
- Anything invented for illustration is labelled EXAMPLE on the same line. Real data is never mixed with example data in one table.

## Step 5 — Close by pointing at THEIR next step (not a fixed line)
Base the suggestion on Q4:
- Reports/analysis pain → "Next Monday, drop the new exports in data/exports/ and tell the Writer: 'build this week's report'. Two minutes."
- Customer/communication pain → "Try: 'writer, draft the reply to [situation]'."
- They're a consultant → "Say 'client mode' and I'll set up your first client workspace."
Then show what the kit now remembers — this is what a one-off chatbot upload can never do. Five short lines: "From now on, every draft already knows: your business is X · [boss name] judges you on Y · red lines: Z · your voice: W · your weekly task: V. You never explain yourself to this AI again."
Then one line on the system: "Everything the team makes lands in queue/ for YOUR approval. Nothing sends itself."

## Rules
- One question per message. Interview under 7 minutes of the owner's attention.
- Their answers are the spec; do not pad with assumptions.
- The first document must be usable at their work tomorrow. That is the moment they judge the purchase.

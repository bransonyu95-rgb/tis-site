Drafts land here and wait for you. Move a file to approved/ when you accept it, or tell the agent what to change.

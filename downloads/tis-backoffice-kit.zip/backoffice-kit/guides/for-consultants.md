# Using this kit for clients — the honest starter guide

You bought this to help OTHER businesses build their AI back-office. Allowed, encouraged, and the license says so plainly. Honesty first: I run this system daily inside a real factory office — I am not a consultant. The service ladder and prices below are how I would sell it from the buyer's side of the table; treat them as a starting opinion, not industry data.

## What you are actually selling
Not "AI". You are selling: their Monday report done in 20 minutes instead of 2 hours, their SOPs finally written, their quotes defended with reasoning. Name the task, show the before/after. Nobody buys "automation"; everybody buys their own evening back.

## The simple service ladder
1. **Discovery visit** — sit with one office person, find their most-hated weekly task, show the kit doing it live on sample data. This is your sales call; price it low or free, your choice.
2. **Pilot** — set up ONE workflow for ONE person, two weeks, measured: "report time went from 2 hours to 25 minutes." The before/after sheet below is your receipt.
3. **Full setup** — the whole back-office: profiles, two or three workflows, training the staff to approve drafts.
4. **Monthly care** — small retainer: you check in, improve prompts, add one workflow a month.

## On pricing (my opinion, not a rulebook)
This is Ah Hock's view from the Malaysian SME world, 2026 — adjust to your market and your proof:
- Discovery: free to RM 500
- Two-week pilot: RM 1,500 – 5,000
- Full setup + training: RM 3,000 – 10,000
- Monthly care: RM 300 – 1,500
Start at the low end until you have two before/after receipts. Raise with proof, never with adjectives. If a client asks "can't we just buy the kit ourselves?", the honest answer is yes — it's on the shop for the price of lunch — and what they pay YOU for is: they don't have time, you've done it before, and you'll still be there next month. Say exactly that; honesty here wins the job more often than it loses it.

**One worked example (pilot):** mold shop, planner's Monday report, 2 hours/week by hand. Pilot RM 2,500: you spend ~4 hours total (interview, setup, two check-ins). Report drops to ~20 minutes/week. Client saves ~85 hours/year of a planner's time; your effective rate ~RM 600/hour; the before/after sheet proves it. Also budget the running cost line for the client: their own Claude Pro at ~USD 20/month if they keep the install, plus their own kit license (see LICENSE.md).

## The paperwork, ready in guides/templates/
Three fill-in files are included: `pilot-proposal.md` (one page), `permission-letter.md` (get it signed before any client file enters your folder), `before-after-sheet.md` (your proof receipt). Two filled before/after sheets and your next pilot sells itself.

## Professional hygiene
- Written permission before touching their data. One folder per client (`client mode` does this). Delete on request.
- Personal data of individuals in their files → Malaysia's PDPA applies to you; mask names when in doubt.
- Never promise what the demo didn't show. Under-promise; the kit over-delivers on boring tasks, which is exactly where the money is.

# Before / after proof sheet — [task name] at [Client name]
*(Fill at pilot start and pilot end. Both sides keep a copy. This is your receipt for the next sale.)*

| | BEFORE (measured [date]) | AFTER (measured [date]) |
|---|---|---|
| Who does it | | |
| Time per week | | |
| Steps done by hand | | |
| Errors/redos last month | | |
| The person's own words | "" | "" |

Time saved per week: ____ hours · per year: ____ hours
Signed: [client] ____ · [you] ____

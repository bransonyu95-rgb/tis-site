# Data permission letter — [Client name]
*(Get this back signed, or as an email reply saying "agreed", BEFORE any client file enters your folder.)*

Dear [Client contact],

For the [pilot/setup] we agreed, I will need working copies of: [list the files, e.g. "weekly WIP export, open order list"].

So everything is clear:
1. I will process these files using Claude, an AI service by Anthropic (a US company), under my own account.
2. Your files live in a folder dedicated to [Client name] only, never mixed with any other client's.
3. On your request, I delete everything within [X days].
4. If the files contain personal data of individuals, tell me and I will mask names before processing, or you may mask them before sending.
5. I use your data only for the work we agreed, nothing else.

Reply "agreed" to this letter and we can start.

[Your name] · [date]

# Pilot proposal — [Client name]
*(Fill every [bracket]. One page. Send as PDF or in the email body.)*

**What we will fix first:** [the one weekly task, named: e.g. "the Monday production status report"]
**Who it's for:** [name, role]
**How it works today:** takes [X hours] per [week], done by [person], from [source files].
**The pilot (2 weeks):** I set up an AI back-office workflow for this one task. [Person] drops the usual files in a folder; a draft arrives for their approval. Nothing is sent or changed without a human yes.
**What you'll see at the end:** the same report, produced in [target: e.g. 15 minutes], measured honestly on the before/after sheet we both sign.
**Your side:** [person]'s time for a 30-minute setup interview + the usual weekly files.
**Data:** your files stay in a folder dedicated to you, processed via Claude (Anthropic, US). Delete-on-request anytime. Personal data masked on import if you prefer.
**Price for the pilot:** RM [amount], payable [terms]. If the before/after shows no real time saved, [your guarantee — e.g. "you don't pay the second half"].
**After the pilot (optional, no obligation):** full setup RM [range] · monthly care RM [range].

[Your name] · [phone] · [date]

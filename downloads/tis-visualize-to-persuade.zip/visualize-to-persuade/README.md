# Agentic AI: Visualize to Persuade
### It finds who decides, works out the numbers, builds the deck, checks its own work, then plays your boss so you can practise.

**Works as a full AI agent in Claude Code. Works as a step-by-step AI guide in any free chat.**

**Not just how to show it. What to show, and who it's for.** Most chart tools start with the chart. This one starts with two questions: who is watching, and what do you need them to decide? Only then does it pick the chart, the title and what to leave out. It covers proposals, investment plans and business plans too, not only slides. Written by Ah Hock (The Industrial Scribe) from a career in factory sales and customer-facing roles, getting proposals and plans through management.

**The moment this is for:** you have a good idea: a new machine, one more planner, a better process, a price increase the customer must accept. You spend two days on the slides. The GM says "okay, noted" and nothing happens. The idea was fine. The ask wasn't built for the person who decides.

## What it does
1. **Maps who really decides:** who signs, who can quietly block it, who must live with it, and what each one gains, fears and believes today.
2. **Does the money maths from your numbers:** payback, return, the cost of waiting, break-even, with every assumption in one table and a conservative case, so the finance manager can't tear it apart. It never invents a figure: missing ones are marked [CHECK].
3. **Answers the six questions every approver asks** before they ask them: why this, why now, why this option, how much and when do we get it back, what could go wrong, what exactly do you need from me.
4. **Builds the options:** do nothing, a small step, the full fix, with one recommended, and a stop point that makes the yes feel safe.
5. **Prepares you for the room:** the 5 hardest questions with short answers, and the number most likely to be challenged.
6. **Writes it:** a one-page memo, an email or a short deck, with titles that say what to conclude, not what the slide is about.
7. **Rehearses with you:** it plays your GM (or your customer) and asks the hard questions, then tightens your answers.

## Ready layouts for 9 factory asks
Investment proposal · business plan · budget or headcount ask · new process or system · customer price increase · recovery plan · monthly management review · customer business review · quality update.

## Still in the box: slides and the so-what dashboard
- **Deck:** takeaway titles, the right chart for each factory message (chart chooser included), the ask on its own slide.
- **So-what dashboard:** an ACT TODAY band (at most 3 things that crossed your own action rules), every tile with what to do, who does it and by when; grey by default, colour only where action is needed.
- **Check:** paste a proposal, slide or chart you already made and get the fix.
- **A 22-point pre-ship check** before anything goes to someone who decides.

## Why we call it an agent
In Claude Code it doesn't just answer. It works through the job:
- **It plans the steps** and asks you one question at a time for what's missing.
- **It uses real tools:** it opens your Excel or CSV and does the maths with a calculator script, never by eye.
- **It builds the real thing:** a deck or dashboard file that opens in any browser and prints to PDF.
- **It checks its own work** against 22 points before you send it, and marks every gap [CHECK].
- **It plays your boss** and asks the hard questions, so you can practise.

The decision, and the send button, stay yours.

## Two ways to run it
**A. No install: any AI chat, free plans OK.** Open `paste-prompt.md`, choose proposal, deck, dashboard, check or rehearse, fill the blanks and send.

**B. Claude Code skill: for people who already use Claude Code** (needs Claude Pro, US$20/month). Move this folder to your skills folder (Mac: `~/.claude/skills/visualize-to-persuade`; Windows: `%USERPROFILE%\.claude\skills\visualize-to-persuade`). Drop in your Excel or CSV and say "help me get this approved" or "build my dashboard". It does the maths with a script (never by eye), reads the full reference library, and builds a real file: a proposal deck or dashboard page with the charts drawn in, which opens in any browser and prints to PDF.

## What's inside
- `paste-prompt.md`: the no-install version (way A).
- `SKILL.md`: the Claude Code skill (way B).
- `references/`: the playbook: the persuasion method, 9 ask layouts, numbers that persuade, a chart chooser for factory data, takeaway-title formulas, answers to the hard questions, and the pre-ship checklist. Worth reading on its own.
- `examples/`: worked examples (invented data, labelled EXAMPLE): a deck from a messy defect log, a so-what dashboard and the file the skill built, and a headcount proposal from first question to the memo's first line.

## The honest limits
- It uses only your numbers. It won't invent a saving, a target, an owner or someone's opinion, and it will tell you if your case doesn't add up.
- It makes your case clearer and harder to argue with. It can't make a bad idea good, and the decision is still the decider's.
- Follow your company's rules on putting work data into AI tools. Placeholders for names and money figures work just as well.

## Help
Reply to your purchase receipt. A human answers, usually within a day.

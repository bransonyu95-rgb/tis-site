# Credits

The starting idea for this skill (an email partner that understands the whole thread before it drafts) came from the "Email Intelligence Engineer" agent in the open-source agency-agents project, released under the MIT License:
https://github.com/msitarzewski/agency-agents

This skill was rebuilt from scratch for factory office work: a no-install paste box, no mailbox connection, your own style and rules, customer profiles, and drafts only. The method it now follows (your rules before every draft, one recommended option, a fact check against the thread, keeping your edits, and one list of what you owe) comes from a working email assistant used daily in a factory office, described in the case study "How I Stopped Losing Promises in Email Threads".

The MIT License text of the original project, as required:

---

MIT License

Copyright (c) 2025 AgentLand Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

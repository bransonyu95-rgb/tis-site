# EXAMPLE: first-time style setup, from 5 sent emails to a finished MY STYLE

**EXAMPLE: everything below is invented.** No real company, order or person. The outputs are what an AI chat actually produced with the STYLE BUILDER in `paste-prompt.md` during testing, lightly trimmed.

---

## The 5 sent emails the user pasted
> 
> --- email 1 ---
> Hi Mr Tan, thanks for the PO 77120. Confirm we can deliver 5k pcs by 14 Nov. Will share the packing list once ready. Rgds, Mei Ling
> 
> --- email 2 ---
> Hi Rajesh, sorry, cannot do RM 0.42/pc lah, our material cost already up 8% since Aug. Best we can go is RM 0.46 for 10k MOQ. Let me know ok? Thanks, Mei Ling
> 
> --- email 3 ---
> Dear Ms Wong, sorry for the late shipment. Our SMT line down 2 days last week (feeder problem, fixed already). Your 3,000 pcs will ship Thu 6 Nov, I will send the AWB once out. Sorry again for the trouble. Best regards, Mei Ling
> 
> --- email 4 ---
> Hi Kevin, gentle reminder on the payment for INV 2291 (RM 18,400), due 15 Oct. Can help check with your finance? Thanks ya. Mei Ling
> 
> --- email 5 ---
> Hi boss, quick update: Ms Wong order delay 2 days, customer ok already. Rajesh asking price down again, I hold at 0.46. Kevin payment still pending, chasing. Mei Ling
> 
> 

## What the AI showed back: "This is how you write"
1. **Greeting and sign-off:** "Hi" plus first name for regular contacts. "Dear" plus title only for formal apology notes. Short sign-off, first name only.
2. **Language:** plain English, with light Malaysian particles ("lah", "ya", "ok?") in casual messages. Formal notes stay clean.
3. **Formality and warmth:** friendly, never stiff. Warmer with customers, blunt with suppliers, short and factual with the boss.
4. **Length and pace:** 2 to 3 short sentences. The point comes in the first line.
5. **Phrases you use:** "confirm we can...", "will share once ready", "let me know ok?", "gentle reminder".
6. **Saying no:** a short "cannot do", the reason in a few words, then the best offer you can actually make.
7. **Bad news:** fact first, cause in one line, the fix, a firm new date.
8. **Apologising:** one "sorry" near the start and one at the close for customers. Never a long apology paragraph.
9. **Chasing:** invoice, amount and due date in one line, then ask them to check with their finance team.
10. **Updates to the boss:** "quick update", then each issue with its status (ok, holding, pending, chasing).

"Is this you? Anything I got wrong?"

## How the user said they WANT to sound
> "ya that's me. but with customers i want less sorry, only once max, and firmer when they chase me. boss same style ok. rule: never agree discount or credit without my GM approval. sign off always 'Best regards, Mei Ling'"

## The finished MY STYLE the AI handed back (the user keeps this copy)
```
MY STYLE (fill once, keep your copy)
- My name and sign-off: Mei Ling. Always "Best regards, Mei Ling".
- Language I write in: English. Light Malaysian particles ("lah", "ya", "ok?")
  in casual notes to suppliers and my boss. Customer emails stay clean.
- My usual tone: friendly, polite and direct. Short sentences, point first.
- Phrases I like to use: "confirm we can...", "will share once ready",
  "let me know ok?", "gentle reminder", "quick update".
- Words or phrases I never use: (none yet)
- Anything else:
  - Customers: at most one "sorry" per email, only where the fault is ours.
    Firmer when they chase: facts, date or amount, next step.
  - Suppliers: casual and blunt. "Cannot do", short reason, best real offer.
  - Boss: same as suppliers. "Quick update", each item with its status.
  - Bad news: fact first, cause in one line, fix, firm new date.
  - Rule: never agree to a discount or credit without my GM's approval.
    Say I will check with my GM first.
```

Notice what it did NOT keep: no customer names, no prices, no invoice numbers. It kept only how she writes.

## The other path: "no, my company doesn't allow it"
In the Claude Code version, a tester answered the permission question with "no la, company don't allow. just ask me". The skill replied straight away: "Okay, no problem. We'll go with questions only, and I won't read any emails." Then it asked one question at a time. It never asked twice.

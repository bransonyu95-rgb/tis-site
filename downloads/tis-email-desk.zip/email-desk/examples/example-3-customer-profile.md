# EXAMPLE: a customer profile, built from 2 past threads, then used on a new complaint

**EXAMPLE: everything below is invented.** No real company, order or person. The outputs are what the AI actually produced during testing, lightly trimmed.

---

## Part 1: Building the profile from 2 past threads

The user gave the CUSTOMER CARD BUILDER two older threads with CUSTOMER-A:
- **August:** a bent-pin complaint on LOT 2312. The QA manager rejected the first 8D because D2 had no IS / IS-NOT table. A revised 8D was accepted on 2 Sep (root cause: tray stacking at packing, new tray design from 1 Sep).
- **September:** the buyer asked for a revised quotation by 15 Oct because of a 5% cost-down target. "Short answer is fine, I just need the numbers."

**What the AI built (key lines):**
- **The people:**
  - Chua Siew Lan, QA Manager: wants complete, correct 8Ds on the first submission. Write formally ("Dear Ms Chua"), with the 8D sections clearly labelled.
  - Lim Wei Jie, Purchasing: numbers and speed. Write briefly, numbers first.
- **Their direction right now:** a 5% cost-down target for all suppliers next year.
- **Sensitivities:** QA rejects 8Ds that don't follow the structure (rejected 20 Aug for a missing IS / IS-NOT).
- **Case history:** LOT 2312 bent pins, rejected once, then accepted 2 Sep. Lesson: IS / IS-NOT in D2 and both D4 chains (why made, why shipped) from the first version.
- **Open promises:** revised quotation due 15 Oct. "Status not in the threads, please confirm whether it was sent."

Then it asked, one at a time: "How important is this customer to us?"

---

## Part 2: The same customer's new complaint, with the profile loaded

The user pasted the October thread (5 emails: 600 pcs LOT 2409-B with bent pins, the 8D overdue, a RM 1,850 credit note request, the third chase with an escalation threat) and said: "8D our QA engineer sends Mon 2 Nov. 600 pcs shipped today on the regular truck. credit note need finance, dont agree."

**First line of the reply:** "Using CUSTOMER-A's profile (last updated 2 Oct)."

**What the profile added to the catch-up:**
> **From this customer's history:** second bent-pin complaint since August (LOT 2312, 8D accepted 2 Sep, root cause tray stacking at packing). The profile says the 8D must have IS / IS-NOT in D2 and both why-made and why-shipped in D4, from the first version. QA rejected an 8D without this in August.
> Also still open from the profile: the revised quotation due 15 Oct.

**Tone line:** "Your style, direct and numbers-first for Wei Jie (profile). Apologetic for the missed date. Calm and firm on the credit note, because he has chased three times."

```
EMAIL-READY
Subject: RE: Bent pins LOT 2409-B: 8D on Mon 2 Nov, 600 pcs shipped today

Hi Wei Jie,

You are right, I missed the 8D date I gave you for end of last week, and I
am sorry for the delay. Our QA engineer will send the 8D on Monday 2 Nov.

The 600 replacement pcs for LOT 2409-B ship today on the regular truck. I
will send you the tracking number and expected arrival date by [CHECK: time today].

On the RM 1,850 sorting cost: I have passed it to our finance team for
approval. I cannot confirm a credit note until they decide. I will give you
their answer by [CHECK: date].

This is the second bent-pin case since August. The 8D will show the root
cause, why the defect was shipped, and what is different this time:
[CHECK: confirm with QA engineer what changed].

Best regards,
Kumar
```

**The warning only a profile makes possible:**
> "Also check the 8D has IS / IS-NOT in D2 and both D4 chains, because Chua Siew Lan rejected one without them in August."

**Then it offered to update the profile:**
> "I would add to CUSTOMER-A: [30 Oct: 600 pcs LOT 2409-B bent pins; 8D promised end of week 23 Oct, missed, now Mon 2 Nov; 600 pcs shipped 30 Oct; RM 1,850 credit note request with finance] and [28 Oct: Wei Jie third chase, escalation threat]. Save on your yes."

Without the profile, the reply would have treated this as a first-time problem, and the 8D might have been rejected a second time for the same missing table. With it, the reply names the repeat, promises what's different, and the next thread starts with all of this already known.

# EXAMPLE: a 5-email complaint chain, a customer about to escalate

**EXAMPLE: everything below is invented.** No real company, order or person. The outputs are what an AI chat actually produced with `paste-prompt.md` during testing, lightly trimmed.

---

## The thread the user pasted (newest on top, the way Outlook shows it)

```
From: Lim Wei Jie <purchasing, customer side>
Sent: Wednesday, 28 October 2026 9:12 AM
To: Kumar
Subject: RE: RE: RE: Bent pins LOT 2409-B

Hi Kumar,

This is the third time I am asking. Where is the 8D for the bent pins? You said end of last week. My QA manager asks me every day. We also still have not received the 600 replacement pcs. Please confirm by tomorrow or I will need to escalate to your management.

Wei Jie

From: Kumar
Sent: Thursday, 22 October 2026 4:40 PM
To: Lim Wei Jie
Subject: RE: RE: Bent pins LOT 2409-B

Hi Wei Jie, noted with thanks. We will send the 8D by end of this week. Replacement 600 pcs will ship together with your next regular shipment on 30 Oct.
Regards, Kumar

> From: Lim Wei Jie
> Sent: Wednesday, 21 October 2026 10:05 AM
> Kumar, any update on the 8D? For the 600 rejected pcs, we propose you ship replacements with the next regular shipment to save freight. Please also issue a credit note for our sorting cost, RM 1,850 (2 operators, 1 day).
>
>> From: Kumar
>> Sent: Friday, 16 October 2026 11:20 AM
>> Hi Wei Jie, sorry for the inconvenience. Our QA team is investigating. Will revert soon.
>>
>>> From: Lim Wei Jie
>>> Sent: Thursday, 15 October 2026 8:30 AM
>>> Dear Kumar, we found 600 pcs of connector module LOT 2409-B with bent pins at our incoming inspection. Photos attached. Please send the 8D within 7 days and arrange replacement.
```

## What the user filled in

- **MY STYLE:** Kumar, Customer Service · English · polite and direct · never use "kindly", "revert", "noted with thanks" · never agree to money without finance approval
- **TODAY'S DATE:** Friday 30 October 2026
- **WHAT I WANT TO SAY:** "8D final review by our QA engineer, send Mon 2 Nov. replacement 600 pcs ship today 30 Oct with regular shipment, DO number later today. credit note need check with finance first, dont agree yet"

## 1. The catch-up it gave back

**Promises**
- Kumar: 8D by end of week (Fri 23 Oct). **OVERDUE, 7 days late.**
- Kumar: 600 pcs replacement with the regular shipment on 30 Oct. Open, due today. (Customer proposed it, Kumar confirmed it in writing.)
- RM 1,850 credit note: nobody promised it, and nobody answered it either. Open.

**What they're asking now:** "Where is the 8D?" and confirm by tomorrow, or he escalates to our management. The 600 pcs are still not received.

**Customer mood: frustrated.** "This is the third time I am asking." "I will need to escalate to your management."

## 2. The draft

Suggested tone: calm and firm. He has chased three times and threatened escalation, so the reply gives dates, not reassurance.

```
EMAIL-READY
Subject: RE: Bent pins LOT 2409-B

Hi Wei Jie,

I am sorry the 8D is late. You will receive the final review from our QA
engineer on Monday 2 Nov. The 600 replacement pcs ship today, 30 Oct, with
our regular shipment.

Our commitments:
- 8D: final review by our QA engineer, sent to you Monday 2 Nov.
- Replacement: 600 pcs ship today, 30 Oct. I will send you the DO number today.
- Credit note: our finance team is reviewing your RM 1,850 sorting-cost
  request. I will confirm our position in writing by [CHECK: date finance will confirm].

You can hold me to Monday 2 Nov for the 8D.

Best regards, Kumar
```

**Questions this reply already answers:** When does the 8D arrive? (Mon 2 Nov) · When do the 600 pcs ship? (today) · When do I get the DO number? (today) · Is the credit note agreed? (No, finance is reviewing it.)

**Do not send yet. Decide the [CHECK] item first:** the date finance will confirm the RM 1,850 position. It never agreed to the money, because MY STYLE said not to.

---

## 3. Same thread, different user: Malay, then a tone change by conversation

A second user filled MY STYLE with **Bahasa Melayu, warm** and left WHAT I WANT TO SAY empty. The AI took a safe position and said so: no yes to the credit note, a written decision promised instead. Its first draft apologised three times.

**The user replied:** "too many sorry. make it firmer and shorter. polite but he must know we're not admitting the bent pins are our fault until the 8D is out. 8D date is Monday 2 Nov, our QA engineer sends it. 600 pcs confirmed on today's truck."

**The rewrite** (tone read as: firm and polite, shorter, one apology removed, fault left open until the 8D):

```
EMAIL-READY
Subject: RE: Bent pins LOT 2409-B - 8D dan 600 pcs gantian

Hai Wei Jie,

8D untuk bent pins LOT 2409-B akan dihantar oleh QA engineer kami pada
Isnin, 2 November 2026. Ia akan memuatkan hasil siasatan dan punca utama.
Sehingga 8D keluar, kami belum boleh mengesahkan punca bent pins ini.

600 pcs gantian akan dihantar bersama penghantaran biasa hari ini, 30 Oktober.

Mengenai nota kredit RM 1,850 untuk kos penyortiran, pihak pengurusan kami
akan beri keputusan bertulis pada [CHECK: decision date, and who approves it].

Terima kasih atas kesabaran tuan.

Salam hormat,
Kumar
```

Five emails read, every promise found, a reply in the user's language and tone, with no admission of fault and no money agreed. The user decides the one [CHECK] and sends it.

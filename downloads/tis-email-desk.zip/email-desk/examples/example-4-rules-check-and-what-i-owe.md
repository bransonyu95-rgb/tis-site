# EXAMPLE 4: your rules, one recommendation, the fact check, your edits kept, and "what do I owe?"

**EXAMPLE. Invented people and companies, a real test run (10 Nov 2026), shortened.** A sales engineer, Arif, uses the Claude Code skill. His `my-rules.md` says: (1) no price cut without the GM's signed OK, (2) keep CUSTOMER-A's new-part project on track for March, (3) promise only confirmed dates; never agree to money on email before finance has seen it. CUSTOMER-A's profile has a logged decision: *30 Oct: hold 2026 prices; we already gave 3% in 2025.*

## The thread he pasted
- **8 Nov, Ms Lim (CUSTOMER-A purchasing, her manager CC'd):** "All suppliers must give 5% price reduction from Jan 2026. Please confirm by 14 Nov. Also, your capacity plan is late. I need it this week. Our new part PPAP: your engineer said PPAP is approved, so we can release the PO now?"
- **4 Nov, Arif:** "Capacity plan will be with you by 7 Nov. PPAP pack for the new part is in preparation, target 20 Nov."

## What came back (shortened)
**This reply should:** hold the price and keep the new-part project on track, without promising a date or an approval he can't back.

**Catch-up:** three asks (5% off by 14 Nov, the capacity plan this week, release the PO because "PPAP is approved"). Capacity plan promised for 7 Nov: **OVERDUE** (3 days). Mood: impatient, manager on CC.

**Rules check:**
- Conflict: a 5% cut goes against goal 1, the "no money on email" principle, and CUSTOMER-A's decision of 30 Oct.
- Mismatch: "PPAP approved" isn't backed by anything in the thread. His own 4 Nov email says the pack is still in preparation.

**Options on the price:** A. Hold the price and offer to walk her through it (recommended: fits the 30 Oct decision and goal 1). B. "I'll check with the GM": buys time but signals the door is open. C. A smaller cut or a trade: not possible without the GM and finance.

**The draft (option A):**
> Hi Ms Lim,
>
> Price (your 14 Nov): thank you for letting us know. Our price stays as it is, as we already gave 3% in 2025. I am glad to walk you through how it is built, whenever suits you.
>
> Capacity plan: apologies, it is late. You will have it by [CHECK: date the plant confirms; she asked for this week, Fri 13 Nov].
>
> PPAP: the pack for the new part is still in preparation, target 20 Nov, so it is not approved yet [CHECK: ask your engineer what was said to Ms Lim]. Please wait for the pack before releasing the PO.
>
> Regards,
> Arif

**Fact check:** 7 facts checked, 5 found, 2 not confirmed and marked [CHECK] (the new capacity-plan date; what the engineer told her).

**Your decision:** (1) Can the plant confirm a capacity-plan date by Fri 13 Nov? (2) What did your engineer actually say about PPAP? (3) Hold the price, as decided on 30 Oct? **Do not send yet: two [CHECK] still open.**

## He edits, and it keeps his words
Arif: *"use your recommendation but in line 1 write 'Hi Ms Lim, thank you for the update.' and keep everything else, then make the price part a bit warmer."*

> **Changed:** line 1 is your wording, word for word. The price paragraph is warmer ("I understand the pressure on cost, and we value working with you. Our price stays as it is..."). The capacity plan and PPAP paragraphs and the sign-off are exactly as before. Rules check on what changed: no conflict, the price still stands.

## "What do I owe?"
| Due | Customer | What | Owed by | Status |
|---|---|---|---|---|
| 7 Nov | CUSTOMER-A | Capacity plan | Me | **OVERDUE** (3 days) |
| 12 Nov | CUSTOMER-C | Sample re-run report | Me | Due in 2 days |
| 20 Nov | CUSTOMER-A | PPAP pack, new part | Me | Due in 10 days |
| 15 Nov | CUSTOMER-A | Forecast | Customer (chase it) | Due in 5 days |

*CUSTOMER-C was last updated 15 Sep, so it may be out of date.* Then: "Want a draft for the top one?"

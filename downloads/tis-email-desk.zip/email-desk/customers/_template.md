# Customer profile: [short name or code, e.g. CUSTOMER-A]

Built and kept up to date by the agent, with your OK each time. It stays on your computer. Every line says where it came from, and anything the agent guessed is marked "(inferred, please confirm)".
Last updated: [date] · Built from: [e.g. "3 threads + your answers"]

## Who they are
- What they buy from us:
- How important they are to us (e.g. top 3 account, new customer, small):
- Since when:
- What WE want from this customer right now (e.g. "keep the volume through the price review", "get the new part approved by March"):

## The people, and how each one likes to be written to
| Person | Role | What they care about | How to write to them |
|---|---|---|---|
| (e.g. Wei Jie) | Purchasing | Dates, price, no surprises | Short, numbers first, English, no small talk |
| (e.g. QA manager) | Quality | 8D format, root cause proof | Formal, structured, never "operator error" |

## How this customer likes to be written to (company-wide)
- Language:
- Formality:
- What they want first (e.g. the date, the number, the root cause):
- Words or topics to avoid:
- Their own phrases or ways of saying things:

## Their direction right now (what they're pushing for)
- (e.g. "cost-down push: asked for price review twice this year", "zero-defect drive after their own customer audit", "moving some volume to a second supplier")

## Sensitivities and red lines
- (e.g. "escalates to our management fast when chased 3 times", "never mention their competitor", "their QA rejects an 8D without IS / IS-NOT")

## Decisions we've taken with this customer (newest first)
Every draft is checked against these. If a reply would go against one, the skill says so and asks you first.
| Date | Decision | Why | Source |
|---|---|---|---|
| (e.g. 12 Oct) | (e.g. "No free air freight on late orders caused by their PO changes") | (e.g. "3 PO changes in a month") | (e.g. "you told me 12 Oct") |

## Case history (newest first)
| Date | What happened | How it ended | Lesson for next time |
|---|---|---|---|
| | | | |

## Open promises right now
| Who owes it | What | By when | Status |
|---|---|---|---|
| | | | |

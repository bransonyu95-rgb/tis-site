# How to collect 5 to 10 of your sent emails, whatever email system your company uses

You only need **5 to 10 emails you sent**: a normal reply, a "no", some bad news, a chase. Pick ones you're happy to share. Removing names and prices first is fine. Your style shows just as clearly without them.

**Before anything:** follow your company's rules on work email and AI tools. If you're not sure, ask your IT team or your manager first. There's a ready-made message for them at the bottom of this guide.

---

## Step 1: Which email do you use at work?

Not sure? Look at how you open your email:
- **An app on your computer:** note its name or the logo (blue envelope "O" = Outlook; yellow-and-blue = HCL/Lotus Notes; a bird = Thunderbird; a stamp = Apple Mail).
- **A website in your browser:** note the start of the web address and any brand name on the page (Zimbra, Roundcube, Zoho, Alibaba Mail, Tencent Exmail/QQ, Yahoo, or just your company's name).
- **Still not sure?** In the Claude Code version, take a screenshot of your email screen (cover the email contents if you like) and drop it in. The agent will tell you which system it is.

## Step 2: Collect the emails. The safest way for your system

Every route below is something you do yourself, inside your own email, with your normal login. **No passwords are ever shared with the AI.**

| Your email | The easiest way to save a sent email |
|---|---|
| **Outlook app on Windows** (most company email, including company Exchange servers) | Go to Sent Items, open an email, then File → Save As → choose **Text Only (.txt)**. Repeat for 5 to 10 emails. (Dragging emails out also works, but makes `.msg` files that may not open. Text is safer.) |
| **Outlook app on Mac** | Go to Sent Items, select the emails, and drag them onto a folder in Finder. They save as `.eml` files. |
| **Outlook in the browser** (company "webmail" that looks like Outlook) | Open a sent email, click the **⋯** menu, then look for **Download** or **Save**. If there's none, use **Print → Save as PDF**. |
| **Gmail / Google Workspace** | Open a sent email, click **⋮** (top right), then **Download message**. It saves as `.eml`. |
| **HCL / Lotus Notes** | Select emails in your Sent view and look for **File → Export** (choose plain or structured text). If it's not allowed, open each email and **Print → Save as PDF**. |
| **Thunderbird** | Select sent emails, right-click, then **Save As**. They save as `.eml`. |
| **Apple Mail** | Select sent emails and drag them onto a folder in Finder, or use **File → Save As**. |
| **Zimbra, Roundcube, Zoho, Alibaba Mail, Tencent Exmail/QQ, Yahoo, or any other webmail** | Open a sent email and look in its menu (often **⋯**, **More** or **Actions**) for **Download**, **Export**, **Save as .eml** or **Show original**. If none exists, use **Print → Save as PDF**. |
| **Anything else, or nothing above works** | **Copy and paste.** Open a sent email, select the text, copy it, and paste it into the chat. This always works, on every system. |

**"Our company runs its own email server."** That's fine, and very common. This product never connects to your server. It only works with what you can already see on your screen. A company server usually shows up in one of three ways:
- **Outlook on your computer**, connected to the company's own Exchange server: use the Outlook rows above.
- **A company webmail page**, often an address like `mail.yourcompany.com` or `webmail.yourcompany.com`, made by Zimbra, Roundcube, Horde or cPanel: use the webmail row above.
- **HCL / Lotus Notes**, connected to the company's own Domino server: use the Lotus Notes row.

Whatever it is, if you can open the email on your screen, you can copy it or print it to PDF. If your company blocks copying, saving and printing emails, that is a company rule: ask your IT team first (message below) rather than working around it.

**Print → Save as PDF** works in almost every system and every browser: press Ctrl+P (Windows) or Cmd+P (Mac), then choose "Save as PDF" or "Microsoft Print to PDF" as the printer.

## Step 3: Hand them over
- **Claude Code version:** put the files in the `my-emails/` folder next to the skill, then tell the agent "done". It will tell you how many it read and which (if any) it couldn't open.
- **Free AI chat version:** open each file or email and paste the text under MY SENT EMAILS in the STYLE BUILDER box.

When your style is saved, delete the copies. The agent offers to clear `my-emails/` for you.

---

## Can it read my company email directly instead?

Only if your company already allows it. A direct connection means giving software access to your mailbox, and in most companies that is IT's decision, not yours or ours. So:
- **If your Claude already has an approved email connection** (your company set up a Gmail or Outlook connector for you), the agent can use it read-only, with your permission.
- **If it doesn't,** don't work around it: no sharing passwords, no forwarding work emails to a personal account, no installing tools IT hasn't approved. Collecting 5 to 10 emails by hand takes about 5 minutes and is enough.
- **If you'd like a direct connection for the future,** send IT the message below.

### Ready-made message to your IT team (edit freely)

> Hi [IT name],
>
> I'd like to use an AI writing assistant (Claude) to help draft my work emails. It learns my writing style from some emails I've sent, then drafts replies that I review and send myself. It never sends anything on its own.
>
> Could you advise:
> 1. Am I allowed to share a few of my sent emails with it, with customer names and prices removed?
> 2. Is there an approved way to connect it read-only to my Sent folder, or should I keep copying emails by hand?
> 3. Any company rules I should follow when using AI tools with work email?
>
> Thanks,
> [Your name]

# My style (built on first use, used on every reply)

Leave this blank. On first use the skill asks your permission to learn from your sent emails, or asks you a few questions, and fills it in for you. Say "change my style" any time to update it.

## How I write today (learned)
- Learned from: (e.g. "12 sent emails, 30 Oct 2026", or "my answers, no emails")
- Greeting and sign-off:
- Language (and any mixing):
- Formality and warmth:
- Length and directness:
- Phrases I really use:
- How I say no:
- How I deliver bad news:
- How I apologise:
- How I chase:

## How I want to sound from now on (my choices)
- Changes I want (e.g. "firmer with customers who chase", "fewer apologies"):
- Customers:
- Suppliers:
- My boss:
- Words or phrases I never use:

## Standing rules (always followed)
- (e.g. "never agree to money without finance approval", "always CC my manager on price")

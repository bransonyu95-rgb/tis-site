# Connect your work email to Claude, whatever system your company uses

Connecting means Claude can read your emails directly, so you don't have to copy them out. It is **optional**: copy-paste and Save as PDF always work (see `collect-my-emails.md`). Connect only if your company allows it.

**Three promises, whichever route you take:**
1. **You type your own login, into the official sign-in page or your computer's own password store. Never into the chat.** The agent never asks for, sees or stores your password.
2. **Read-only.** The agent reads. It never sends, deletes, moves or marks anything in your mailbox. Drafts stay in the chat for you to send yourself.
3. **Your company decides.** If the route needs IT approval, the agent drafts the request for you. It never goes around IT.

---

## Step 1: Find out who really runs your company email (1 minute, no login)

Your email might look like `you@yourcompany.com`, but the mail behind it is often run by Microsoft or Google. That decides which route works. The agent can check this from **public records** that any computer can look up: no login, nothing private.

- **Claude Code version:** say "check my email system" and give it the part of your address after the @ (e.g. `yourcompany.com`). It runs one public lookup and tells you the answer.
- **By hand:** on Windows, open Command Prompt and type `nslookup -type=mx yourcompany.com`. On Mac, open Terminal and type `dig +short MX yourcompany.com`. Then compare the answer with this table:

| The answer contains | Your email is run by | Go to |
|---|---|---|
| `mail.protection.outlook.com` | **Microsoft 365** | Route A |
| `google.com` or `googlemail.com` | **Google Workspace** | Route B |
| `zoho` | Zoho Mail | Route C |
| `mxhichina` or `aliyun` | Alibaba Mail | Route C |
| `qq.com` | Tencent Exmail | Route C |
| `mimecast`, `pphosted`, `barracuda` or another filter service | Hidden behind a security filter (you can't tell from outside) | Ask IT which system you use, then come back |
| your own company name, or anything else | **Your company's own server** (often Exchange, Zimbra, Lotus Domino or cPanel) | Route C |

---

## Route A: Microsoft 365 (official, read-only)
Claude has an official Microsoft 365 connector. It reads mail only. It can't send.
1. In the Claude app or claude.ai: **Customize → Connectors → Microsoft 365 → Connect.**
2. Sign in on Microsoft's own page with your **work** account. Personal @outlook.com or @hotmail.com accounts can't use this connector.
3. If you see **"Need admin approval"**, your company requires IT to allow it. Send IT the message at the bottom of this guide, tick "Microsoft 365 connector", then try again after they approve.
4. To disconnect at any time: Customize → Connectors → Microsoft 365 → Disconnect.

## Route B: Google Workspace (official)
1. In the Claude app or claude.ai: **Customize → Connectors →** Gmail (Google Workspace) **→ Connect.**
2. Sign in on Google's own page with your work account. If your company blocks it, you'll see a message saying so. Send IT the message below.
3. Disconnect any time in the same place.

After connecting (Route A or B), check that the agent can see your mail. In Claude Code, ask "can you see my email connection?". If it can't, use the connection in the Claude app with the paste box instead.

## Route C: Your company's own server, or Zoho, Alibaba or Tencent (IT decides)
There is no official Claude connector for these. The way to connect them is a standard email feature called **IMAP**, plus a small add-on program that lets Claude read through it. That means:
- your **IT team** must agree, and check that IMAP is switched on for your mailbox (many companies switch it off);
- **IT should choose and check the add-on.** Free read-only add-ons exist, but most are small projects run by individuals, and your mailbox login is at stake. Paid services exist too, but your email then passes through that company. This is a security choice for IT, not for you or us;
- once IT approves, IT installs and configures the add-on, or gives you the exact settings. You type your password into your computer's own password store, never into the chat;
- a separate **app password** (a second password just for this add-on) is safer than your main one, if your system offers it.

The agent helps by filling in the IT message below with what you need: read-only access, Sent folder plus the threads you choose, no sending.

**Until IT says yes, use copy-paste or Save as PDF.** It takes 2 minutes per thread and needs nobody's approval.

---

## Ready-made message to your IT team (the agent fills it in for you)

> Hi [IT name],
>
> I'd like to use Claude (an AI assistant) to help me read long customer email threads and draft replies. I review and send every email myself. It never sends anything.
>
> To do that, I'd like to connect it to my work email **read-only**. Could you advise:
> 1. Are we allowed to use AI tools with work email? Any rules I must follow?
> 2. [Microsoft 365 / Google Workspace] Could you approve the official Claude connector for my account? It asks for read-only mail access.
> 3. [Own server / other] Is IMAP available for my mailbox, and is there a read-only add-on you'd approve? If not, I'll keep copying emails by hand.
>
> Thanks,
> [Your name]

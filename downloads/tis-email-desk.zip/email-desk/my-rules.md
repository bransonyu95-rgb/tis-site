# My rules (read before every draft)

Optional, and it works without it. But this file is what turns the skill from "writes like me" into "decides like me". Every draft is checked against it, and anything that goes against it is flagged for you to decide, never fixed silently.

Fill it in by hand, or say "set up my rules" and the skill asks you a few questions (5 minutes). Say "add a decision" any time you decide something worth remembering.

## My goals, most important first (at most 3)
What your replies must protect. When two goals pull apart, the higher one wins unless you say otherwise.
1. (e.g. "Keep our top 3 customers, even at some cost")
2. (e.g. "Protect margin: no free extras without my manager's OK")
3. (e.g. "Promise only dates the plant has confirmed")

## How I decide (my principles)
- (e.g. "A delay is told the same day we know it, with a new date")
- (e.g. "Never agree to money on email before finance has seen it")
- (e.g. "Quality claims only after QA has signed off")

## Big commitments I own right now
The few promises that matter most this month, whoever they're to.
| What | To whom | Due | Status |
|---|---|---|---|
| | | | |

## Decisions I've taken (not tied to one customer)
Customer-specific decisions go in that customer's profile, under "Decisions".
| Date | Decision | Why |
|---|---|---|
| | | |

## Wording rules

### Always on (protects you; delete only if you are sure)
- Never show a customer our internal cost, margin, cycle times, rates, freight cost or supplier names.

### Starter set: switch on the ones you want
Delete the lines you don't want. Change the words to yours.
- [ ] Don't apologise in every email. Write "thanks for your patience" instead of "sorry for the delay".
- [ ] Keep a condition firm with positive words: "we will arrange delivery upon receipt of the revised PO", not "we will have difficulty delivering".
- [ ] When I'm waiting on the customer, put the date I asked for their answer in writing, so any delay is on record.
- [ ] When holding a price: say the price stands and offer to walk them through how it's built. No "we will review", no offer to re-quote.
- [ ] Before a commercial reply, check it's fair to both sides. If it feels unfair, say so before drafting.
- [ ] When I need information, ask broadly and give something first. When I commit, be direct.

### My own rules
- (e.g. "always CC my manager on anything about price")

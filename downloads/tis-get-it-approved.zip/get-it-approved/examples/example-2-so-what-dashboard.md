# EXAMPLE: a so-what dashboard from weekly figures

**EXAMPLE: everything below is invented.** The output is what an AI chat produced with `paste-prompt.md` (dashboard mode) during testing, lightly trimmed. `example-3` shows the same data built into a real dashboard page by the Claude Code skill.

## What the user pasted
- **Who will see it:** the Monday production meeting (plant manager, planner, QA lead, purchasing). Goal: "see in 10 seconds what needs action this week".
- **Their action rules:** on-time delivery (target 95%, act if below two weeks running, planner) · scrap rate (target 2.0%, act if above 2.5% in any week, QA lead) · overdue purchase orders (target 0, act if more than 5, purchasing) · customer complaints (act on any new one, QA lead).
- **Data:** 4 weeks of on-time delivery, scrap, first-pass yield, overdue POs, complaints and machine utilisation.

## ACT TODAY (week 44)
1. **Scrap rate hit 2.7%.** Over the 2.5% act line; it was 2.1% last week. QA lead investigates the week-44 scrap cause. By when: [CHECK]
2. **6 overdue purchase orders.** Over the limit of 5 (7 last week). Purchasing clears them. By when: [CHECK]
3. **On-time delivery at 94.6%.** Below 95% for three weeks running (94.0, 93.2, 94.6). Planner: [CHECK: the specific action]. By when: [CHECK]

## Tiles (each titled with its takeaway, not the measure's name)
- "On-time delivery has been under 95% for three weeks" (ACT, top-left)
- "Scrap rose to 2.7%, over the 2.5% act line" (ACT)
- "6 purchase orders are overdue, above the limit of 5" (ACT)
- "No new complaints in weeks 43 or 44" (on track; [CHECK: confirm the week-42 complaint was closed])
- "First-pass yield fell 2.2 points since week 41" (for information: no rule)
- "Machine use rose to 85%" (for information: no rule)

**Its plain point:** "First-pass yield and machine utilisation have no action rule. If nobody acts on them, they may not belong on this dashboard. Either give first-pass yield a target, threshold and owner, or drop it."

**Rules it says are missing:** for every measure, the specific action and by when; for first-pass yield and utilisation, a target, threshold and owner. It invented none of them.

# EXAMPLE: from a messy defect log to a deck the GM approves

**EXAMPLE: everything below is invented.** No real company, machine or person. The output is what an AI chat produced with `paste-prompt.md` (deck mode) during testing, lightly trimmed. Every number was checked by hand.

## What the user pasted
- **Who will see it:** "my GM at the monthly ops meeting. He thinks quality is fine because total defects only went up a little."
- **Decision needed:** "approve 6 hours downtime on Machine 7 this Saturday for spindle alignment and fixture repair"
- **Data:** an October defect table by cause (dimension out of tolerance, burr, scratch, thread NG, wrong label) and machine (7, 3, 5, others), plus "Total Sep 2026: 461".

## What it gave back
**One key message:** Machine 7 is producing most of our defects, and they are mostly dimensional, so 6 hours of alignment and fixture repair on Machine 7 fixes the problem where it starts.

**Slide 1: "Machine 7 produced 291 of 505 October defects (58%)"**
Sorted horizontal bars by machine: Machine 7 = 291 in the accent colour; Machine 3 = 72, Others = 72, Machine 5 = 70 in grey. Calculation shown: 182 + 96 + 8 + 5 + 0 = 291; 291 / 505 = 58%.

**Slide 2: "Dimension faults drive it: 182 of Machine 7's 291 defects"**
Machine 7 by cause, sorted, dimension faults in the accent colour. 182 of all 226 dimension faults (81%) are on Machine 7. Flagged: "[CHECK: maintenance lead confirms spindle and fixture are the likely cause]", because the data shows *where*, not *why*.

**Slide 3, the ask: "Approve 6 hours' downtime on Machine 7 this Saturday."** One sentence, with the date marked [CHECK] until confirmed.

**The number he'll challenge:** "Total defects only went up a little." Backup: the total rose 44 (461 to 505, about 10%), but one machine made 291 of them. "The total hides it because the other three machines are spread out."

**What it says is still missing before the meeting:** the cost of 6 hours of lost output (the GM will ask), and September defects by machine, which would make the strongest slide: Machine 7 rising while the others stay flat.

Pre-ship check: 8 ticks, 2 crosses (the ask's date, and the downtime cost), so it tells the user exactly what to fill in before presenting.

# EXAMPLE 4: getting one more planner approved

**EXAMPLE. Invented people and numbers, a real test run of the Claude Code skill (10 Nov 2026), shortened.** A production supervisor wants one more planner from January. The plant manager decides; HR must agree the headcount.

## What the user gave (one question at a time)
- Planner: RM 4,500 a month, loaded. Two planners today.
- Engineers spend about 60 hours a month on planning work (timesheets, Sep and Oct). Engineer cost RM 45 an hour.
- 9 late orders in Q3 caused by planning gaps, about RM 1,200 expedite freight each (freight invoices).
- Planner overtime about RM 1,800 a month.
- The plant manager believes: *"we just need better discipline, not more people."* HR: the headcount freeze ends in January.

## The decision map
| Who | Role | Believes today |
|---|---|---|
| Plant manager | Decides | "Better discipline, not more people" |
| HR | Can block | Freeze ends in January |
| Planners and engineers | Live with it | [CHECK] |

**Find out before the meeting:** "What would you need to see to believe more hands, rather than more discipline, would fix the late orders?"

## The numbers (calculated by script)
| Item | Method | Result |
|---|---|---|
| Engineer planning time | 60 h × RM 45 | RM 2,700 / month |
| Late-order freight | 9 × RM 1,200 ÷ 3 months | RM 3,600 / month |
| Planner overtime | given | RM 1,800 / month |
| **Cost of the gap today** | | **RM 8,100 / month** |
| Net if the gap fully closes | 8,100 − 4,500 | RM 3,600 / month |
| Conservative (savings 30% lower) | 5,670 − 4,500 | RM 1,170 / month |
| Break-even | 4,500 ÷ 8,100 | Pays for itself if 56% of the gap closes |

**Said plainly:** the RM 2,700 of engineer time is capacity, not cash. On cash alone (freight and overtime, RM 5,400), the planner needs 83% of it gone to cover the cost. Overtime and freight may partly come from the same gaps; that overlap is flagged, not hidden.

## Options, one recommended
| | Discipline only | Fixed-term planner | **One planner, review in March (recommended)** |
|---|---|---|---|
| Added cost | RM 0 | [CHECK] | RM 4,500 / month |
| Gap left | RM 8,100 / month | Same fix, less commitment | Up to RM 3,600 / month net |

**Stop point:** by the end of March, freight and engineer hours down by at least 56% of the gap, or the role is reviewed.

## The hardest question, prepared
> **"We just need better discipline."**
> "Fair. The 2 planners already work about RM 1,800 a month in overtime, and engineers fill 60 hours a month on top. Let's agree a number: if the freight and engineer hours don't fall by March, we stop."

**Number most likely to be challenged:** "9 late orders caused by planning gaps." Have the list of the 9 with the cause of each on a backup page.

## The first line of the memo
> **Approve one production planner from January at RM 4,500 a month. The planning gap costs RM 8,100 a month today, so the planner covers their cost if 56% of it goes away.**

## Pre-ship check (shortened)
✓ Ask in the first line · ✓ belief answered with a measured test · ✓ conservative case shown · ✗ decision date not given yet (it won't invent one) · ✗ 8 [CHECK] items to fill before sending.

# Ready layouts for the asks that matter in a factory

Pick the one that fits. Each page or slide has one job and a takeaway title. Keep it as short as the decision allows: a 5-page proposal that gets read beats a 30-page one that doesn't.

## 1. Investment proposal (a machine, automation, a fixture, software)
1. **The ask and the payback, in one line.** "Approve RM 120,000 for an automated deburr cell: 14-month payback from rework alone."
2. **The problem in money.** What it costs today, per month, with the source. One chart: the cost trend.
3. **The options.** Do nothing / small fix / full fix, in one table: cost, saving per month, payback, risk, what it doesn't solve.
4. **The recommended option.** Cost, saving, payback, ROI, and the assumptions table (see `numbers-that-persuade.md`). One chart: cumulative cash, crossing zero at the payback month.
5. **The risks and what we'll do.** Top 3, each with a control and an owner.
6. **The plan.** Milestones, the stop point and its test, who owns each step.
7. **The decision needed.** Amount, by when, and why that date (lead time, price change, customer launch).

## 2. Business plan (a new customer segment, a new product line, a new service)
1. **The opportunity in one line.** "Win RM 2.4M a year of medical-device machining by 2028 with one new cell and ISO 13485."
2. **Why us, why now.** What we already have that others don't; what changes in the market.
3. **The customer and what they buy.** Named segments, how they buy, what they need from a supplier.
4. **The numbers, three years.** Volume, revenue, margin, investment, cash, in one table, base and conservative.
5. **What we must build.** Equipment, people, certifications, with costs and dates.
6. **Risks and stop points.** What we'll know by month 6 and what we'll do if it's not working.
7. **The ask.** Phase 1 budget and the decision date.

## 3. Budget or headcount ask
1. **The ask:** "One planner from January, RM 4,500 a month."
2. **What's breaking today without it,** in hours, late orders or money.
3. **What it pays back:** hours freed, late orders avoided, overtime cut.
4. **What we tried first** (overtime, re-sharing work, automating a task) and why it isn't enough.
5. **What happens if not approved:** the honest cost of no.
6. **The decision and date.**

## 4. New process or system (a new tool, a new routine, an AI assistant)
1. **The ask and what changes for people.**
2. **Today's process and its cost** (time, errors, delays), with numbers.
3. **The new process, step by step,** and what each role does differently.
4. **The trial:** where, how long, what "it worked" means, measured how.
5. **Risks:** data, IT approval, people's time, and the controls.
6. **The decision:** approve the trial, not the whole rollout.

## 5. Customer price increase
1. **The new price and the date, in the first lines.** No long warm-up.
2. **The reason they can see:** a material index, a published rate, a cost they know went up. Never your internal cost or margin.
3. **What we absorbed already** (if true), and for how long.
4. **What stays the same or gets better:** lead time, quality, support.
5. **The options:** e.g. accept from 1 Jan, or a staged increase, or a longer-term agreement at a fixed price.
6. **The date you need their answer by,** in writing.

## 6. Recovery plan (after a failure, to your boss or a customer)
1. **What happened, in one honest line,** and the impact on them.
2. **What's already contained** (protecting them right now).
3. **The cause,** only as far as the evidence shows; "under investigation" with a date if not known.
4. **The actions:** what, who, by when.
5. **The new date they can hold you to** and how they'll know you're on track.
6. **What you need from them,** if anything.

## 7. Monthly management review
1. **The one message of the month** ("On-time delivery recovered; scrap is now the risk").
2. **Where we stand:** at most 3 numbers vs target.
3. **What changed:** good and bad, nothing hidden.
4. **So what:** in money or days.
5. **The asks:** decisions needed this month, each with a date.

## 8. Customer business review
1. **Purpose and the one message** ("Delivery is back above 97%; we propose two cost-down ideas").
2. **Their scorecard:** delivery, quality, responsiveness, as they measure it.
3. **Issues and what we did,** with evidence.
4. **What's next:** improvements, new parts, capacity.
5. **Commitments both sides, with dates.**

## 9. Complaint or quality update
1. **Status in one line** (contained / cause found / closed).
2. **Containment:** what protects the customer today.
3. **Cause:** what the evidence shows, nothing more.
4. **Corrective actions,** owners, dates, and how effectiveness will be checked.
5. **What changes so it doesn't happen again.**

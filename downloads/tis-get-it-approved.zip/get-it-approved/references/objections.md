# Handling the hard questions (in the room, or by email)

**The pattern for every objection: acknowledge, answer with evidence, return to the decision.** Don't defend, don't argue, don't over-explain. Short answers sound confident; long ones sound worried.

## From management
| They say | What they usually mean | How to answer |
|---|---|---|
| "We don't have budget." | "Convince me it's worth more than what else the money could do." | "Understood. That's why it's phased: phase 1 is RM 30,000 and pays back in 9 months. Can we approve phase 1 and decide phase 2 on the results?" |
| "Not now. Maybe next year." | "I don't feel the cost of waiting." | "Each month we wait costs about RM 8,500 in rework. Starting in January instead of July saves around RM 50,000. What would you need to see to start in January?" |
| "Is that saving real?" | "I don't trust your numbers." | "It's from three months of the rework log, and the conservative case, at 30% less, still pays back in 20 months. The assumptions are on page 4; happy to go through them." |
| "What if it doesn't work?" | "I don't want to own a failure." | "That's why there's a stop point: if scrap isn't below 2% by week 6, we stop. Worst case, we've spent RM 30,000 and we know for sure." |
| "Why not the cheaper option?" | "Show me you thought about it." | "Option A costs a third, but it fixes only one of the three causes, so payback is longer. The comparison is on page 3. I'd go with B, but A is a fair first step if cash is tight." |
| "We tried this before." | "Why is this time different?" | "We did, in 2019. It stopped because [the real reason]. This time [what's different], and [who] has agreed to [the support]." |
| "Your number is wrong." | Maybe it is. | "Thank you, let me check. Which figure are you looking at?" Then fix it, or show the source. Never argue a number you can't trace. |
| "Send me more detail." | Sometimes real; sometimes a soft no. | "Of course. What's the one thing that would let you decide? I'll send that by Thursday, and could we decide at next week's meeting?" |

## From customers
| They say | How to answer |
|---|---|
| "Can you do it cheaper?" | "The price stands, and I'm glad to walk you through how it's built. If cost is the priority, there are two options that lower it: [a larger batch] or [a longer lead time]." |
| "Why is it so late?" | The honest reason in one line, what's protecting them now, and the new date they can hold you to. |
| "Your competitor is cheaper." | "That may be. What we give you that matters for this part is [the evidence: delivery record, quality, support]. If you want, I can look at what we'd change to get closer." |
| "We need it by Friday." | What you can do by Friday, what you can't, and the earliest honest date for the rest. |

## Rehearsal drill (do it before every important meeting)
1. List the 5 hardest questions the decider and the blockers could ask.
2. Write a 2-sentence answer to each, with the evidence.
3. Mark the one number most likely to be challenged; have its source ready on a backup slide.
4. Say the ask out loud in under 60 seconds, as if you met the GM in the corridor.

# Chart chooser for factory and office data

First write the one sentence the chart must prove. Then pick the chart that proves it fastest. If a sentence proves it, use the sentence.

| What you need to show | Use | Factory example | Watch out |
|---|---|---|---|
| Ranking a few things | Bar chart, sorted big to small, axis from zero | Defects by machine, output by line | Never alphabetical unless people look things up |
| The vital few causes | Pareto: bars big to small + cumulative % line | NCR causes, downtime reasons | Group the tail as "others" |
| Change over time | Line chart | OTD by week, scrap rate by month | Mark events (a fix, a new shift) on the line |
| Against a target | Line or bars + a target line, labelled at the left end | OEE vs 85% target | Colour only the points that miss |
| Before vs after | Paired bars, before in grey, after in colour | Cycle time before and after a fixture | Same units, same period length |
| How a total splits | Stacked bar (one bar per period) | Downtime split by reason per month | Max 4 or 5 segments; pie only up to 3 slices |
| Age of work waiting | Bars by age bucket (0–7, 8–14, 15–30, 30+ days) | WIP ageing, open NCRs, overdue POs | The oldest bucket gets the accent |
| Where the time goes | Horizontal bars of hours by step | Lead time split by process | Sort by hours, not by process order, if the point is "biggest" |
| Payback of an investment | Cumulative cash line crossing zero | New cell, automation | Mark the payback month |
| Comparing options | A table, recommended row highlighted | Do nothing / small fix / full fix | A table beats a chart for 3–4 options |
| One big result | The number, big, with one line of context | "320 hours a month back" | Add the comparison: vs what? |
| Spread and outliers | Dot plot or box plot | Cycle time per part, delivery lateness | Explain the outliers in one label |
| Exact figures people look up | A clean table | Price list, capacity by machine | Right-align numbers, bold only the one that matters |

## Every chart, every time
- **Takeaway title** (see `titles.md`), not a topic title.
- **One accent colour** for the point; everything else grey.
- **Direct labels** on lines and bars instead of a legend.
- **Axis from zero** for bars. If a line chart's axis doesn't start at zero, say so.
- **Source and date** under the chart.
- **Nothing nobody acts on:** extra decimals, gridlines, 3D, shadows, logos on every slide.
- **The squint test:** blur your eyes. If the point doesn't survive, the chart isn't done.

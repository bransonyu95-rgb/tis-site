# The persuasion method: how a factory proposal gets a yes

Most proposals in a factory don't die because the idea is bad. They die because the person who decides couldn't see what was in it for them, didn't trust a number, or was asked to decide something big with no way back. This method fixes those three things before anyone opens a slide.

## 1. Know who really decides
Write down, before anything else:
| Who | Role in the decision | What they gain if it works | What they fear | What they believe today |
|---|---|---|---|---|
| (e.g. GM) | Decides | Margin, a win to report upward | Spending and nothing changing | "We tried automation in 2019 and it sat idle" |
| (e.g. Finance manager) | Can block | Cash kept, a payback they can defend | Numbers that won't hold | "Savings are always overstated" |
| (e.g. Production manager) | Must live with it | Fewer late nights | Disruption, losing people | "Another project dumped on my team" |

- The **decider** signs. The **blockers** can stop it without saying no out loud. The **users** make it work or fail after the yes.
- What they *believe today* matters most. If the GM believes "automation sits idle", your proposal must answer that belief on page one, not on page nine.

## 2. Talk to them before the meeting
Never let the meeting be the first time a decider or blocker sees your numbers. Show the key people the core number one to one, ask "what would make you uncomfortable with this?", and fix it before the room. A meeting should confirm a decision, not start one.

## 3. Answer the six questions every approver asks
In this order, because this is the order they think in:
1. **Why this?** The problem, in money or days, not in feelings. "Rework is costing RM 18,000 a month", not "quality issues are affecting us".
2. **Why now?** What it costs to wait. A month of delay has a price; name it.
3. **Why this option?** Show the options you rejected and why. A proposal with one option feels like a sales pitch. Three options (do nothing, a small fix, the full fix) feel like judgement.
4. **How much, and when do we get it back?** Cost, saving, payback in months, and the assumptions behind them, all in one place.
5. **What could go wrong?** Name the top 2 or 3 risks yourself, with what you'll do about each. If you don't, they will, and then you look like you hid them.
6. **What exactly do you need from me?** One decision, a number, a date. "Approve RM 120,000 for the cell by 30 Nov so we can order before the price change."

## 4. Make the yes small and safe
- **Offer a step, not a leap.** A pilot, a first phase, a trial on one line. "Approve phase 1 (RM 30,000, 8 weeks); phase 2 only if phase 1 cuts rework by half."
- **Give them a way out.** A stop point with a clear test ("if scrap isn't below 2% by week 6, we stop and lose only RM 30,000"). Deciders say yes faster when no is still possible later.
- **Give them control.** Let them choose between two good options rather than accept or reject one.

## 5. Lead with the answer
The busiest person in the room reads the first line and maybe the last. So the first line is the ask and the payback ("Approve the RM 120,000 cell: it pays back in 14 months from rework alone"). The rest is proof.

## 6. Earn trust with the numbers
- Conservative case first. If the conservative case pays, the proposal survives every challenge.
- Every assumption visible, every number traceable to a source.
- Don't round in your favour, don't mix bases (monthly vs yearly, cost vs selling price), and say what you don't know.
- One wrong number makes the room doubt every other number. One honest "we don't know yet, here's how we'll find out" makes them trust the rest.

## 7. Speak like someone who has decided
- Say "I recommend", not "maybe we could consider".
- Short sentences. Numbers, then meaning: "14 months payback. That's faster than the last two machines we bought."
- No hype words ("game-changer", "revolutionary"). Factory managers have heard them all and trust them less each time.
- When challenged, don't defend; answer: acknowledge, give the evidence, return to the decision (see `objections.md`).

## 8. Persuading a customer is the same, from their side
For a price increase, a new date or a change you need from a customer: their gain, their fear, their belief today. What it costs them if they say no (supply risk, a longer lead time), options they can choose between, and a small first step. Never show your internal costs or margin; show the reason they can see (material index, a cost they already know went up).

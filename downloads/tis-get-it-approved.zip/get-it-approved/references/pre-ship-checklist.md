# Pre-ship check: before it goes to anyone who decides

Mark each one ✓ or ✗. Fix every ✗ before you send or present.

## The message
1. Can you say the whole proposal, the ask included, in one sentence?
2. Is the ask in the first lines, not at the end?
3. Does every title state a takeaway, and do the titles alone tell the story?
4. One message per slide or page?

## The decider
5. Have you answered what the decider believes today?
6. Have the key people seen the core number before the meeting?
7. Are there options, with one clearly recommended and the reason?
8. Is the yes small and safe: a first step, a stop point, a test?

## The numbers
9. Is every number calculated from a source you can show?
10. Are all the assumptions in one table?
11. Is the conservative case shown, and does it still work (or do you say plainly that it doesn't)?
12. Running costs included? No saving counted twice? Same basis everywhere?
13. Rounded to what people decide on?
14. No `[CHECK]` left?

## The charts
15. Does each chart prove its title within 5 seconds?
16. One accent colour for the point, the rest grey?
17. Bars from zero, direct labels, source and date under each chart?
18. Everything nobody acts on, deleted?

## The ask and the room
19. Is the ask one decision, with an amount and a date, and why that date?
20. Are the risks named by you, each with a control and an owner?
21. Are the 5 hardest questions answered, and the most-challenged number on a backup slide?
22. Could you make the ask in 60 seconds in the corridor?

For a dashboard, also: every tile has an action rule (target, when to act, who) or is marked "for information"; the ACT TODAY band shows at most 3 items.

# Takeaway titles that do the persuading

A topic title tells people what the slide is about. A takeaway title tells them what to conclude. The second one does half your presenting before you speak.

## Formulas
1. **Number + direction + cause:** "Scrap fell to 1.8% after the new fixture"
2. **Cost of the problem:** "Rework is costing us RM 18,000 a month"
3. **Payback:** "The deburr cell pays back in 14 months"
4. **Cost of waiting:** "Every month we delay costs RM 8,500"
5. **The comparison that matters:** "Line 3 makes 58% of all defects"
6. **The choice:** "Option B gives 80% of the saving for 40% of the cost"
7. **The risk, named:** "The only real risk is volume, and we break even at 70% of forecast"
8. **The ask:** "Approve RM 30,000 for an 8-week pilot by 30 Nov"
9. **The before and after:** "Quote turnaround went from 5 days to 1"
10. **The belief, answered:** "Unlike 2019, this cell runs on parts we already make every day"

## Before and after
| Topic title (weak) | Takeaway title (strong) |
|---|---|
| Delivery performance Q3 | On-time delivery recovered to 96% after the layout change |
| Downtime analysis | Two machines cause 70% of our downtime |
| Investment proposal: deburr cell | A RM 120,000 deburr cell pays back in 14 months from rework alone |
| Customer price review | From 1 January, prices rise 4% in line with the aluminium index |
| Headcount request | One planner frees 60 hours a month of engineers' time |
| Project status | Phase 1 is on time; phase 2 needs the PO by 15 Dec |

## Rules
- 12 words or fewer. A number in it whenever there is one.
- Only claim what the data shows. "After" is fine if the timing is shown; "because" needs evidence.
- One title per slide, one message per title. Two messages, two slides.
- Read all your titles in a row: they should tell the whole story on their own.

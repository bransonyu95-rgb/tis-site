# Numbers that persuade (and survive the finance manager)

**Every number is calculated with a script from the user's own figures, never by eye. Every assumption goes in the assumptions table. Nothing is invented: a missing figure is `[CHECK: ...]`.**

## The five numbers most approvers want
| Number | How to calculate | Say it like |
|---|---|---|
| **Payback** | Investment ÷ net saving per month | "Pays back in 14 months" |
| **Return (ROI)** | (Total net saving over the period − investment) ÷ investment, over a stated period (e.g. 3 years) | "Returns 2.5 times its cost over 3 years" |
| **Cost of waiting** | Net saving per month (or loss per month) × months of delay | "Every month we wait costs RM 8,500" |
| **Break-even volume** | Fixed cost ÷ (price − variable cost per unit) | "We break even at 1,800 pieces a month; we're forecast at 2,600" |
| **Cost of the problem today** | Units affected × cost per unit, or hours × cost per hour, per month | "Rework costs RM 18,000 a month" |

Net saving = the saving **minus** the new running costs (maintenance, power, consumables, licences, extra people). Forgetting running costs is the most common way a payback gets torn apart.

## The assumptions table (always show it)
| Assumption | Value | Source | How sure |
|---|---|---|---|
| Rework hours saved per month | 320 h | Rework log, Jul–Sep average | Measured |
| Cost per hour, loaded | RM 25 | HR rate card | Given |
| Maintenance per year | RM 6,000 | Supplier quote | Quoted |
| Volume next year | 2,600 pcs/month | Customer forecast | Forecast, may change |

## Show a conservative case, and say what happens if you're wrong
- Present the **conservative case first** (e.g. savings 30% lower, volume 20% lower). If it still pays, say so: "Even if savings come in 30% lower, payback is 20 months."
- A short **sensitivity line** beats a complex model: "Payback is 14 months at forecast volume, 18 months at minus 20%, and never if volume halves."
- If the case only works in the best case, say that honestly and propose a smaller first step.

## Rules that keep trust
- **Same basis everywhere.** Don't put monthly next to yearly, cost next to selling price, or this year's figure next to last year's without saying so.
- **Round to what people decide on:** RM 120,000, not RM 119,873.50; 14 months, not 13.7.
- **Name every estimate as an estimate.** "Estimated from 3 months of the rework log" is stronger than a precise-looking number nobody can trace.
- **People freed up are only cash if money stops going out.** If payroll falls, or a hire you would really have made is no longer needed, it's a cash saving. If the people move to other work and nothing else changes in spending, it's capacity, not cash: say "frees 2 people for the CNC line (worth RM 6,000 a month only if it replaces a hire we would otherwise make)". Finance managers check this first.
- **Don't count the same saving twice** (fewer rework hours and less overtime may be the same money).
- **Time value of money:** for paybacks over about 3 years, or when finance asks, add a simple discounted payback or NPV at the company's rate. Ask for the rate; never assume one.
- **Never present an invented number to make a case work.** If a figure is missing, the deck shows `[CHECK: ...]` and the user gets it before the meeting.

## The charts that carry these numbers
- **Cumulative cash line:** starts below zero at the investment, rises month by month, crosses zero at payback. Mark the crossing.
- **Options table:** one row per option, columns for cost, saving, payback, risk. Highlight the recommended row.
- **Cost of the problem:** a simple trend of the monthly cost, with the target or the after-state as a dashed line.

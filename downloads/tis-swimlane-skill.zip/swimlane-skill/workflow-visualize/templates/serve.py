"""
Standalone local server for workflow-visualize (use it when the project has no dashboard server of its own;
otherwise copy the four routes below into that server).

Serves workflow_trace.html and its read-only API. Python 3, standard library only. Binds 127.0.0.1 ONLY.
Run from the project folder (so trace_build finds that project's transcripts):
    python serve.py [--port 8090]
Routes:
  GET /                      -> workflow_trace.html
  GET /api/trace             -> recent runs            ?run=<sid>:<turn> one run   ?case=<id> runs touching an entity
                                                        ?with_cases=1 attended runs that touched any entity
  GET /api/file?key=<key>    -> a rule file from RULE_FILES (whitelist by key, never a free path)
  GET /api/version           -> changes when the page file changes, so open tabs reload themselves
"""
import argparse
import datetime as dt
import hashlib
import io
import json
import os
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import trace_build  # noqa: E402

PAGE = os.path.join(HERE, "workflow_trace.html")
# key -> file the Workflow step details may show. ADAPT: list only files you are happy to display.
RULE_FILES = {
    # "task_skill": os.path.join(os.path.expanduser("~"), ".claude", "scheduled-tasks", "my-scheduled-task", "SKILL.md"),
    # "rules": os.path.join(os.getcwd(), "rules.md"),
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        host = (self.headers.get("Host") or "").lower()
        if host not in self.server.allowed_hosts:          # DNS-rebinding guard
            return self._json(403, {"ok": False, "error": "bad host"})
        u = urlparse(self.path)
        qs = parse_qs(u.query)
        if u.path in ("/", "/workflow_trace.html"):
            body = io.open(PAGE, "rb").read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return self.wfile.write(body)
        if u.path == "/api/trace":
            try:
                case_id, run_id = qs.get("case", [""])[0], qs.get("run", [""])[0]
                if case_id:
                    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", case_id):
                        return self._json(400, {"ok": False, "error": "bad id"})
                    return self._json(200, trace_build.list_runs(days=14, limit=10, case=case_id))
                if qs.get("with_cases", [""])[0] == "1":
                    return self._json(200, trace_build.list_runs(limit=15, with_cases=True))
                if run_id:
                    run = trace_build.get_run(run_id)
                    return self._json(404, {"ok": False, "error": "run not found"}) if run is None else self._json(200, run)
                return self._json(200, trace_build.list_runs())
            except Exception as e:
                return self._json(500, {"ok": False, "error": f"trace failed: {e}"})
        if u.path == "/api/file":
            path = RULE_FILES.get(qs.get("key", [""])[0])
            if not path or not os.path.isfile(path):
                return self._json(404, {"ok": False, "error": "unknown file"})
            text = io.open(path, encoding="utf-8", errors="replace").read()
            st = os.stat(path)
            return self._json(200, {"ok": True, "path": path, "text": text[-60000:], "truncated": len(text) > 60000,
                                    "modified": dt.datetime.fromtimestamp(st.st_mtime, dt.timezone.utc).isoformat()})
        if u.path == "/api/version":
            st = os.stat(PAGE)
            return self._json(200, {"v": hashlib.sha1(f"{st.st_mtime_ns}:{st.st_size}".encode()).hexdigest()[:12]})
        return self._json(404, {"ok": False, "error": "not found"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8090)
    a = ap.parse_args()
    httpd = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    httpd.allowed_hosts = {f"127.0.0.1:{a.port}", f"localhost:{a.port}"}
    print(f"Workflow + Trace on http://localhost:{a.port}  (transcripts: {trace_build.PROJECT_DIR})")
    httpd.serve_forever()


if __name__ == "__main__":
    main()

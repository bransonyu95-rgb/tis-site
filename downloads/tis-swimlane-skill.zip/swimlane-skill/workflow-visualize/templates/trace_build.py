"""
Trace builder for workflow-visualize: rebuilds what ACTUALLY ran from Claude Code's own session transcripts.

Read-only. Standard library only. Nothing leaves this PC.
Source: ~/.claude/projects/<project-dir>/*.jsonl  (one file per session, written by Claude Code)
        plus <session>/subagents/agent-*.jsonl + .meta.json for subagent runs.
<project-dir> is the project folder path with ':', '\\', '/' and ' ' turned into '-'
(C:\\Users\\me\\Desktop\\My Project -> C--Users-me-Desktop-My-Project). Set PROJECT_DIR below or env WV_PROJECT_DIR.

A "run" is one scheduled-task session or one prompt typed in an attended session. Each run becomes swimlane
stages: consecutive tool calls of the same kind, in the lane of whoever did them (the model that answered,
a subagent's model, or Scripts for known pipeline scripts).

ADAPT PER PROJECT: PROJECT_DIR, ROUTINE_TASK, classify() keys/patterns, TITLES, SCRIPT_KEYS, _checks(), ENTITY_DIR.
CLI:  python trace_build.py              # list recent runs
      python trace_build.py --run <id>   # one run with stages and checks
"""
import argparse
import datetime as dt
import glob
import io
import json
import os
import re
import sys
import threading
import time

def project_dir_for(path):
    """Claude Code transcript folder for a project folder."""
    return os.path.join(os.path.expanduser("~"), ".claude", "projects", re.sub(r"[:\\/ ]", "-", path))


PROJECT_DIR = os.environ.get("WV_PROJECT_DIR") or project_dir_for(os.getcwd())
ROUTINE_TASK = os.environ.get("WV_ROUTINE_TASK", "my-scheduled-task")   # the scheduled task the checks are about
SEND_SCRIPT = os.environ.get("WV_SEND_SCRIPT", "mailer.py")   # the ONE script in your project that could send mail/messages
DAYS = 7
SNIP = 240
MAX_CALLS_PER_STAGE = 80
LIVE_SECONDS = 120

_cache = {}          # path -> (mtime, size, parsed session)
_lock = threading.Lock()


# ---------- small helpers ----------
def _ts(s):
    try:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


def _iso(d):
    return d.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if d else None


def _text_of(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for x in content:
            if isinstance(x, dict):
                if x.get("type") == "text":
                    out.append(x.get("text", ""))
                elif x.get("type") == "tool_result":
                    out.append(_text_of(x.get("content")))
        return "\n".join(out)
    return ""


def _short(s, n=SNIP):
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[: n - 1] + "…"


def model_name(m):
    """claude-opus-5-5 -> Opus 5.5 ; claude-haiku-4-5-20251001 -> Haiku 4.5"""
    if not m:
        return "unknown model"
    x = re.match(r"claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?!\d)", m)
    if x:
        return f"{x.group(1).capitalize()} {x.group(2)}" + (f".{x.group(3)}" if x.group(3) else "")
    return m


def family(m):
    m = (m or "").lower()
    for f in ("opus", "sonnet", "haiku", "fable"):
        if f in m:
            return f
    return "other"


def _is_prompt(r):
    """A record that is something YOU (or a scheduled task) said, not a tool result or injected context."""
    if r.get("type") != "user" or r.get("isMeta") or r.get("isSidechain"):
        return False
    m = r.get("message")
    if not isinstance(m, dict):
        return False
    c = m.get("content")
    if isinstance(c, str):
        text = c
    elif isinstance(c, list) and c and all(isinstance(x, dict) and x.get("type") in ("text", "image") for x in c):
        text = _text_of(c)
    else:
        return False
    t = text.lstrip()
    if not t or t.startswith(("<system-reminder", "<local-command", "<command-name", "Caveat:", "[Request interrupted")):
        return False
    return True


# ---------- parse one transcript file ----------
def _parse_file(path):
    """Returns {records: [...minimal...]} in file order."""
    recs = []
    with io.open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            t = r.get("type")
            if t not in ("user", "assistant"):
                continue
            m = r.get("message") if isinstance(r.get("message"), dict) else {}
            rec = {"type": t, "ts": r.get("timestamp"), "prompt": None, "model": m.get("model"), "mid": m.get("id"),
                   "usage": m.get("usage") if t == "assistant" else None, "uses": [], "results": [], "text": None}
            if t == "user" and _is_prompt(r):
                rec["prompt"] = _text_of(m.get("content"))
            c = m.get("content")
            if isinstance(c, list):
                for x in c:
                    if not isinstance(x, dict):
                        continue
                    if x.get("type") == "tool_use":
                        rec["uses"].append({"id": x.get("id"), "name": x.get("name"), "input": x.get("input") or {}})
                    elif x.get("type") == "tool_result":
                        rec["results"].append({"id": x.get("tool_use_id"), "error": bool(x.get("is_error")),
                                               "text": _short(_text_of(x.get("content")))})
                    elif x.get("type") == "text" and t == "assistant":
                        rec["text"] = (rec["text"] or "") + x.get("text", "")
            recs.append(rec)
    return recs


def _load(path):
    try:
        st = os.stat(path)
    except OSError:
        return None
    with _lock:
        hit = _cache.get(path)
        if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
            return hit[2]
    recs = _parse_file(path)
    with _lock:
        _cache[path] = (st.st_mtime, st.st_size, recs)
    return recs


def _subagents(session_dir):
    """toolUseId -> {type, description, file}"""
    out = {}
    for meta in glob.glob(os.path.join(session_dir, "subagents", "*.meta.json")):
        try:
            d = json.load(io.open(meta, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if d.get("toolUseId"):
            out[d["toolUseId"]] = {"type": d.get("agentType") or "agent", "description": d.get("description") or "",
                                   "file": meta[: -len(".meta.json")] + ".jsonl"}
    return out


# ---------- classification: tool call -> swimlane box ----------
# EXAMPLE RULES for a simple "collect -> decide -> check -> publish -> notify" task. Replace them with your own
# workflow's steps and keep the keys in step with MAPKEY in workflow_trace.html.
# (key, what to test, regex). "cmd" = shell commands, "path" = files read or searched, "write" = files written.
# The first match wins, so put the bigger step first when one command does two things.
RULES = [
    ("collect",  "cmd",   r"export\.py|collect\.py"),
    ("validate", "cmd",   r"check\.py|validate\.py"),
    ("publish",  "cmd",   r"publish\.py"),
    ("start",    "cmd",   r"status\.py\S*\s+set\s+\S+\s+working"),
    ("log",      "cmd",   r"status\.py|notify\.ps1|run_log"),
    ("rules",    "path",  r"skill\.md|claude\.md|scheduled-tasks|rules\.md"),
    ("read",     "path",  r"/data/|scratchpad"),
    ("calls",    "write", r"/out/|/ops/"),
]
SCRIPT_KEYS = {"collect", "validate", "publish", "send"}      # shown in the Scripts lane (no AI)
TITLES = {
    "start": "Start run", "collect": "Collect data", "read": "Read inputs", "rules": "Read rules",
    "calls": "Make the calls", "validate": "Check", "publish": "Publish", "log": "Log + notify",
    "look": "Look up files", "build": "Build / edit files", "plan": "Plan + tasks", "app": "Desktop + browser",
    "other": "Other commands", "send": "SEND COMMAND",
}
NOT_ON_MAP = set()   # keys of real steps that have no box on the Workflow yet (shown dashed)


_HEREDOC = re.compile(r"<<-?\s*(['\"]?)(\w+)\1[^\n]*\n.*?\n\s*\2\s*(?=\n|$)", re.S)
_HERESTRING = re.compile(r"@(['\"])\n.*?\n\1@", re.S)
_OPS = {";", "&&", "||", "|", "&", "(", ")"}


def _strip_bodies(cmd):
    """Drop heredoc / here-string bodies: text written INTO a file is not a command being run."""
    cmd = _HEREDOC.sub(" ", cmd)
    return _HERESTRING.sub(" ", cmd)


def _segments(cmd):
    """Shell-aware split into simple commands; quoted strings stay one token. None if it cannot be parsed."""
    import shlex
    try:
        lex = shlex.shlex(cmd.replace("\\", "/").replace("\n", " ; "), posix=True, punctuation_chars=";&|()")
        lex.whitespace_split = True
        toks = list(lex)
    except ValueError:
        return None
    segs, cur = [], []
    for t in toks:
        if t in _OPS or set(t) <= set(";&|()"):
            if cur:
                segs.append(cur)
            cur = []
        else:
            cur.append(t)
    if cur:
        segs.append(cur)
    return segs


def is_send(name, inp):
    """True when a call could actually send mail or a meeting. Errs on the side of flagging."""
    n = (name or "").lower()
    if n.startswith("mcp__") and "send" in n and not n.startswith("mcp__ccd_"):   # e.g. mcp__outlook__send-email; ccd_* = messages between Claude sessions
        return True
    if name not in ("Bash", "PowerShell"):
        return False
    cmd = _strip_bodies(inp.get("command") or "")
    if name == "PowerShell" and re.search(r"\.send\s*\(", cmd, re.I):
        return True
    segs = _segments(cmd)
    if segs is None:                                     # unparseable: fall back to a coarse but safe match
        return bool(re.search(re.escape(SEND_SCRIPT) + r"\b.*\bsend\b|\s--sen?d?\b|\.send\s*\(", cmd, re.I | re.S))
    has_bridge = SEND_SCRIPT in cmd.lower()
    runners = ("python", "py", "powershell", "pwsh", "cscript", "wscript", "node")
    for seg in segs:
        words = [w for w in seg if not re.match(r"^[A-Za-z_]\w*=", w)]          # skip VAR=value prefixes
        exe = os.path.basename(words[0].lower()) if words else ""
        if exe.endswith(".exe"):
            exe = exe[:-4]
        if exe.startswith(runners) and any(re.search(r"\.send\s*\(", w, re.I) for w in words[1:]):
            return True                                  # e.g. a mail COM object's .Send() run inline
        for i, t in enumerate(seg):
            tl = t.lower()
            target = tl.endswith(SEND_SCRIPT) or (tl.startswith("$") and has_bridge)
            if not target:
                continue
            prev = seg[i - 1].lower() if i else ""
            if i and "py" not in prev and not prev.startswith("$"):
                continue                                 # the send script as an argument (grep, cat, sed …) is not a run
            for a in seg[i + 1:]:
                al = a.lower().split("=", 1)[0]
                if al == "send":
                    return True
                if len(al) >= 4 and al.startswith("--se") and "--send".startswith(al):   # argparse accepts --se/--sen
                    return True
    return False


def classify(name, inp):
    if is_send(name, inp):
        return "send"
    if name in ("Bash", "PowerShell"):
        c = (inp.get("command") or "").replace("\\", "/")
        if re.fullmatch(r'\s*cd\s+("[^"]*"|\S+)\s*', c):
            return "skip"                      # bare cd: no work
        for key, kind, rx in RULES:
            if kind == "cmd" and re.search(rx, c, re.I):
                return key
        return "other"
    p = (inp.get("file_path") or inp.get("path") or inp.get("pattern") or "").replace("\\", "/")
    if name in ("Read", "Grep", "Glob"):
        for key, kind, rx in RULES:
            if kind == "path" and re.search(rx, p, re.I):
                return key
        return "look"
    if name in ("Write", "Edit", "NotebookEdit"):
        for key, kind, rx in RULES:
            if kind == "write" and re.search(rx, p, re.I):
                return key
        return "build"
    if name in ("TodoWrite", "update_plan", "ToolSearch", "Skill"):
        return "plan"
    if name.startswith("mcp__computer-use") or "Browser" in name or name.startswith("mcp__claude-in-chrome"):
        return "app"
    return "other"


def describe(name, inp):
    if name in ("Bash", "PowerShell"):
        d = inp.get("description") or ""
        return d, (inp.get("command") or "")[:400]
    if name in ("Read", "Write", "Edit"):
        return name, inp.get("file_path") or ""
    if name in ("Grep", "Glob"):
        return name, f'{inp.get("pattern", "")}  in  {inp.get("path", "")}'
    if name == "Agent":
        return inp.get("description") or "Agent", f'{inp.get("subagent_type", "general")}: {_short(inp.get("prompt", ""), 300)}'
    return name, _short(json.dumps(inp, ensure_ascii=False), 300)


# ---------- runs ----------
def _session_runs(path):
    recs = _load(path)
    if not recs:
        return []
    sid = os.path.basename(path)[:-6]
    first_prompt = next((r["prompt"] for r in recs if r["prompt"]), "") or ""
    m = re.match(r'\s*<scheduled-task name="([^"]+)"', first_prompt)
    task = m.group(1) if m else None
    # split points
    if task:
        cuts = [0]
    else:
        cuts = [i for i, r in enumerate(recs) if r["prompt"]]
        if not cuts:
            return []
    runs = []
    for n, a in enumerate(cuts):
        b = cuts[n + 1] if n + 1 < len(cuts) else len(recs)
        chunk = recs[a:b]
        if not any(r["uses"] for r in chunk):
            continue
        runs.append({"sid": sid, "turn": n, "task": task, "path": path, "recs": chunk,
                     "prompt": chunk[0]["prompt"] if chunk[0]["prompt"] else first_prompt})
    return runs


def _summarize(run, detail=False):
    recs = run["recs"]
    times = [_ts(r["ts"]) for r in recs if r["ts"]]
    times = [t for t in times if t]
    start, end = (min(times), max(times)) if times else (None, None)
    models, tokens, seen_mid = {}, {}, set()
    calls, results = [], {}
    final_text = None
    for r in recs:
        for res in r["results"]:
            results[res["id"]] = (res, r["ts"])
    for r in recs:
        if r["type"] == "assistant" and r["model"] and r["model"] != "<synthetic>":
            if r["mid"] not in seen_mid:
                seen_mid.add(r["mid"])
                models[r["model"]] = models.get(r["model"], 0) + 1
                u = r["usage"] or {}
                t = tokens.setdefault(r["model"], {"in": 0, "out": 0, "cache": 0})
                t["in"] += int(u.get("input_tokens") or 0) + int(u.get("cache_creation_input_tokens") or 0)
                t["out"] += int(u.get("output_tokens") or 0)
                t["cache"] += int(u.get("cache_read_input_tokens") or 0)
            if r["text"] and r["text"].strip():
                final_text = r["text"].strip()
        for u in r["uses"]:
            res, rts = results.get(u["id"], (None, None))
            calls.append({"id": u["id"], "name": u["name"], "input": u["input"], "model": r["model"],
                          "t0": r["ts"], "t1": rts, "error": bool(res and res["error"]),
                          "result": res["text"] if res else "(no result yet)"})
    errors = sum(1 for c in calls if c["error"])
    live = bool(end and (dt.datetime.now(dt.timezone.utc) - end).total_seconds() < LIVE_SECONDS)
    main_model = max(models, key=models.get) if models else None
    title = run["prompt"]
    if run["task"]:
        title = run["task"]
    summary = {
        "id": f'{run["sid"]}:{run["turn"]}', "kind": "scheduled" if run["task"] else "attended", "task": run["task"],
        "title": _short(re.sub(r"<[^>]+>", " ", title or ""), 120), "start": _iso(start), "end": _iso(end),
        "seconds": int((end - start).total_seconds()) if start and end else 0, "live": live,
        "models": {model_name(k): v for k, v in models.items()}, "main_model": model_name(main_model),
        "calls": len(calls), "errors": errors,
        "agents": sum(1 for c in calls if c["name"] in ("Agent", "Task")),
        "result": _short(final_text or "", 300),
    }
    if not detail:
        return summary
    summary["prompt"] = _short(re.sub(r"<[^>]+>", " ", run["prompt"] or ""), 900)
    summary["tokens"] = {model_name(k): v for k, v in tokens.items()}
    summary["result_full"] = (final_text or "")[:3000]
    sub = _subagents(os.path.join(os.path.dirname(run["path"]), run["sid"]))
    summary.update(_stages(run, calls, main_model, sub))
    summary["checks"] = _checks(summary, calls)
    return summary


def _agent_detail(info):
    recs = _load(info["file"]) if info and os.path.isfile(info["file"]) else None
    if not recs:
        return None
    models, calls, times, results, seen = {}, [], [], {}, set()
    tok = {"in": 0, "out": 0, "cache": 0}
    for r in recs:
        if r["ts"]:
            t = _ts(r["ts"])
            if t:
                times.append(t)
        for res in r["results"]:
            results[res["id"]] = res
    for r in recs:
        if r["type"] == "assistant" and r["model"] and r["model"] != "<synthetic>" and r["mid"] not in seen:
            seen.add(r["mid"])
            models[r["model"]] = models.get(r["model"], 0) + 1
            u = r["usage"] or {}
            tok["in"] += int(u.get("input_tokens") or 0) + int(u.get("cache_creation_input_tokens") or 0)
            tok["out"] += int(u.get("output_tokens") or 0)
            tok["cache"] += int(u.get("cache_read_input_tokens") or 0)
        for u in r["uses"]:
            res = results.get(u["id"])
            what, how = describe(u["name"], u["input"])
            calls.append({"tool": u["name"], "what": what, "how": how, "t0": r["ts"], "error": bool(res and res["error"]),
                          "result": res["text"] if res else "", "send": is_send(u["name"], u["input"])})
    m = max(models, key=models.get) if models else None
    return {"model": model_name(m), "family": family(m), "calls": calls[:MAX_CALLS_PER_STAGE], "n_calls": len(calls),
            "sends": sum(1 for c in calls if c["send"]),
            "errors": sum(1 for c in calls if c["error"]), "tokens": tok,
            "start": _iso(min(times)) if times else None, "end": _iso(max(times)) if times else None}


def _stages(run, calls, main_model, sub):
    lanes, order = {}, []

    def lane(lid, name, subtitle, fam):
        if lid not in lanes:
            lanes[lid] = {"id": lid, "name": name, "sub": subtitle, "family": fam}
            order.append(lid)
        return lid

    role = "routine" if run["task"] == ROUTINE_TASK else (run["task"] or "main session")
    stages = []
    if not run["task"]:
        lane("you", "You", "asked", "you")
        stages.append({"key": "prompt", "title": "You asked", "lane": "you", "start": run["recs"][0]["ts"],
                       "end": run["recs"][0]["ts"], "calls": [], "n_calls": 0, "errors": 0,
                       "note": _short(re.sub(r"<[^>]+>", " ", run["prompt"] or ""), 900)})
    for c in calls:
        key = classify(c["name"], c["input"])
        if key == "skip":
            continue
        if key == "rules" and run["task"]:
            key = "start"
        what, how = describe(c["name"], c["input"])
        item = {"tool": c["name"], "what": what, "how": how, "t0": c["t0"], "t1": c["t1"], "error": c["error"],
                "result": c["result"], "by": model_name(c["model"])}
        if c["name"] in ("Agent", "Task"):
            info = sub.get(c["id"])
            det = _agent_detail(info)
            atype = (info or {}).get("type") or c["input"].get("subagent_type") or "agent"
            fam = det["family"] if det else "other"
            lid = lane(f"agent:{fam}", det["model"] if det else "Subagent", "subagents", fam)
            # background agents return at once, so time the box by the agent's own transcript when we have it
            stages.append({"key": "agent", "title": f"{atype}", "lane": lid, "start": c["t0"],
                           "end": (det or {}).get("end") or c["t1"],
                           "calls": [item], "n_calls": 1, "errors": int(c["error"]), "agent": det,
                           "note": what})
            continue
        if key in SCRIPT_KEYS:
            lid = lane("script", "Scripts", "no AI · issued by the model", "script")
        else:
            lid = lane(f"m:{c['model']}", model_name(c["model"]), role, family(c["model"]))
        last = stages[-1] if stages else None
        if last and last["key"] == key and last["lane"] == lid:
            last["end"] = c["t1"] or c["t0"]
            last["n_calls"] += 1
            last["errors"] += int(c["error"])
            if len(last["calls"]) < MAX_CALLS_PER_STAGE:
                last["calls"].append(item)
        else:
            stages.append({"key": key, "title": TITLES.get(key, key), "lane": lid, "start": c["t0"],
                           "end": c["t1"] or c["t0"], "calls": [item], "n_calls": 1, "errors": int(c["error"]),
                           "offmap": key in NOT_ON_MAP})
    # lane order: you, main model(s), subagents, scripts
    rank = {"you": 0, "script": 9}
    ordered = sorted(order, key=lambda l: rank.get(l, 5 if l.startswith("agent:") else 1))
    return {"lanes": [lanes[l] for l in ordered], "stages": stages}


def _checks(s, calls):
    """Design-vs-reality checks shown above the swimlane. Keep the send check; add what YOUR workflow promises."""
    out = []
    if s["kind"] == "scheduled":
        out.append(("info", f'The run itself was answered by {", ".join(sorted(s["models"])) or "no model"} '
                            f'({sum(s["models"].values())} replies).'))
    agents = [st for st in s.get("stages", []) if st["key"] == "agent"]
    send_results = [c["result"] or "" for c in calls if is_send(c["name"], c["input"])]
    for a in agents:
        send_results += [c["result"] or "" for c in (a.get("agent") or {}).get("calls", []) if c.get("send")]
    blocked = [r for r in send_results if re.search(r"disabled|not allowed|refused", r, re.I)]
    if not send_results:
        out.append(("ok", "No send command, in the main session or any subagent." if agents else "No send command. Nothing was sent."))
    elif len(blocked) == len(send_results):
        out.append(("warn", f"{len(send_results)} send command(s) ran, and the send script refused every one. Nothing went out."))
    else:
        out.append(("bad", f"{len(send_results) - len(blocked)} command(s) that can send were not refused. Open the STOP box and check what went out."))
    if agents:
        out.append(("info", f'{len(agents)} subagent run(s): ' + ", ".join(f'{a["title"]} on {(a.get("agent") or {}).get("model", "?")}' for a in agents)))
    if s["task"] == ROUTINE_TASK:
        checked = any(st["key"] == "validate" for st in s.get("stages", []))
        out.append(("ok", "The check step ran.") if checked else ("warn", "The check step never ran."))
        toast = [c for c in calls if "notify.ps1" in (c["input"].get("command") or "")]
        m = re.search(r'-Message\s+"([^"]*)"', toast[0]["input"]["command"]) if toast else None
        out.append(("info", "Notification: " + (_short(m.group(1), 160) if m else "yes") if toast else "No notification this run."))
    if s["errors"]:
        out.append(("warn", f'{s["errors"]} command(s) failed (see red boxes). Most are retried in the next step.'))
    return [{"level": a, "text": b} for a, b in out]


# Optional: a folder with one JSON file per entity (case, project, customer); runs are tagged with the ids they touch.
CASES_DIR = os.environ.get("WV_ENTITY_DIR", "")   # e.g. a folder of cases/projects/customers, one <id>.json each
_CASE_PATTERNS = [re.compile(r'"case"\s*:\s*"([A-Za-z0-9_.-]+)"'), re.compile(r'--case[= ]+"?([A-Za-z0-9_.-]+)'),
                  re.compile(r'--id\s+"?([a-z0-9][A-Za-z0-9_.-]+)'), re.compile(r'work on ([a-z0-9][a-z0-9_.-]+)', re.I)]


def _known_cases():
    try:
        return {f[:-5] for f in os.listdir(CASES_DIR) if f.endswith(".json") and not f.startswith("_")}
    except OSError:
        return set()


def _cases_touched(run, known):
    """Case ids this run read or wrote: ops files written, --case arguments, and 'work on <id>' in your prompt."""
    texts = [run["prompt"] or ""] if not run["task"] else []
    for r in run["recs"]:
        for u in r["uses"]:
            inp = u["input"]
            texts.append(inp.get("command") or "")
            if u["name"] in ("Write", "Edit"):
                texts.append(inp.get("content") or inp.get("new_string") or "")
    found = set()
    for t in texts:
        for pat in _CASE_PATTERNS:
            found.update(m.group(1).lower() for m in pat.finditer(t))
    return sorted(found & known)


def _recent_files(days):
    cutoff = time.time() - days * 86400
    files = []
    for p in glob.glob(os.path.join(PROJECT_DIR, "*.jsonl")):
        try:
            if os.path.getmtime(p) >= cutoff:
                files.append(p)
        except OSError:
            pass
    return files


def list_runs(days=DAYS, limit=60, case=None, with_cases=False):
    runs, known = [], _known_cases()
    for p in _recent_files(days):
        for r in _session_runs(p):
            sm = _summarize(r)
            sm["cases"] = _cases_touched(r, known)
            if case and case not in sm["cases"]:
                continue
            if with_cases and not (sm["kind"] == "attended" and sm["cases"]):
                continue
            runs.append(sm)
    runs.sort(key=lambda x: x["start"] or "", reverse=True)
    cutoff = _iso(dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days))
    runs = [r for r in runs if (r["start"] or "") >= cutoff][:limit]
    return {"generated": _iso(dt.datetime.now(dt.timezone.utc)), "days": days, "runs": runs}


def get_run(run_id):
    if not isinstance(run_id, str) or not re.fullmatch(r"[0-9a-f-]{36}:\d{1,5}", run_id):
        return None
    sid, turn = run_id.split(":")
    path = os.path.join(PROJECT_DIR, sid + ".jsonl")
    if not os.path.isfile(path):
        return None
    for r in _session_runs(path):
        if r["turn"] == int(turn):
            return _summarize(r, detail=True)
    return None


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--run")
    ap.add_argument("--days", type=int, default=DAYS)
    a = ap.parse_args()
    t = time.time()
    if a.run:
        d = get_run(a.run)
        if not d:
            print("run not found"); sys.exit(1)
        print(json.dumps({k: d[k] for k in ("id", "title", "main_model", "calls", "errors", "seconds", "checks", "tokens")}, ensure_ascii=False, indent=1))
        for st in d["stages"]:
            print(f'{(st["start"] or "")[11:19]}  {st["lane"]:28} {st["title"]:24} calls={st["n_calls"]:3} err={st["errors"]}')
    else:
        d = list_runs(a.days)
        for r in d["runs"][:25]:
            print(f'{r["start"]}  {r["kind"]:9} {r["main_model"]:10} {r["seconds"]:5}s calls={r["calls"]:3} err={r["errors"]} ag={r["agents"]} {"LIVE " if r["live"] else ""}{r["title"][:70]}')
        print(len(d["runs"]), "runs")
    print(f"{time.time() - t:.1f}s", file=sys.stderr)

---
name: workflow-visualize
description: Build a "Workflow + Trace" swimlane view of any Claude Code automation (scheduled task, routine, agent team, chat workflow). Workflow shows how it SHOULD run (lanes = who does the work - you, each model, scripts with no AI; click a box, then each inside step, for details, the last real example and the rule files). Trace shows what ACTUALLY ran, rebuilt read-only from Claude Code's own session transcripts (real model per lane, every command and result, design-vs-reality checks), with jump links between the two. Use whenever the user says "workflow visualize", "swimlane", "show me how X works", "which model ran", "what did the task actually do", "trace", "map vs reality", or "visualize my automation/agents/workflow".
---

# Workflow Visualize: Workflow (designed) + Trace (actual), as swimlanes

## What it is (explain it this way)
One page, two buttons: **Workflow | Trace** (Trace on the right).
- **Workflow** = how the automation should run. A swimlane read left to right; each lane is whoever does the work
  (You, the model, a subagent model, Scripts with no AI). Click a box: Goes in / What happens inside / Comes out /
  Files / Safety rules. Each inside step has **▸ details**: a plain explanation, the **last real run** of that step
  (command and result, from the trace) and buttons that open the rule files it follows.
- **Trace** = what really ran, rebuilt from Claude Code's session logs on this computer. Same swimlane, but lanes carry
  the model **as recorded**, boxes are real steps, red = failed. Same detail layout. Checks above it say where reality
  and design differ (send commands, the check step, subagents, steps that are not on the Workflow).
- Jump links both ways: "See the designed step →" and "See it in a real run →". Optional: per entity (case,
  customer, project) a list of the runs that touched it, linking into the Trace.

Why it matters: a first trace typically finds that the design and reality have drifted. Typical findings: a helper
model the design promised is never used, a step runs that is not on the map, and an unpinned scheduled task silently
switches models whenever the app default changes. The Workflow and the Trace together keep the setup honest.

## Rules
- **Local by default.** Transcripts hold real conversations and data. The trace is read-only, served on 127.0.0.1 with
  a Host-header guard, rendered with textContent only (never innerHTML), and the file viewer is a **whitelist by key**,
  never a free path. Do not publish a filled-in version that contains work data.
- Keep the conversation light: one step at a time, at most 3 bullets, end with ONE next action or a yes/no.
  The user decides design changes ("make the Workflow match reality" vs "fix the task to match the Workflow").

## Build it, step by step
1. **Read the real system first**, never draw from memory: the scheduled task's `~/.claude/scheduled-tasks/<name>/SKILL.md`,
   the scripts it runs (their docstrings), CLAUDE.md agent rules, `.claude/agents/*.md` (their `model:`). Then look at
   1-2 real transcripts (see reference.md) to see the actual order of commands.
2. **Workflow data**: copy `templates/workflow_trace.html`, fill `SWIM` (one entry per flow: lanes, phases, boxes,
   edges) and `STEPMORE` (per inside step: `more`, `match` = regex on the real command, `files` keys, `inside`).
   Set `ROUTINE_TASK` at the top of the script and `MAPKEY` (real stage key → Workflow box).
3. **Trace builder**: copy `templates/trace_build.py` next to it. Set `PROJECT_DIR` (or run from the project folder),
   `ROUTINE_TASK`, `SEND_SCRIPT`; rewrite `RULES` for this workflow's steps and `_checks()` for what the design
   promises. Keep the keys in step with `MAPKEY`.
4. **Serve**: if the project already has a local server, add the routes from `templates/serve.py` to it
   (`/api/trace`, `/api/file`, `/api/version`, the page route) and warm the trace cache at start in a background
   thread. Otherwise run `python templates/serve.py --port 8090` from the project folder.
   Fill `RULE_FILES` with only the files you are happy to display.
5. **Embed (optional)**: as a tab in an existing dashboard via `<iframe src="/<page>?embed=1&run=<id>">`; add the
   page-version auto-reload to the host page too, so open tabs pick up changes without a manual refresh.
6. **Verify before saying it works**: `python -m py_compile`, extract the `<script>` and `node --check` it, open it in a
   browser and click through every box (both modes, both jump links, a file button). For a significant build, have an
   independent reviewer try to break the safety checks (see the send-detector lesson below).

## Lessons that cost time on the first build (do not repeat)
- **Send detection must be shell-aware**: tokenize with `shlex` (quoted text stays one token), drop heredoc and
  here-string bodies (text written INTO a file is not a run), accept argparse prefixes (`--se`, `--sen` = `--send`),
  include subagent calls, ignore `mcp__ccd_*` (messages between Claude sessions), and say "refused by the script"
  when the result shows sending is disabled. A naive text match both missed real sends and raised false alarms.
- **Compound commands**: the first matching rule wins, so put the bigger step first (collect before a status check
  when one command does both). Skip bare `cd` commands. Normalise Windows backslashes to `/` before any regex.
- **Background agents** return at once: time an agent box by its own transcript (`subagents/*.meta.json` → `toolUseId`).
- **List limits hide things**: "latest 60 runs" can be all one long chat. Ask the server for exactly what you need
  (`?with_cases=1`, `?case=<id>`) instead of filtering a capped list in the browser.
- **Merging pages**: never splice code at a text anchor that also appears inside a function. `let/const` are not on
  `window`; test with `contentWindow.eval('RUN')`.
- **Escaping**: write patch scripts to a file instead of nested heredocs; `\'` inside JS strings written from Python
  is the classic break. Always `node --check` after a patch.
- **The model is a fact to record, not assume**: an unpinned scheduled task follows the app default model.
- Restarting the server while someone is clicking gives "Failed to fetch": retry once in the page and say it may be
  restarting.

## Files
- `templates/workflow_trace.html`: the page (Workflow + Trace, step details, jump links, auto-reload), with a small
  fictional example flow to replace.
- `templates/trace_build.py`: transcript → runs → stages → checks (CLI: `python trace_build.py [--run <id>]`).
- `templates/serve.py`: standalone 127.0.0.1 server with the four routes.
- `reference.md`: the Claude Code transcript format the builder relies on, and the stage keys.

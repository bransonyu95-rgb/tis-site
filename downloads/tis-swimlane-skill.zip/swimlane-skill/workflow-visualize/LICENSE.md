# License — plain English

**What you bought:** one copy of the Workflow Swimlanes skill (USD 1.99, once), for your own use on your own computers.

**You may:** use it on all your machines and all your projects, personal or commercial; adapt the templates freely; use the pages it builds in your business, with clients, in presentations.

**You may not:** resell or redistribute these files themselves, free or paid, as-is or renamed. If a friend or client wants the skill, they buy their own USD 1.99 copy — that's what keeps updates coming.

**Updates:** free, forever, from your download page.

**Refunds:** 14 days, no questions — reply to your purchase receipt. You keep the files.

Governing law: Malaysia. Sold by The Industrial Scribe (theindustrialscribe.com).

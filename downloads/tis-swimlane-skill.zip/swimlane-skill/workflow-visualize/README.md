# Workflow Swimlanes for Claude Code
### See exactly what your AI did — and what it was supposed to do — in one picture.

This is a Claude Code **skill**: a set of instructions your Claude follows to build a "Workflow | Trace" page for ANY automation you run — a scheduled task, an agent team, a nightly routine, or just a working session.

- **Workflow** = how your automation SHOULD run. A swimlane read left to right; each lane is who does the work (you, the model, scripts with no AI). Click any box: what goes in, what happens inside, what comes out, which rule files it follows.
- **Trace** = what ACTUALLY ran, rebuilt read-only from Claude Code's own session logs on your computer: the real model used, every command and result, red for failures, and checks showing where reality drifted from the design.

The first trace almost always finds a surprise: a step that runs but isn't on the map, a helper model that never gets used, a task silently switching models. That's the point.

## What you need
- **Claude Pro** (USD 20/month) — Claude Code is the engine, no free tier.
- Python 3 on your computer (Mac has it; Windows: python.org). No other installs.

## Install (2 minutes)
1. Unzip this folder.
2. Move the inner `workflow-visualize` folder into your Claude Code skills folder:
   - Mac: `~/.claude/skills/workflow-visualize`
   - Windows: `%USERPROFILE%\.claude\skills\workflow-visualize`
   (Can't see the `.claude` folder? Dot-folders are hidden on purpose. In Claude Code, just ask: "move this workflow-visualize folder into my skills folder" — it will do it for you.)
3. In Claude Code, say: **"workflow visualize my <task name>"** — and answer its questions.

## What's inside
- `SKILL.md` — the method your Claude follows, including the hard-won lessons.
- `reference.md` — the session-log format the trace reads.
- `templates/` — the page, the trace builder, and a small local server. Everything runs on YOUR computer only (127.0.0.1); nothing is uploaded anywhere.

## The honest limits
- It reads Claude Code's local session logs, so it traces work done on that computer. Cloud runs leave no local logs.
- Your Claude does the adapting; the first build of a new workflow page takes it a focused session, not a minute.

## Help
Reply to your purchase receipt — a human answers, usually within a day.
🛡️ 14-day guarantee: not useful? Full refund, keep the files.

# Reference: what the trace builder reads

## Where Claude Code keeps transcripts
- `~/.claude/projects/<project-dir>/<session-id>.jsonl`: one line per record, one file per session.
  `<project-dir>` = the project folder path with `:`, `\`, `/` and spaces turned into `-`
  (`C:\Users\me\Desktop\My Project` → `C--Users-me-Desktop-My-Project`).
- `~/.claude/projects/<project-dir>/<session-id>/subagents/agent-<id>.jsonl` + `agent-<id>.meta.json`
  (`{"agentType": "worker", "description": "...", "toolUseId": "toolu_..."}`): `toolUseId` is the id of the
  `Agent` tool call in the parent session that started it.
- Scheduled tasks run as ordinary sessions; their first user message starts with
  `<scheduled-task name="<task-name>" file="...SKILL.md">`.

## Records that matter (everything else is ignored)
- `type: "assistant"`: `message.model` (e.g. `claude-opus-5-5`, `claude-haiku-4-5-20251001`),
  `message.id` (several records can share one id: count usage once per id), `message.usage`
  (`input_tokens`, `output_tokens`, `cache_read_input_tokens`, `cache_creation_input_tokens`),
  `message.content[]` items of `type: "tool_use"` (`id`, `name`, `input`) and `type: "text"`.
- `type: "user"`: a real prompt when `message.content` is a string (or text items only) and `isMeta` is not set;
  tool results are `content[]` items of `type: "tool_result"` (`tool_use_id`, `is_error`, `content`).
- `timestamp` (ISO, UTC) on every record.

## Runs, stages, lanes
- Run = one scheduled-task session, or one prompt + everything until the next prompt in an attended session.
  Run id = `<session-id>:<turn>`; validate it with `^[0-9a-f-]{36}:\d{1,5}$` before touching the disk.
- Stage = consecutive tool calls with the same `classify()` key in the same lane. Agent calls are one stage each,
  with the subagent's own calls, model, tokens and times inside.
- Lane = `you` (the prompt), `m:<model>` (the answering model), `agent:<family>` (subagents), `script` (known
  pipeline scripts, issued by the model but running with no AI).

## Stage keys in the template (map them to Workflow boxes with MAPKEY)
From `RULES`: `collect` · `validate` · `publish` · `start` · `log` · `rules` · `read` · `calls`.
Built in: `look` (other reads) · `build` (other writes) · `plan` · `app` (desktop/browser tools) · `other` ·
`send` (always alarmed) · `skip` (bare `cd`) · `agent` (use `agent:<type>` in MAPKEY).

## Speed (measured on ~800 runs / 30 days)
Cold parse of 7 days ≈ 1.5-2.5 s; cached by file mtime+size afterwards: list ≈ 0.1-0.5 s, one run ≈ 5-20 ms.
Warm the cache in a background thread when the server starts.

---
name: so-what-presenter
description: Turns factory and office data into slides or a dashboard that people act on. Every title states the takeaway, and every dashboard tile says what to do and who does it. Use when the user wants a presentation, deck, slide, management update, customer review, chart, KPI dashboard or weekly report, says their report gets "okay, noted", asks which chart to use, or asks to check or fix a chart. Builds a ready-to-open file (a slide deck or dashboard page with real charts) from their own data. Never invents numbers, targets, thresholds or owners.
---

# So-What Presenter: from data to a decision

Nobody in a factory gets paid for making charts. They get paid for making decisions happen. A report that gets ignored and one that gets approved almost never differ in their data. The difference is whether the person presenting knew what the data was supposed to make the audience DO. This skill makes that the first question, every time.

## Step 0: Ask three things (one message, skip what the user already said)
1. **Who will see it,** and what do they already believe? (The GM thinks delivery is fine. The customer suspects quality is slipping.)
2. **What do you need them to decide or do?**
3. **Deck, dashboard, or check?** A deck is for a meeting. A dashboard is a screen people check every week. A check fixes something they already made.

Get today's date from the system (`date`). Never assume it.

## Step 1: Read the data properly
- Read the file they give you (`.csv`, `.xlsx`, a pasted table) or ask them to drop it into the folder. For `.xlsx`, read it with a short script. If that fails, say so plainly and ask for File, then Save As, then CSV. Never skip a file silently.
- **Calculate with a script, never by eye.** Totals, percentages, changes and Pareto shares are computed in code from their rows, and you state the method in one line ("OTD = on-time lines / total lines, per week").
- Big files: summarise honestly ("4,812 rows read; 3 weeks; 2 lines with missing dates left out").
- If the data does not support a clear message, say so. Never invent one.

## Step 2: The So-What method
1. **What is the one thing the data proves?** One thing per slide or per tile. Three things means three slides.
2. **So what must happen next?** The decision, approval or action.
3. **The answer to 1 becomes the title.** Never "Delivery Performance Q3". Always "On-time delivery recovered to 96% after the layout change". A takeaway title does half the presenting before anyone speaks.

## Step 3: Choose the chart
| The message is about | Use | Factory example |
|---|---|---|
| Comparing a few things | Bar chart, sorted, axis from zero | Defects by machine, output by line |
| Change over time | Line chart | OTD trend, scrap rate by month |
| The vital few causes | Pareto: bars sorted big to small, plus a cumulative % line | NCR causes |
| Parts of a whole | Stacked bar (no pie beyond 3 slices) | Downtime split by reason |
| Before vs after | Paired bars, old in grey, new in colour | Cycle time before and after a fix |
| One big number | Just the number, big | Hours saved per week |

When in doubt: a sorted bar with a takeaway title beats anything fancy.

## Step 4: Declutter (every chart)
No 3D, no shading, light or no gridlines, direct labels instead of a legend. **One accent colour** for the point, everything else grey. Round to what people can act on. **Source and date** under every chart. The squint test: blur your eyes; if the point doesn't survive, the chart isn't done.

## Mode A: Deck
1. The one message of the whole deck, in one sentence.
2. As few slides as possible (usually 3 to 5). The default structure for a management update: **Situation** (where we stand, max 3 numbers), **What changed** (good and bad, no hiding), **So what** (in money or days), **The ask** (one sentence, with a date). For a customer deck: purpose, facts, actions and evidence, commitment and next steps with dates.
3. For each slide: the takeaway title (12 words max), the chart (type, axes, what gets the accent colour), what to leave out, and a 2-sentence speaker note.
4. **The number they will challenge,** and the backup answer to prepare.

## Mode B: Dashboard (the so-what dashboard)
A normal dashboard shows data and leaves people to work out what it means. A so-what dashboard tells them what to do.
1. **Action rules first.** For each measure, ask for: the target, when to act (e.g. "below 95% two weeks running"), and who acts. **Never invent a target, threshold or owner.** List what's missing and ask. A measure without a rule is "for information" and goes to the bottom, with the honest note: "if nobody acts on it, it may not belong here".
2. **ACT TODAY band at the top:** at most 3 items where a number crossed the user's rule. Each one: what moved, so what, the action, who, by when. If nothing crossed a rule: "Nothing to act on today."
3. **One tile per measure, in order of importance:** a takeaway title (not the measure's name), the number big, vs target and vs last period, a small trend, status (on track / watch / act, from the user's rules only), and the action line ("If this stays below 95% next week: planner calls the expedite review").
4. **Colour rule:** grey by default; the accent colour only for "act". If everything is coloured, nothing stands out.
5. **Same layout, new data.** Next week the user drops in the new export and says "refresh the dashboard". Keep the layout and rules; recompute everything; update ACT TODAY.

## Mode C: Check
For a chart or slide they paste or describe: (1) title, takeaway or topic? Rewrite it. (2) Can you tell the message in 5 seconds? (3) Is there a simpler chart? (4) List everything to delete. (5) The fix in one paragraph. If it should be a sentence instead of a chart, say so.

## Step 5: Build the file (when they want the real thing)
- **Deck:** one HTML file of slides (one slide per screen, 16:9) that opens in any browser and prints to PDF. Plus, for each slide, short steps to rebuild it in PowerPoint if they need a `.pptx`.
- **Dashboard:** one HTML page in the layout above.
- **Build rules:**
  - Charts are drawn inside the file (inline SVG), with no internet connection needed, because factory laptops often block outside sites.
  - Every number comes from the script's calculation.
  - Grey (#9A9A9A) by default, one accent (#C2410C) for the point.
  - Takeaway titles, direct labels, source and date under every chart.
  - Readable on a laptop screen and a projector.
  - Labels never overlap. Put the rule or target line's label at the left end, above the line; data labels go above their point; leave margin so nothing is cut off at the edges.
- Save it in the folder (e.g. `so-what-deck-<topic>.html` or `so-what-dashboard.html`) and tell them in one line how to open it.

## Step 6: Pre-ship check (print it, ticks or crosses)
Every title a takeaway? One message each? The ask on a slide, with a date? Bars from zero, numbers rounded? One accent colour? Could the busiest person repeat the point after 5 seconds? The challenged number ready? Source and date on every chart? Everything nobody can act on deleted? Could they make the ask in 60 seconds in the corridor? For dashboards also: every tile has an action rule or is marked for information? ACT TODAY shows at most 3 items?

## Hard rules
- Their numbers only. Calculated, never estimated. Gaps are `[CHECK: ...]`.
- Never invent targets, thresholds, owners, dates or causes. Ask.
- Never claim a cause the data doesn't show. "Machine 7 made 58% of defects" is a fact; "because the operator was careless" is not.
- Never name the user's customers or company in anything you build unless they typed the name themselves.

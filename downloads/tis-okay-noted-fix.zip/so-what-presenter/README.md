# "Okay, Noted." Fix: slides and dashboards people act on
### Paste your data. Get slides where every title says what it proves, and a dashboard where every number says what to do and who does it.

**The moment this is for:** you spent two days on the monthly report. Your boss looks at it and says "okay, noted." Nothing happens. The data was fine. It just never said *so what*.

## The method (it's in everything this kit does)
Before any chart, answer three questions:
1. **Who is in the room,** and what do they already believe?
2. **What is the one thing the data proves?** That sentence becomes the title. Not "Delivery Performance Q3". Instead: "On-time delivery recovered to 96% after the layout change".
3. **So what must happen next?** The decision, approval or action your slide exists to trigger.

## Three ways to use it
1. **Deck:** slides for a meeting. The one message, 3 to 5 slides with takeaway titles, the right chart for each (and what to delete), the ask with a date, and the number they'll challenge, with your backup answer ready.
2. **Dashboard: the so-what dashboard.** A normal dashboard shows numbers and leaves people to work out what they mean. This one tells them:
   - an **ACT TODAY** band at the top: at most 3 things that crossed *your* action rules, each with what to do, who does it and by when;
   - every tile titled with its takeaway, not the measure's name;
   - every tile with an action line ("If this stays below 95% next week: the planner calls the expedite review");
   - grey by default, colour only where action is needed;
   - measures nobody acts on, moved to the bottom and flagged honestly.
3. **Check:** paste or describe a chart or slide you already made. Get the takeaway title, what to delete, and the fix.

Every result ends with the 10-point pre-ship check, so you know it's ready before the meeting.

## Two ways to run it
**A. No install: any AI chat, free plans OK.** Open `paste-prompt.md`, choose deck, dashboard or check, fill the blanks, paste your table, and send. Build the slides in your own PowerPoint or Excel from what it gives you.

**B. Claude Code skill: for people who already use Claude Code** (needs Claude Pro, US$20/month). Move this folder to your skills folder (Mac: `~/.claude/skills/so-what-presenter`; Windows: `%USERPROFILE%\.claude\skills\so-what-presenter`). Drop your Excel or CSV export in, and say "make the deck for Monday" or "build my dashboard". It does the maths with a script (never by eye) and builds a real file: a slide deck or a dashboard page with the charts drawn in, which opens in any browser and prints to PDF. Next week, drop in the new export and say "refresh the dashboard".

## What's inside
- `paste-prompt.md`: the no-install version (way A).
- `SKILL.md`: the Claude Code skill (way B).
- `examples/`: worked examples (invented data, labelled EXAMPLE): a deck from a messy defect log, a so-what dashboard from weekly figures, and the dashboard file the skill built.

## The honest limits
- It uses only your numbers. It won't invent targets, thresholds or owners. If your dashboard has none, it lists what's missing, because without them a dashboard can't tell anyone to act.
- It finds what the data proves. It won't invent a cause the data doesn't show.
- Follow your company's rules on putting work data into AI tools. Placeholders for customer names and money figures work just as well.

## Help
Reply to your purchase receipt. A human answers, usually within a day.

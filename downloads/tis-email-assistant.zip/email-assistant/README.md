# Agentic AI: Email Assistant
### It reads the thread, remembers every customer, drafts the reply and tracks what you still owe. You press send.

**Works as a full AI agent in Claude Code. Works as a step-by-step AI guide in any free chat.**

Paste the whole customer email chain. Get the history in a few lines, a warning if the request goes against your own rules, one recommended position, then a reply in your language and tone with every fact checked against the thread. You adjust it by talking, it keeps your edits, and you send it.

**The moment this is for:** a customer chases you for the third time. The thread is 15 emails deep, with forwards, quoted replies and three people CC'd. You need to know what was promised, what's overdue and what they're actually asking, and you need to answer well, fast.

## First use: it learns how YOU write (5 minutes, once)
Before it drafts anything, it asks your permission to learn from emails you've already sent: how you greet, how you sign off, how you say no, how you give bad news, how you chase, and whether you mix languages. It shows you "this is how you write" and asks if it got you right. Then it asks how you *want* to sound from now on (firmer? fewer apologies? different with your boss?). It saves only a short style summary. No email text, names or prices are kept. Not on Gmail or Outlook? It works out which email system you use (from its name, web address or a screenshot) and walks you through saving a few sent emails, step by step. It never asks for your password. Don't want to share emails? Answer a few questions instead.

## It knows each customer before it writes (customer profiles)
Every customer is different. One buyer wants the date in line one; another expects a proper greeting. One QA manager rejects any 8D without an IS / IS-NOT table. One customer is in a cost-down drive and reads every email looking for a price opening. So it keeps a **profile for each customer**:
- the people, and how each one likes to be written to;
- what the customer is pushing for right now;
- their sensitivities;
- their past cases and how they ended;
- the promises still open.

Before drafting, it reads that customer's profile. The reply fits the customer and the exact person you're answering, and it spots repeats ("this is their 2nd bent-pin complaint since August"). Profiles build up as you work: after every thread, it offers to add the new case. Only you approve what's saved. You can also set up your top customers in one go from a few past threads. In the free version, each customer gets a **customer card** you keep in your notes and paste in when you reply.

## It decides like you, not just writes like you (your rules)
Optional, 5 minutes once: tell it your goals (up to 3, in order), how you decide, and the decisions you've already taken, overall or per customer. Before every draft it checks the request against them: "This goes against your decision of 12 Oct: no free air freight for this customer." It never settles a conflict on its own. You choose. Say "add a decision" any time and it remembers.
One rule is always on, because it protects you: it never shows a customer your internal cost, margin, rates or supplier names. A starter set of wording rules ("thanks for your patience" instead of apologising, keeping conditions firm with positive words) is there to switch on if you want it.

## What you get, every time
1. **The catch-up:** who's who, what happened (dated), every promise with its status (kept / open / OVERDUE), what the customer is asking now, what's still open, and the customer's mood. It also flags "agreed by silence": things you never answered that the customer may now treat as agreed.
2. **The rules check:** any conflict with your goals or past decisions, and any mismatch inside the thread (two figures on different bases, a date nobody confirmed), in at most three lines.
3. **One recommendation:** if there's a real choice, 2 or 3 options in one line each, and the one it recommends with the reason. It drafts that one, and you can say "use option B".
4. **The reply draft:** in your language (English, Bahasa Melayu, Chinese and others), in your tone, with your sign-off. It answers their question in the first two sentences. Every promise in it has an owner and a date, and nothing is made up. Gaps are marked [CHECK].
5. **The fact check:** every date, number and promise in the draft is checked against the thread. Anything it can't find is marked [CHECK], and a date nobody confirmed never goes out as a promise.
6. **"Questions this reply already answers":** so you can see the customer has nothing left to chase.
7. **A conversation, not a one-shot, and it keeps your edits.** Reply "firmer", "shorter", "in Malay", or paste back your own edited version: it changes only what you ask and tells you in one line what changed.

**"What do I owe?"** Ask it, and it lists every open promise across all your customers in one table, oldest first, with the overdue ones marked.

It drafts only. Sending is always your click.

## Why we call it an agent
In Claude Code it doesn't just write. It works like an email assistant who never forgets:
- **It learns how you write** from your sent emails (with your OK) and keeps a short style file.
- **It remembers every customer** in their own file, and updates it after each thread, only with your OK.
- **It checks each request against your own rules** and past decisions before it drafts.
- **It checks its own draft** against the thread, so no date or promise goes out that nobody agreed.
- **It keeps a list of everything you owe** across all customers, oldest first.

It never sends, schedules or auto-replies. Sending is always your click.

## Two ways to use it

**A. No install: any AI chat, free plans OK.** Open `paste-prompt.md`. Run the STYLE BUILDER once with 5 to 10 of your sent emails, then keep the MY STYLE block it gives you. Each time, paste your copy plus the thread into ChatGPT, Claude or Gemini. Start here.

**B. Claude Code skill: for people who already use Claude Code** (needs Claude Pro, US$20/month). Move this folder to your skills folder (Mac: `~/.claude/skills/email-assistant`; Windows: `%USERPROFILE%\.claude\skills\email-assistant`). Paste a thread and say "help me reply to this". On first use it asks your permission and learns your style: from emails you paste or drop into a `my-emails/` folder, or straight from your Sent folder if your Claude already has an email connection. Then it saves your style in `my-style.md`.

## What's inside
- `paste-prompt.md`: the no-install version (way A).
- `connect-my-email.md`: connect your work email to Claude directly, read-only, whatever system your company uses. It finds out who really runs your company email (Microsoft 365, Google, Zoho, Alibaba, Tencent or your own server) from public records, then gives you the route that fits: the official connector, or an IT-approved connection. It never asks for your password.
- `collect-my-emails.md`: how to get 5 to 10 sent emails out of any email system (Outlook, Gmail, Lotus Notes, company webmail, Zimbra, Alibaba Mail and more), plus a ready-made message to your IT team if you want a direct connection later.
- `SKILL.md` + `my-style.md` + `my-rules.md`: the Claude Code skill (way B). `my-style.md` starts blank and fills itself in on first use; `my-rules.md` is your goals, decisions and wording rules (optional).
- `CREDITS.md`: where the idea came from, and the open-source licence.
- `customers/`: one profile per customer, built with your OK (starts with a blank `_template.md`).
- `examples/`: four worked examples (invented, labelled EXAMPLE): (1) a messy 5-email complaint chain, the catch-up, the draft and a tone change; (2) the first-time style setup, from 5 sent emails to a finished MY STYLE; (3) a customer profile built from 2 past threads, then used on a new complaint; (4) your rules, one recommendation, the fact check, your edits kept, and "what do I owe?".

## The honest limits
- It only knows what's in the thread, the customer's profile and what you tell it. If a promise was made on the phone, tell it, or it won't know.
- Check your company's rule on pasting customer emails into AI tools. If you're unsure, swap names, prices and part numbers for placeholders first.
- It drafts. It doesn't decide. Money, dates and admissions of fault are yours to decide, and it will mark them [CHECK] rather than guess.

## Help
Reply to your purchase receipt. A human answers, usually within a day.

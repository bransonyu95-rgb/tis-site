# EXAMPLE: a waste hunt on the weekly supplier follow-up

**EXAMPLE. An invented person and company, a real method.** A purchasing executive at a 45-person CNC job shop ran the paste box. Below is what came back after about 30 questions, shortened.

## 1. Business nature
**B, High-Mix Custom** (one-off and small repeat jobs, a new enquiry each time, sample approval for new customers). Money is made on response speed, so in purchasing the costliest waste is late material and plating that stalls one-off jobs.

## The SOP check
The written SOP (2019) says: export open POs, email suppliers, update the ERP promised date.
- **In the SOP but nobody does it:** updating the ERP promised date ("nobody looks at it").
- **Done but not in the SOP:** reformatting the export, searching the inbox for replies, phoning non-repliers, typing dates into a private tracker, answering planners on WhatsApp, a Friday summary for the GM.

## 2. Waste map (weekly steps x 4.33 weeks; estimate from her answers)

| Step | Minutes x times per month = hours per month | Waste type | Keep / cut / fix |
|---|---|---|---|
| 1. Export open POs to Excel | 10 x 4.33 = 0.7 h | Value | Keep |
| 2. Delete columns, reformat (same every week) | 20 x 4.33 = 1.4 h | Extra processing | Fix: template |
| 3. Email 25 suppliers one by one, 3 min each | 75 x 4.33 = 5.4 h | Value, done slowly | Fix |
| 4. Search the inbox for replies, 15 min a day | 75 x 4.33 = 5.4 h | Searching | Fix |
| 5. Phone 8 non-repliers, 5 min each | 40 x 4.33 = 2.9 h | Value (relationship) | Keep |
| 6. Type new dates into a private tracker | 20 x 4.33 = 1.4 h | Extra processing | Combine |
| 7. Answer planners on WhatsApp, 10 x 3 min | 30 x 4.33 = 2.2 h | Moving things around | Rearrange |
| 8. Friday summary for the GM ("never replies") | 30 x 4.33 = 2.2 h | Making what nobody uses | Eliminate (test) |
| Expedite approval wait, about 1 day | [CHECK: how many a month] | Waiting | Next hunt |

**Total: 300 minutes a week, about 21.7 hours a month, about RM 541 a month at RM 25 an hour.** These are the hours the steps take today, not a promised saving.

## 3. Cut first
- **Eliminate** the GM summary: stop it for two weeks and see who asks. If needed, share the tracker instead.
- **Rearrange** the WhatsApp questions: planners read a shared, read-only tracker.
- **Combine** the tracker and the ERP date: type each date once, in one place. Decide which one, and fix the SOP to match.
- **Simplify** the export with a saved layout, and the 25 emails with one fixed template. Ask suppliers to put the PO number in the subject line.

## 4. Top 3 to automate
1. **Reading replies into the tracker** (Level 2, an AI prompt pasted each time): 6.9 hours a month today, and the input is already digital. The AI drafts a table and she checks it.
2. **Drafting the chaser emails** (Level 2): she reviews and clicks Send.
3. **The export layout** (Level 1, a template).
Phone calls stay human (Level 0).

## 5. Build guide for number 1 (shortened)
1. Prepare: the tracker headers, 3 real replies with names replaced, and this week's expected PO list.
2. Paste this prompt each week:
```
You are my purchasing assistant. I will paste supplier email replies below.
For each reply, extract: Supplier, PO number, new promised delivery date, any problem mentioned.
Rules: use only what is written. Never guess a date. Missing or unclear = [CHECK].
Flag any question or change in quantity or price.
Output a table: Supplier | PO number | New date | Problem | Reply received?
Then list which expected POs have NO reply: [paste PO list]
Replies: [paste replies]
```
3. Test on one week of real replies: the table must match what she would have typed, with no invented date.
4. Time steps 4 and 6 for two weeks before and after, and write down the real minutes.
5. Update the SOP: new steps, owner, revision date.

## 6. Help that fits
- SOP from 2019 that no longer matches reality: free article "How to Write Any Manufacturing SOP in 30 Minutes Using AI".
- The same prompt pasted every week: free article on AI Skills ("Stop Re-Introducing Yourself to Your AI Every Morning").

## 7. Next hunt
The expedite approval: about a day's wait each time. Count how many a month first.

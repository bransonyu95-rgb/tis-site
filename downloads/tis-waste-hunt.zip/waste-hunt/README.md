# The Waste Hunt: find the waste in your SOP, then automate what's left
### An AI interview that digs into one task you redo every week, shows you where the hours go, tells you what to cut, and walks you through automating the rest.

**The moment this is for:** you know your weekly report, your PO keying or your supplier chasing eats hours. You've heard "use AI". But which part, and how? Most people automate the task exactly as it is, waste included, and end up with a faster mess.

## What it does, in order
1. **Your factory first (7 questions).** Your business nature: commodity volume, high-mix custom, qualified precision, plus "captive" if one or two customers are most of your revenue. This tells you where waste costs your kind of factory most.
2. **One real task, step by step.** It asks for your written SOP (or notes that there isn't one), then keeps asking until it knows what *really* happens: who, which system, what's copied from where to where, how many minutes, how often, who waits, what gets redone. It digs for the hidden steps: searching, chasing, retyping, reformatting, waiting for a signature.
3. **The waste map.** Every step tagged with the office version of the 8 wastes (waiting, moving things around, pile-up, searching, extra processing, making what nobody uses, mistakes and rework, wasted talent), with hours per month from your own numbers.
4. **Cut before you automate.** Eliminate, combine, rearrange or simplify first. Some hunts save hours with no tool at all.
5. **What to automate, and how far.** Each remaining step gets a level, from "fix the template" to "an AI skill that runs on your files". The top 3 are ranked by hours saved, ease and risk.
6. **A build guide for number 1.** What to prepare, the exact prompt or build steps, a test on one real case, before-and-after timing, and the updated SOP.

**The hard rule:** anything that leaves or commits the company (sending, approving, ordering, pricing, signing) stays a human click. AI drafts, a person decides. Anything that connects to company systems needs IT's OK first.

## Two ways to run it
**A. No install: any AI chat, free plans OK.** Open `paste-prompt.md`, copy the box into a new chat and answer one question at a time. About 30 minutes.

**B. Claude Code skill: for people who already use Claude Code** (needs Claude Pro, US$20/month). Move this folder to your skills folder (Mac: `~/.claude/skills/waste-hunt`; Windows: `%USERPROFILE%\.claude\skills\waste-hunt`). Drop your SOP, a sample report or an export into `sop-in/` and say "waste hunt". It reads your files and does the sums with a script. It saves every hunt and keeps a `waste-log.md` of hours found and hours actually saved. If you want, it then builds number 1 with you and tests it on your real file.

## What's inside
- `paste-prompt.md`: the no-install version (way A).
- `SKILL.md`: the Claude Code skill (way B).
- `tis-resources.md`: the free and paid TIS pages it may point you to, only when one fits a finding in your waste map.
- `examples/`: a worked hunt (invented company, labelled EXAMPLE).

## The honest limits
- It uses only your numbers. Hours saved are an estimate from your answers until you time the before and after.
- It finds waste in office workflows (reports, data entry, chasing, approvals, documents). It is not a shop-floor time study.
- Follow your company's rules on putting work information into AI tools. Placeholders like "Customer A" work just as well.

## Help
Reply to your purchase receipt. A human answers, usually within a day.

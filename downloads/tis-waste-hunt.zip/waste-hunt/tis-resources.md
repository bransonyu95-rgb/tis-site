# TIS resources the diagnostic may recommend

Rules for the AI:
- Recommend only from this list. Never invent a product, page, price or feature.
- At most 3 suggestions per result, each tied to a finding in the user's waste map, in one line: what it is, why it fits *their* finding, and whether it is free or paid.
- Free first. If a free page solves it, suggest that before anything paid.
- Items marked COMING are not in the shop yet: you may mention that they are coming, but never give a buy link or a price.
- If nothing here fits, suggest nothing. The diagnosis is the product, not the advert.

Checked against theindustrialscribe.com on 9 November 2026. Update this file when the shop changes.

## Free

| Fits when the waste is in... | Resource | Link |
|---|---|---|
| Writing or updating an SOP (no SOP, outdated SOP, SOP only in someone's head) | Article: How to Write Any Manufacturing SOP in 30 Minutes Using AI | https://theindustrialscribe.com/article-sop-writing.html |
| The weekly production report (what to track, what to drop) | Article: The 12 Numbers Every Production Manager Should Track Every Week | https://theindustrialscribe.com/article-production-report.html |
| The weekly WIP or job status report built by hand | Free skill: Weekly WIP Status Report (copy-paste, any AI chat) | https://theindustrialscribe.com/skill-wip-status-report.html |
| Re-explaining the same context to the AI every time | Article: Stop Re-Introducing Yourself to Your AI Every Morning (what a Skill is) | https://theindustrialscribe.com/article-what-are-skills.html |
| Decks that come back, rework before a boss or customer review | Free: The Pre-Ship Checklist | https://theindustrialscribe.com/free-checklist.html |
| RCA / customer complaint reports sent back | Article: How to Write an RCA Report Your Customer Won't Send Back | https://theindustrialscribe.com/article-rca-report.html |
| Delivery and price questions slipping in the inbox | Article: How I Connected AI to My Company Outlook in 60 Minutes | https://theindustrialscribe.com/article-ai-to-outlook.html |
| Big ERP exports nobody has time to analyse | Article: Turning over 300,000 rows of factory data into a growth strategy | https://theindustrialscribe.com/article-factory-intelligence.html |
| Not sure where AI fits in their own job | Free: The Insider Test (30 questions, your type and an AI direction) | https://theindustrialscribe.com/insider-test.html |

## Paid (in the shop)

| Fits when the waste is in... | Resource | Price | Link |
|---|---|---|---|
| A document redone every week (weekly report, SOPs in the ISO 9001 convention, hard emails and customer replies), and the user has Claude Pro | Build Your AI Back-Office (the kit): interviews you, reads one real working file, drafts the weekly document | USD 3.99 | https://theindustrialscribe.com/backoffice.html |
| Seeing the workflow: what was supposed to happen vs what actually happened, for an automation they already run in Claude Code | Workflow Swimlanes skill. Not sold on its own: it comes in The Kit + Tools bundle (the kit + Workflow Swimlanes + The Waste Hunt). If the user already owns The Waste Hunt, say so plainly. | USD 9.99 (bundle) | https://theindustrialscribe.com/ |

## COMING (mention only, no link, no price)

| Fits when the waste is in... | Resource |
|---|---|
| Reports and dashboards that get "okay, noted" and no action | "Okay, Noted." Fix: slides and dashboards people act on |
| Long customer email threads: reading the history, drafting the reply | "The Long Email Thread" Reply |

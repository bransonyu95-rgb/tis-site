# TIS resources the diagnostic may recommend

Rules for the AI:
- Recommend only from this list. Never invent a product, page, price or feature.
- At most 3 suggestions per result, each tied to a finding in the user's waste map, in one line: what it is, why it fits *their* finding, and whether it is free or paid.
- Free first. If a free page solves it, suggest that before anything paid.
- Items marked COMING are not in the shop yet: you may mention that they are coming, but never give a buy link or a price.
- If nothing here fits, suggest nothing. The diagnosis is the product, not the advert.

Updated 10 November 2026: the kit, the bundles and the free articles are no longer on the site. Update this file when the shop changes.

## Free

| Fits when the waste is in... | Resource | Link |
|---|---|---|
| The weekly WIP or job status report built by hand | Free skill: Weekly WIP Status Report (copy-paste, any AI chat) | https://theindustrialscribe.com/skill-wip-status-report.html |
| Decks that come back, rework before a boss or customer review | Free: The Pre-Ship Checklist | https://theindustrialscribe.com/free-checklist.html |
| Not sure where AI fits in their own job | Free: The Insider Test (30 questions, your type and an AI direction) | https://theindustrialscribe.com/insider-test.html |

## Paid (in the shop)

| Fits when the waste is in... | Resource | Price | Link |
|---|---|---|---|
| Seeing the workflow: what was supposed to happen vs what actually happened, for an automation they already run in Claude Code | Workflow Swimlanes skill | USD 0.99 | https://theindustrialscribe.com/swimlanes.html |
| Reports, slides or dashboards (including the weekly production report) that get "okay, noted" and no action; or a proposal, investment case or budget ask that needs a yes | Get It Approved: The Persuasion Playbook (proposals, payback maths, the hard questions, slides and so-what dashboards; paste box + Claude Code skill) | USD 9.99 | https://theindustrialscribe.com/okay-noted.html |
| Long customer email threads, or enquiries slipping in the inbox: rereading the history, chasing promises, drafting the reply | Email Intelligence Desk: catch-up, your rules checked, a reply in your voice (paste box + Claude Code skill) | USD 9.99 | https://theindustrialscribe.com/email-reply.html |
| Big exports nobody has time to turn into decisions, and the user wants to see how a real factory office did it | Case study PDF: Building So-What Reports (23 pages, real counts) | USD 18.99 | https://theindustrialscribe.com/#cases |

## COMING (mention only, no link, no price)

Nothing right now.

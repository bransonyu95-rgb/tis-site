---
name: waste-hunt
description: Finds the waste in a factory-office workflow and guides the user to automate what is left. Interviews the user about their business nature, then one real task step by step (the written SOP versus what really happens), maps every step against the 8 office wastes, says what to cut before automating, ranks what to automate and how far, and writes a build guide. It can then build the first automation with them. Use when the user says "waste hunt", "diagnose my workflow", "what can I automate", "check my SOP", "where is the waste", "my weekly report takes too long", "know your business nature", or wants to cut office time or cost. Never invents times, numbers or steps.
---

# The Waste Hunt: see it, cut it, then automate what's left

This skill applies the lean methods factories use (the 8 wastes to find waste, 5S to clear and organise the workspace, standard work to keep it lean) to office work. It serves one purpose: keep the factory office out of waste, so the company spends less to run and moves faster. The order matters. **Automating a wasteful step just makes the waste faster.** So: see what really happens, cut, then automate, and keep a human click on anything that leaves the company.

Get today's date from the system (`date`). Never assume it.

## How to talk
- One question at a time, short, with examples to pick from. Plain words; explain any term in brackets the first time.
- Never invent a time, count, step, owner or cause. Vague answers ("quite long") get a follow-up: "Roughly how many minutes? How many times a week?" Unknowns become `[CHECK: ...]`.
- Be kind and honest. Name waste plainly. Say when something should NOT be automated.
- The user may answer in English, Bahasa Melayu or Chinese. Reply in their language.

## Files (in the folder this skill runs in)
- `my-factory.md`: business nature and context line (Part 1). Written once, reused.
- `hunts/<date>-<task>.md`: one file per diagnosed task (waste map, cut list, top 3, build guide).
- `waste-log.md`: one line per hunt: task, hours per month found, 5S score before and after, what was cut, what was built, hours measured after (filled in later). This is the user's proof of savings.
- `sop-in/`: the user drops their SOP, work instruction, sample report or export here. Read everything in it. For `.docx`, `.xlsx` or `.pdf`, read it with a short script; if a file can't be read, say so plainly and ask for a copy-paste or Save As PDF/CSV. Never skip a file silently.

If `my-factory.md` exists, skip Part 1 and say "I remember your factory: <context line>. Right?"

## Part 1: What kind of factory (once)
Ask, one at a time: what you make and for which sectors; volume pattern (one-off / repeat batches / high volume); typical customer (OEM / tier-1 / trader); how orders arrive (enquiry each time / rolling POs / annual agreements); how many nearby could do the job (many / few / almost nobody); what a new customer needs (PO / sample approval / full audit); how much of the sales comes from the biggest one or two customers (under a third / about half / most).
Then the business nature, in two lines:
- **A Commodity Volume:** money is made on efficiency, so waste in volume paperwork costs most.
- **B High-Mix Custom:** money is made on response speed, so waste that slows enquiries and quotes costs most.
- **C Qualified Precision:** money is made on control, so waste in evidence, traceability and audit records costs most.
- **+ Captive** if one or two customers are about half or more of the sales: waste in proving your value to that customer costs most.
Write `my-factory.md` with the nature, why, and a one-line context line the user can paste at the top of any AI prompt.

## Part 2: Pick the workflow
Ask the role, then "Which task do you redo every week or every day that you'd most like gone?", with four examples that fit the role and the nature. Then, one at a time: how often; minutes each time; who gets the result; what they actually do with it. If nobody acts on the result, flag it now: it may be the biggest waste of all.

## Part 3: The SOP check (the digging)
1. Is there a written SOP? If yes, ask them to drop it into `sop-in/` or paste it. If no, record "no written SOP": knowledge in one person's head is a risk.
2. Walk what REALLY happens, trigger to hand-over. For each step, keep asking until you have: who; which system, file or tool; what is copied, typed or checked, from where to where; minutes per time and times per month; who waits and how long; what goes wrong and how often it's redone.
3. Dig for hidden steps: searching, chasing someone for an input, retyping into a second system, reformatting for a different person, waiting for a signature. Ask "What happens just before this? Just after?" and "What would break if you skipped it?"
4. If there's a written SOP, show the gaps in a short table: in the SOP but nobody does it / done but not in the SOP / done differently. A step the SOP requires but nobody does goes to Part 6: make it real (say what it would fix) or remove it from the SOP.
5. If they dropped a sample report or export, read it and use it: count columns nobody uses, spot data typed by hand that already exists elsewhere, check what the receiver actually needs.
6. At the end, ask (optional) what an hour of their time costs the company, and the working days per month if any step is daily.

## Part 4: The waste map
One table, one row per step: Step | Who | Minutes x times per month = hours per month | Waste type | Keep / cut / fix.
Office version of the 8 wastes: **Waiting** (input, approval, signature) · **Moving things around** (forwarding, printing to hand over, re-sending) · **Pile-up** (backlogs, unread queues) · **Searching** (files, switching systems) · **Extra processing** (retyping data that's already in a system, reformatting, needless double checks) · **Making what nobody uses** (reports or columns nobody acts on) · **Mistakes and rework** (errors found later, send-backs) · **Wasted talent** (a senior person doing copy-paste). Steps the business truly needs are **Value**.
**Calculate the totals with a script, never by eye.** Weekly steps: minutes x 4.33 weeks; daily steps: minutes x their working days per month. State the factor. Show the sum. If the user gives a cost per hour, show money per month too. Label it "estimate from your answers". These are the hours the steps take today, not a promised saving; savings are known only after the before-and-after timing.

## Part 5: The 5S check (clear and organise the work behind this task)
The lean way to make the workspace behind a task stay lean. Look at its files, folders, reports, spreadsheet, inbox and checklist (and anything in `sop-in/`). Ask one or two short questions per S, one at a time, and score each from 0 (not at all) to 5 (fully in place) from the user's answers and files only:
- **Sort:** anything nobody needs? Old file versions, report columns or whole reports nobody reads, extra CCs, "just in case" steps. If a sample report is in `sop-in/`, count the columns nobody uses.
- **Set in order:** one place for everything? Could a colleague covering find the current file in 30 seconds (one folder, one naming rule, the latest version obvious)?
- **Shine:** is the source clean? Duplicates, wrong or missing entries, broken formulas or links, unread pile-ups. Are problems spotted while working or found later?
- **Standardize:** is the agreed way written down (SOP, template, checklist, naming rule) so anyone does it the same?
- **Sustain:** an owner, and a short regular check that stops it sliding back?
Show a 5S table: S | Score | Finding | The one action, with the total out of 25, labelled "from your answers". Sort and Set in order actions feed Part 6 (cut first). Standardize and Sustain actions feed Part 8 (the SOP update and the regular check). Record the 5S score in the hunt file and in `waste-log.md`; re-score it a month after the build.

## Part 6: Cut before you automate
For each waste step, in this order: **Eliminate** (who would notice? ask) · **Combine** · **Rearrange** (order or owner, so nobody waits) · **Simplify** (template, checklist, one format). Add the 5S Sort and Set in order actions. Include any SOP step nobody does: make it real or remove it from the SOP. Then list what's left that still takes real time: the automation candidates. Many hunts end here with real savings and no tool at all. Say so when it happens.

## Part 7: What to automate, and how far
Score each candidate: same every time? input already digital? hours per month? cost of a mistake? needs judgement or a relationship? Then a level:
- **Level 0:** no tool; fix the SOP, template or owner.
- **Level 1:** a spreadsheet formula, template or checklist.
- **Level 2:** an AI prompt pasted each time (AI drafts, person checks).
- **Level 3:** a Claude Code skill or small script that runs on the user's own files.
- **Level 4:** a scheduled routine that runs by itself, only for steps that read and prepare.
**Hard rule:** anything that leaves or commits the company (send, approve, order, price, sign, change the ERP) stays a human click. AI drafts, a person decides. Never route around IT: anything that connects to company systems needs IT's OK first. Never ask for or type a password.
Rank the top 3 by hours saved, ease and risk. Pick number 1 and say why in two sentences.

## Part 8: The build guide, then build it together
Write the guide into the hunt file:
1. What to prepare (files, a sample, who to ask).
2. The build, step by step at the chosen level: for Level 2, the full prompt with blanks; for Level 3 or 4, inputs, steps, outputs, checks.
3. Test on one real case. What "it worked" looks like.
4. Measure before and after for two weeks; real numbers go into `waste-log.md`.
5. Standardize and sustain (5S): the updated SOP (new steps, owner, revision date), the template, checklist or naming rule, and a short regular check with an owner. Re-score the 5S a month later.

Then ask: "Want to build number 1 now?" If yes and it's Level 1 to 3, build it in this folder: a spreadsheet template, a prompt file, a skill folder, or a script that reads their file from `sop-in/` and writes the result to a new file. Run it on their real sample, show the output, and ask them to check it. Never overwrite their original files. For Level 4, build and test it as Level 3 first. Schedule nothing until it has run correctly by hand at least twice and the user says yes.

## Part 9: Help that fits (only if it fits)
Read `tis-resources.md` (next to this skill). Suggest at most 3 items, each tied to a finding in this waste map, in one line each: what it is, why it fits, free or paid. Free first. Items marked COMING: mention only, with no link and no price. If nothing fits, suggest nothing. Never invent a product or a page.

## Finish every hunt with
1. Business nature, one line. 2. Waste map and total hours per month. 3. 5S score out of 25, with one action per S. 4. Cut first. 5. Top 3 with levels. 6. Build guide for number 1. 7. Help that fits, if any. 8. **Next hunt:** the next task worth diagnosing. Save the hunt file and add the line to `waste-log.md`.

## Coming back
- "How much have we saved?" Read `waste-log.md`. Report hours found versus hours measured after, and keep the two apart. Found is an estimate; measured is proof.
- Two weeks after a build, if the log has no "after" number, ask for it before starting a new hunt.

## Hard rules
- The user's numbers only. Calculated, never estimated by eye. Gaps are `[CHECK: ...]`.
- Never invent steps, times, owners or causes.
- Cut before you automate.
- Human click on anything that leaves or commits the company. IT approves connections. No passwords.
- Never name the user's company, customers or colleagues in files you write unless they typed the name themselves, and suggest placeholders when they do.

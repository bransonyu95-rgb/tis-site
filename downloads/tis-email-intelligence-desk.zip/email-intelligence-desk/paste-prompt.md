# Email Intelligence Desk — the no-install version

Works in any AI chat: ChatGPT, Claude or Gemini, free plans included. Nothing to install.

You paste the whole customer email chain. In under a minute you get the history in a few lines (who promised what, what's still open, what the customer is really asking now), a warning if the request goes against your own rules or a decision you already took, one recommended position, then a reply drafted in your language and your tone, with every fact checked against the thread. You adjust it by talking to the AI, and it keeps your own edits. You send it yourself.

## Set it up once: teach it how YOU write (5 minutes, then never again)
1. Open 5 to 10 emails **you sent** to customers or suppliers. Pick a mix: a normal reply, a "no", some bad news, a chase. Not sure how to get them out of your company's email system (webmail, Lotus Notes, Zimbra, Alibaba Mail and so on)? `collect-my-emails.md` has the steps for each one. Copy-paste always works.
2. Copy the **STYLE BUILDER** box below, paste your emails under it, and send it in a new chat.
3. The AI shows you "this is how you write", asks if it got you right, then asks how you *want* to sound from now on (firmer? fewer apologies? different for your boss?).
4. It hands you a filled-in **MY STYLE** block. Paste that into the MY STYLE part of the main box further down, and keep that copy in your notes. It is now YOUR version, and every reply sounds like you.

No emails to share? Skip the style builder and fill MY STYLE in by hand. That works too.

```
=== STYLE BUILDER: START ===
Below are some emails I sent. Learn how I write, so you can later draft replies that sound like me.

Rules: only learn my STYLE. Don't copy whole sentences, and don't repeat any names, prices or part numbers from these emails in your answers.

Step 1. Show me "This is how you write" in 6 to 10 short lines: greeting and sign-off, language (and any mixing), formality and warmth, length and how fast I get to the point, phrases I often use, how I say no, how I give bad news, how I apologise, how I chase. Give each line a short example of the pattern in your own words. Then ask: "Is this you? Anything I got wrong?" Wait for my answer.

Step 2. Then ask me, ONE question per message:
  1. From now on, do I want to sound just like this, or change something (e.g. firmer with customers who chase, fewer apologies, more formal with new customers)?
  2. Should I sound different with customers, suppliers and my boss?
  3. Any rule you must always follow (e.g. never agree to money without finance, never promise air freight)?

Step 3. Give me my finished MY STYLE block in exactly this shape, ready to copy:
MY STYLE (fill once, keep your copy)
- My name and sign-off:
- Language I write in:
- My usual tone:
- Phrases I like to use:
- Words or phrases I never use:
- Anything else:
Include what I asked to change, how I write to customers, suppliers and my boss, and my rules, inside those lines.

MY SENT EMAILS (paste 5 to 10 below):

=== STYLE BUILDER: END ===
```

Before you paste: check your company's rule on putting work emails into AI tools. If you're unsure, remove names, prices and part numbers first. Your style shows just as clearly without them.

## Optional, and worth it: a card for each important customer (5 minutes per customer)
Every customer is different. One buyer wants the date in line one; another gets offended without a greeting. One QA manager rejects any 8D without an IS / IS-NOT table. A **customer card** remembers all that, plus their current push (cost-down? zero-defect?) and their past cases, so every reply fits that customer.
1. Pick a customer. Collect 2 or 3 past email threads with them (same ways as your sent emails: see `collect-my-emails.md`).
2. Paste them under the CUSTOMER CARD BUILDER box below and send it.
3. Answer its few questions, then keep the card it gives you in your notes, one per customer.
4. Each time you reply to that customer, paste their card into the main box. After every reply, the AI hands you the card back with the new case added. Copy it back into your notes.

```
=== CUSTOMER CARD BUILDER: START ===
Below are some past email threads with ONE customer. Build me a CUSTOMER CARD so future replies fit this customer.

Rules: facts only from these threads or from my answers. Never invent a person, a preference or a past case. Mark anything you guessed "(inferred, please confirm)". Don't record personal phone numbers, home addresses or private details. Describe people neutrally ("prefers short replies", not "rude").

Step 1. Draft the card in exactly this shape:
CUSTOMER CARD: [short name or code]
- What they buy / how important they are to us:
- The people (name, role, what they care about, how to write to each):
- How this customer likes to be written to (language, formality, what they want first, words to avoid):
- Their direction right now (what they're pushing for):
- Sensitivities and red lines:
- Case history (date: what happened, how it ended, lesson):
- Open promises (who owes what, by when):
- Decisions we've taken with them (date, decision, why):
- What WE want from this customer right now:
- Last updated:

Step 2. Then ask me, ONE question per message, only what the threads can't tell you:
  1. How important is this customer to us?
  2. Anything about them I should know that isn't in these emails?
  3. Does anyone there need a different tone from the rest?
Then give me the final card, ready to copy.

CUSTOMER SHORT NAME OR CODE:

PAST THREADS (paste 2 or 3 below):

=== CUSTOMER CARD BUILDER: END ===
```

## Optional, and the most useful 5 minutes: MY RULES
Your style makes replies sound like you. Your rules make them decide like you. Fill in the MY RULES part of the main box once (keep your copy in your notes, next to MY STYLE):
- **My goals:** up to 3, most important first. What your replies must protect (a key customer, margin, only confirmed dates).
- **How I decide:** your principles ("a delay is told the same day", "no money agreed on email before finance sees it").
- **Decisions I've taken:** with date and customer ("12 Oct, CUSTOMER-A: no free air freight on orders they changed"). Customer cards also keep their own decisions.
- **Wording rules:** keep the ones you want from the starter list in the box, delete the rest.
Every draft is then checked against it. If the customer asks for something you already said no to, you see it before you write a word.

## Every time you use it (2 minutes)
1. Copy your saved box.
2. If you have a card for this customer, paste it under **CUSTOMER CARD**. Then paste the whole email chain under **THE THREAD**, newest on top the way Outlook shows it. Messy is fine, and so are forwards and quoted replies.
3. Optional: under **WHAT I WANT TO SAY**, write your point in a few words, in any language. Example: "agree to the 15th, but no air freight cost from our side".
4. Fill in **TODAY'S DATE**, paste it all into a new chat, and press Enter.
5. Read the catch-up, the rules check and the draft, then reply in plain words to change it: "firmer", "warmer", "shorter", "in Malay", "use option B". Changed some words yourself? Paste your version back and say "keep my edits, now make line 2 firmer": it only touches what you ask. Send it from your own mail when you're happy.

**Before you paste:** check your company's rule on putting customer emails into AI tools. If you're unsure, replace customer names, prices and part numbers with placeholders such as CUSTOMER-A, PRICE-1 or PART-X first. The AI works just as well.

```
=== START ===
You are my email partner for customer threads. Two jobs: (1) catch me up on a long email chain so I don't have to reread it, (2) draft my reply in my language and my tone. I decide; you advise. I send everything myself. You only draft.

JOB 1: CATCH ME UP. Read THE THREAD (newest is usually on top; quoted text repeats older emails, so count each message once). Show me, short:
- WHO'S WHO: each person, their side (customer or us) and their role if visible. One line each.
- WHAT HAPPENED: the story in 3 to 6 lines, oldest to newest, with dates.
- PROMISES: every commitment anyone made: who, what, by when, and status (kept / open / OVERDUE against TODAY'S DATE). Include silent decisions: something proposed that nobody objected to and later emails treated as agreed. Mark those "agreed by silence".
- WHAT THEY'RE ASKING NOW: the exact question or demand in the latest customer email, in one line.
- STILL OPEN: what nobody has answered yet, and who owes the next move.
- CUSTOMER MOOD: one line (calm / impatient / frustrated / angry) and why, quoting their words.
- FROM THIS CUSTOMER'S HISTORY (only if I pasted a CUSTOMER CARD): repeats or patterns that matter now (e.g. "2nd bent-pin complaint since August"), and earlier promises still open.
Never guess. If the thread doesn't say it, write "not in the thread".
Start the catch-up with one line: who this reply is to, and what it should achieve for me.

RULES CHECK (before drafting, at most 3 lines). Compare the request, and WHAT I WANT TO SAY, with MY RULES and the CUSTOMER CARD's decisions:
- Conflicts: anything that goes against my goals, my principles or a decision I logged. Name it: "This goes against your decision of 12 Oct: ...".
- Mismatches in the thread: two figures on different bases, a date nobody with authority confirmed, a claim (approved, shipped, cleared) nobody confirmed.
- If none: "No conflict with your rules." Never resolve a conflict silently. If WHAT I WANT TO SAY doesn't settle it, draft the option that keeps my rule and say so.

JOB 2: RECOMMEND, THEN DRAFT MY REPLY.
- If there's a real choice (agree / refuse / partly agree / ask first) and I didn't say what I want: give 2 or 3 options in one line each, recommend ONE with the reason, and draft that one. I can say "use option B".
- Tone, in this order: MY STYLE is the base. The CUSTOMER CARD (if pasted) adjusts it for this customer and the exact person I'm replying to: their language, formality, what they want first, words to avoid. Today's mood adjusts it further. WHAT I WANT TO SAY wins over everything. State the tone in one line before the draft.
- Respect the card's sensitivities. Never contradict an earlier promise on the card. If it's a repeat problem, say honestly what's different this time.
- Answer what they're asking NOW in the first two sentences. No warm-up paragraph.
- Use my point from WHAT I WANT TO SAY if I gave one.
- Every commitment in my reply has a WHAT, a WHO (a role is fine) and a DATE. "We are looking into it" is banned.
- Never invent a fact, price, date or promise that isn't in the thread or in my notes. Mark gaps [CHECK: ...].
- If my reply carries bad news: the news goes in sentence one, then the recovery plan (actions, owners, dates) and the new date they can hold me to. Bad news beats no news.
- Don't repeat what they already know. Don't reopen things that are settled. Don't blame people.
- MY RULES and the card's decisions are internal. Never quote them to the customer as an agreement, a policy or "our decision". Give the position with a reason the customer can see (e.g. their own PO change). Call something an agreement only if the thread shows the customer agreed.
- Never show the customer our internal cost, margin, cycle times, rates, freight cost or supplier names, even if they appear in the thread. Follow the wording rules I kept in MY RULES.
- Before showing me, read the draft AS THE CUSTOMER. If they could still reply with a question, fix the draft or mark [CHECK].
- FACT CHECK: re-read the thread. Every date, number, name and promise in the draft must be in the thread, the card or my notes. Fix or mark [CHECK] any that isn't. A date the plant or the owner hasn't confirmed goes in as [CHECK], not as a promise.

SHOW ME, in this order, short:
1. CATCH-UP (Job 1)
2. RULES CHECK
3. OPTIONS and your recommendation (or one line: "Position: ...")
4. THE DRAFT, with subject line, ready to paste
5. One line: "Fact check: X facts found in the thread" (name any that weren't), then "Questions this reply already answers": a short list
6. YOUR DECISION: at most 3 yes/no items (any [CHECK], any conflict). If any [CHECK] is left: "Do not send yet."
7. One line: "Want it firmer, warmer, shorter, in another language, or a different position? Just tell me."
8. UPDATED CUSTOMER CARD: my card with today's case, new promises and anything new about the people added (or a new card started from this thread if I pasted none), ready for me to copy back into my notes. Only facts from the thread or from me. Mark guesses "(inferred, please confirm)". No personal phone numbers, home addresses or private details.
If I took a decision in this thread, add it to the card under "Decisions" with today's date and the reason.
Then wait. KEEP MY EDITS: if I paste back a version I edited, that is now the draft; never undo my wording. When I ask for a change, change only what the request touches and keep the rest word for word (rewrite everything only if I ask for a full rewrite, a new position or another language). After each change, tell me in one line what changed, and re-check the facts and my rules on it. "Firmer" means clearer and more definite in tone, never a new promise, date or offer I didn't make. If I describe the feeling I want ("polite but they must know we're not paying"), turn it into the tone and tell me in one line how you read it.

MY STYLE (fill once, keep your copy)
- My name and sign-off:
- Language I write in (e.g. English, Bahasa Melayu, Chinese; or "same as the customer"):
- My usual tone (e.g. polite and direct; warm; formal):
- Phrases I like to use:
- Words or phrases I never use:
- Anything else (e.g. "always CC my manager on price topics", "never promise air freight"):

MY RULES (optional, fill once, keep your copy)
- My goals, most important first (up to 3):
- How I decide (my principles):
- Decisions I've taken (date, customer, decision, why):
- Always on: never show a customer our internal cost, margin, cycle times, rates, freight cost or supplier names.
- Starter wording rules (delete the ones you don't want):
  - Write "thanks for your patience" instead of apologising in every email.
  - Keep conditions firm with positive words ("we will arrange delivery upon receipt of the revised PO").
  - When waiting on the customer, put the date I asked for their answer in writing.
  - When holding a price: the price stands, offer to walk them through it, no "we will review".
- My own rules:

CUSTOMER CARD (optional: paste this customer's card from your notes, or leave empty):

TODAY'S DATE:

WHAT I WANT TO SAY (optional, any language):

THE THREAD (paste the whole chain below):

=== END ===
```

## "What do I owe?" across all your customers (1 minute)
Your customer cards each keep the open promises. To see everything in one list, paste all your cards under this small box:

```
=== WHAT DO I OWE: START ===
Below are my customer cards. Make ONE table of every open promise, oldest due date first: Due | Customer | What | Owed by | Status. Mark OVERDUE against today's date. Split it into "owed by me or my team" and "owed by the customer" (those are chasers). List only what the cards say; if a card's "Last updated" is old, say so. Then ask which one I want a draft for.
TODAY'S DATE:
MY CARDS:
=== WHAT DO I OWE: END ===
```

## Why it works
You don't read 20 emails to find the one promise that matters. The AI reads them all and lists every promise with its date and its status. The reply starts from what the customer is asking right now, and you set how it sounds before anything goes out.

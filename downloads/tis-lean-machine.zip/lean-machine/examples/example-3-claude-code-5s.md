# EXAMPLE 3: 5S on a messy Claude Code setup

**EXAMPLE. An invented setup, from a real test run of the Claude Code skill (15 Nov 2026), shortened.** A planner at a precision machining factory has used Claude Code for a few months. They say: "5S my Claude Code."

## Step 0: the scan (read-only)
6 skills the user made, 1 CLAUDE.md (10 lines), 2 memory notes, 1 MCP server (name only). Settings show counts only, and their values are never shown. Checksums of the settings files are recorded first, as proof they won't be touched.

## The 5S score (from the scan and the user's answers)
| S | Score | What we found | The one action |
|---|---|---|---|
| Sort | 2/5 | `weekly-report-old` (a copy of `weekly-report`), `test1` (never used, nearly 2 years old), `random-notes` (a folder with notes, not a skill) | Archive the 3 |
| Set in order | 2/5 | Folder `supplier-chaser` but skill name `supplier-follow-up`; CLAUDE.md has no sections | Rename the folder to match; give CLAUDE.md the standard layout |
| Shine | 1/5 | `quote-helper` header won't load (an unquoted `: `); the memory index points to a missing file; CLAUDE.md says both "always answer short" and "always give long detailed explanations"; it points to a 2024 report path and a skill that no longer exists | Fix the header and the index, settle the contradiction, mark the 2 stale lines [CHECK] |
| Standardize | 2/5 | No CLAUDE.md layout, headers written differently | Standard layout; quoted descriptions |
| Sustain | 0/5 | No check, no log, no rule | Add the rule, log it, set a re-check date |
| **Total** | **7/25** | | |

## The plan (nothing changed yet)
| # | What | Action | Why |
|---|---|---|---|
| 1 | weekly-report-old | archive | duplicate, never used |
| 2 | test1 | archive | never used, no real description |
| 3 | random-notes | archive (user agreed) | not a skill |
| 4 | supplier-chaser | rename folder to supplier-follow-up | folder must match the name |
| 5 | quote-helper | quote the description | header won't load |
| 6 | memory index | remove the line to the missing file | file is gone |
| 7 | CLAUDE.md | remove 3 repeats, add sections, add "check before adding a skill" | repeats, no sections |
| 8 | CLAUDE.md contradiction | ask: short or long? (user: "short") | two rules fight |
| 9 | CLAUDE.md stale lines | mark [CHECK], ask the user | can't know the right path |

**Not touched:** permissions, hooks, settings values, the MCP server's config. Those are the user's to change.
"Shall I do all of it, some of it, or none?" User: "All."

## After
| S | Before | After |
|---|---|---|
| Sort | 2 | 5 |
| Set in order | 2 | 4 |
| Shine | 1 | 3 (two lines still wait for the user's answer) |
| Standardize | 2 | 4 |
| Sustain | 0 | 3 (the first monthly check is still to come) |
| **Total** | **7** | **19 / 25** |

- Nothing deleted. 3 items are in `.claude/_5s-archive/2026-11-15/`, and copies of every edited file are in its `edited/` folder.
- `UNDO.md` lists 7 changes, each with where it was and how to put it back.
- The settings checksums are unchanged.
- The re-check date (15 Dec) is in `waste-log.md`.
- "Restart Claude Code so the changes load."

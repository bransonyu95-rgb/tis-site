# EXAMPLE 2: the changeover on machine 3 (shop floor)

**EXAMPLE. An invented factory and numbers, from a real test run of the free-chat version (15 Nov 2026), shortened.** A CNC cell leader at a high-mix precision machining factory picks one thing: the changeover on machine 3, a CNC mill.

## The walk, in short
From the last good part of the old job to the first good part of the new one takes **95 minutes**, 12 times a month. There's no written changeover standard. The machine hour costs RM 120.

## The waste map (estimate from the user's answers)
| Step | Minutes × times = hours/month | Waste |
|---|---|---|
| Walk to the tool crib (3 trips) | 15 × 12 = 3.0 h | Motion |
| Search the shared rack for the fixture | 10 × 12 = 2.0 h | Motion |
| Ask engineering which revision, load from USB | 20 × 12 = 4.0 h (mostly waiting) | Waiting, wrong-revision risk |
| Set work offsets | 15 × 12 = 3.0 h | Value |
| First-article check: 20 min waiting for QC, 5 min checking | 25 × 12 = 5.0 h (4.0 h waiting) | Waiting, then value |
| Adjust and re-run | 10 × 12 = 2.0 h | Defects |
| **Total** | 95 × 12 = 1,140 min = **19 h a month ≈ RM 2,280** | |

## 5S, scored from a photo of the bench (described: 12 loose tools, two old drawings, no labels, no shadow board, chips under the vice, a torque wrench with a broken handle)
| S | Score | Action |
|---|---|---|
| Sort | 1 | Red-tag the broken torque wrench; pull old drawings |
| Set in order | 1 | Shadow board for machine 3 tools |
| Shine | 2 | Clear chips after each changeover |
| Standardize | 0 | Write the one-page standard |
| Sustain | [CHECK] | Name an owner and a short check |

## The real cause (5 Whys)
QC waits 20 minutes → QC isn't told in advance → there's no "first article ready" signal → **the changeover was never standardized.** No one is blamed: a missing signal and a missing standard can be fixed.

## Cut first
- Stage the tools for the next job at the machine while the old job still runs.
- Give each fixture a labelled slot.
- Write the approved revision on the job sheet (engineering confirms it, and the quality owner OKs it because it touches traceability).
- Put a "first article ready" card on the machine so QC comes on time. **The first-article check itself stays.** Only the waiting before it is cut, and the quality owner OKs any change to that step.

## The one-page Lean Plan
1. **Problem:** the changeover takes 95 min, 12 times a month: 19 h, about RM 2,280 a month.
2. **Waste:** waiting 8 h, motion 5 h, re-run 2 h.
3. **Cause:** no standard, so there's no signal to QC.
4. **What if (not a promise):** removing only the QC wait gives 75 min a changeover, which saves 4 h (RM 480) a month.
5. **Actions:** cut first (signal, revision on the sheet, staged kit, labelled slots), then standardize (one-page standard, shadow board), then automate (a Level 2 prompt that drafts the kit list from the job sheet).
6. **Owners, target and dates:** [CHECK]. These are for the cell leader to set.
7. **Check:** time every changeover for two weeks, and re-score the 5S in a month.

# Agentic AI: The Lean Machine
### Lean, the way it's really done inside a factory. Walk any part of your work, find the waste, clean it up, fix the real cause, and keep it that way. Then it 5S's your Claude Code too.

**Works as a full AI agent in Claude Code. Works as a step-by-step AI guide in any free chat.**

**Written from the inside.** Lean isn't a poster on the wall. It's walking to the machine, timing the changeover, asking "why?" five times, and writing the new way down so it doesn't slide back. Ah Hock (The Industrial Scribe) wrote this from a career in factory sales and customer-facing roles, for the people who actually do the work: on the floor, in engineering, in planning and in the office.

**The moment this is for:** something eats your hours every week. A changeover that takes forever. A drawing change that sits for days. An order that takes two weeks to ship but only two hours to make. A report you rebuild by hand. You've heard "use AI". But if you automate it as it is, you just get a faster mess.

## It learns YOUR factory
Every hunt teaches it more about your own floor. It keeps a **factory memory**: your numbers, the causes that keep coming back, the fixes you tried, and whether they really worked, measured before and after. So your next Lean Plan starts with **"From your own factory"**: what already worked on your machine 3, ready to copy to machine 5. Proven fixes from your own floor come before any textbook idea. When the same cause shows up hunt after hunt, it tells you plainly: that's a factory-wide problem now.
Already have old records? Drop in your 5S audits, downtime logs, scrap logs or improvement sheets, and it learns from day one.
It's not secret AI training. It's plain files on your own computer that you can open, edit or delete, and nothing is sent anywhere. It writes roles, not names ("the QC inspector", "Customer A"), and saves nothing without your OK. In free chat, it hands you a **factory memory card** at the end to paste in next time.

## Plus lessons from inside a real factory
Every plan can also draw on lessons from improvement work inside a real precision-machining factory. For example: lead time is mostly waiting; split "planned to wait" from "forgotten" before you blame the floor; the material kit is its own wait; capture output at the machine with almost no typing; remove what nobody uses; a problem needs an owner before it needs a system. They're patterns, anonymised, with no company names or figures. It uses one only when it fits what you found.

## Use it anywhere in the factory
| Area | What it walks with you |
|---|---|
| **Shop floor** | A machine, a cell, a store: changeover time, walking trips, parts waiting, setup scrap |
| **Engineering** | Drawings, programs, changes: which version is live, how long a change waits, who keeps getting asked |
| **Process flow** | One real order from enquiry to payment: work time vs waiting time, every hand-over |
| **Office** | Reports, data entry, chasing: what's copied, retyped and redone |

## What it does, in order
1. **Your factory first.** A short read of your business nature, so it knows where waste costs your kind of factory most.
2. **Go and see.** It asks what really happens, one step at a time, until every step has a time and a reason. It checks your SOP against what people actually do.
3. **The waste map.** Every step tagged with the 8 wastes, with hours per month from your own numbers. For an order, it shows the plain truth: "about 2 hours of real work in 9 days".
4. **The 5S check, scored out of 25.** For a bench, a rack or a folder. Send a photo and it scores what it can see.
5. **The real cause.** The 5 Whys on the biggest waste, until it reaches something you can change.
6. **Cut before you automate.** Remove, combine, reorder, simplify. Many hunts save hours with no tool at all.
7. **The new standard.** A one-page standard and a simple visual check, so it stays lean.
8. **Automate only what's left.** Each step gets a level, from "fix the template" to "an AI skill that runs on your files".
9. **Your one-page Lean Plan.** The problem, the waste, the cause, what already worked in your own factory, the target, who does what by when, and the date you check again.

## Why we call it an agent
In Claude Code it doesn't just advise. It does the work with you:
- **It reads your real files and photos:** SOPs, exports, drawing lists, a photo of the bench.
- **It does the sums with a script,** never by eye.
- **It builds the fix:** the template, the checklist, the prompt or a small script, tested on your real file.
- **It remembers your factory** between hunts: your numbers, repeat causes, fixes and standards, in files you own.
- **It keeps a log** of hours found, hours actually saved, and your 5S score before and after.
- **It 5S's your Claude Code setup.** Over time Claude Code gets messy like any workbench: skills you never use, a CLAUDE.md that keeps growing, memory notes that are out of date, two tools doing the same job. It scans your setup (read-only) and scores the 5S. Then it shows you a plan, and only after your yes does it tidy things up: unused skills go to an archive folder, broken headers get fixed, CLAUDE.md is trimmed. **It never deletes anything**, it keeps an undo list, and it never touches your keys, passwords, permissions or anything IT manages.

Anything that leaves or commits the company (sending, approving, ordering, pricing, signing) stays your click.

## Two ways to run it
**A. No install: any AI chat, free plans OK.** Open `paste-prompt.md`, copy the box into a new chat and answer one question at a time. About 30 to 45 minutes.

**B. Claude Code skill: for people who already use Claude Code** (needs Claude Pro, US$20/month). Move this folder to your skills folder (Mac: `~/.claude/skills/lean-machine`; Windows: `%USERPROFILE%\.claude\skills\lean-machine`). Drop your SOP, an export or photos into `sop-in/` and say "lean machine" (or "waste hunt"). To clean up Claude Code itself, say "5S my Claude Code".

## What's inside
- `paste-prompt.md`: the no-install version (way A).
- `SKILL.md`: the Claude Code skill (way B).
- `references/insider-lessons.md`: 16 lessons from inside a real factory, anonymised. Worth reading on its own.
- `references/lean-by-area.md`: walk questions, waste examples and 5S for the shop floor, engineering, process flow and office, plus the 5 Whys and the one-page Lean Plan. Worth reading on its own.
- `references/claude-code-5s.md`: the 5S routine for your Claude Code setup, with a CLAUDE.md layout and a skill template.
- `scripts/claude_5s_scan.py`: the read-only scan of your Claude Code setup (plain Python, nothing to install).
- `tis-resources.md`: the free and paid TIS pages it may point you to, only when one fits a finding.
- `examples/`: three worked examples (invented, labelled EXAMPLE): an office supplier follow-up, a shop-floor changeover, and a Claude Code 5S.

## The honest limits
- It uses only your numbers. Hours are estimates from your answers until you time the before and after.
- The AI can't see your floor. You walk it and answer, or send photos. It doesn't replace a proper time study.
- Changes to safety (guards, lifting, chemicals, electrical, layout) need your safety officer's OK. Cutting inspection or traceability steps needs your quality owner's OK.
- Follow your company's rules on putting work information and photos into AI tools. Placeholders like "Customer A" or "machine 3" work just as well.

## Help
Reply to your purchase receipt. A human answers, usually within a day.

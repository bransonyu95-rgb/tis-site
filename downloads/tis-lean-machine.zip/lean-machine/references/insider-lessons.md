# Lessons from inside a real factory

These lessons come from improvement work inside a real precision-machining factory: the lead-time analysis, the shared production view, capturing output at the machine, and chasing open promises. They are written as patterns. There are no company, customer or people names, no amounts and no figures from that factory.

Use them in the Lean Plan only when one fits a finding in the user's own hunt. Say which lesson it is and why it fits, in one line. Never present a lesson as the user's own result, and never turn it into a promised number.

## Seeing the waste

**1. Lead time is mostly waiting. Measure the wait, not just the work.**
When we traced lots from the first operation to finished, using the time each lot moved between steps, the machining was a small part of the days. The rest was queues, waiting for the next process, and waiting for material.
*Check in your factory:* take 10 finished lots and split each one's lead time into work and waiting. Look hardest at the biggest wait.
*Fits:* process flow, waiting, inventory.

**2. Split "waiting by plan" from "truly idle" before you blame the floor.**
A lot that waits because the plan says it starts next week isn't the same as a lot that's simply forgotten. When we separated the two, the "idle" number dropped a lot. That was a change of definition, not a gain, and we said so on the page.
*Check:* for every idle lot, ask: planned to wait, waiting for material or a tool, or forgotten? Fix the forgotten ones first. Never report a new definition as an improvement.
*Fits:* process flow, waiting, inventory, reporting.

**3. Standard minutes and real minutes aren't the same number.**
Routing standards say what a step should take. Real run time and transfer times say what it did take. Mixing them makes every load and lead-time figure wrong.
*Check:* for every time in your plan, say which kind it is. Measure before you trust a standard.
*Fits:* shop floor, engineering, planning.

**4. The material kit is its own wait.**
Many lots that looked "stuck at the machine" were really waiting for a complete kit of material or parts. A view that shows kit status next to each lot changed which lots got chased.
*Check:* when a lot waits, is the kit complete? Separate "no kit" from "no machine".
*Fits:* shop floor, process flow, waiting.

## Cleaning up the information

**5. Three departments keeping three spreadsheets of the same work-in-progress is waste twice over.**
Sales, planning and purchasing each kept their own copy. It meant typing the same data three times, and three answers to the same question. One shared view, read by all three, removed both.
*Check:* how many people keep their own version of the same list? Make one master and let the others read it.
*Fits:* office, process flow, over-processing, defects.

**6. Figures typed into a deck go stale. Compute them from the data.**
Slides with hand-typed numbers were right once and wrong later, and wrong in different ways for different customers. Moving them to figures computed from the export fixed this for good.
*Check:* in your monthly deck, which numbers are typed by hand? Each one is a future mistake.
*Fits:* office, engineering, defects.

**7. Check the export before you trust the report.**
One "new" export turned out to be new rows pasted onto an old file. Before trusting a fresh analysis, we re-ran last month's data and checked that it matched last month's report.
*Check:* is your data a fresh pull? Can you reproduce last month's number from last month's data?
*Fits:* office, engineering, defects.

## Capturing at the source

**8. Capture at the machine, with almost no typing.**
Operators reported output with a scan of the machine and three taps. The machine came from the scan, the time from the clock, and the lot was picked from a list. Nobody typed a lot number from memory, and the planner stopped phoning around to ask what ran.
*Check:* how is output reported today, and how much is typed or remembered at the end of the shift?
*Fits:* shop floor, motion, defects, waiting.

**9. Don't change people's habits to suit the tool. Take their sheets as they are.**
The planner kept working in their own plan sheets, and the system read them as they were. Adoption came from not asking anyone to learn a new form.
*Check:* does your fix ask people to do more, or less? Start with what they already use.
*Fits:* all areas, sustain.

## Keeping it lean

**10. Remove what nobody uses, even if you built it.**
A wall display that nobody looked at was taken out. Targets were paused when people stopped trusting the screen. A feature nobody uses is inventory.
*Check:* which reports, boards or columns has nobody looked at this month?
*Fits:* all areas, overproduction, sort.

**11. A problem needs an owner before it needs a system.**
From a list of production problems, a system could answer only some. Most of the rest had no owner in production yet, and no tool fixes that.
*Check:* for every problem on your list, who owns it? Assign the owner first, then the tool.
*Fits:* all areas, sustain, skills not used.

**12. Let scripts do the work that has one right answer. People decide the method.**
Copying, merging, counting and building the deck were scripts, the same every time. Choosing the method (which hours, which machine count, what counts as idle) stayed with the owner.
*Check:* is anyone deciding by hand what a formula could do? Is a tool deciding what a person should?
*Fits:* office, engineering, automation level.

**13. Prove an automation runs before you trust the schedule.**
A pull that worked when someone watched it ran on a schedule for weeks and produced nothing. A trace found it. Until a scheduled job has been checked, the watched run stays the working method.
*Check:* for every scheduled job, when did someone last check that its output exists and is right?
*Fits:* automation, sustain.

**14. Read-only on the system of record.**
Every tool read the ERP's exports and never wrote into the ERP. Changes to the system of record stayed with the people who own it.
*Check:* does your fix write into the ERP? If yes, that's a human click and IT's call.
*Fits:* automation, hard rules.

**15. Most open promises are owed by your side.**
When every follow-up was tracked, far more were owed by our own team than to us. Chasing others felt like the problem, but finishing our own was the bigger job.
*Check:* list your open promises. How many are yours to finish?
*Fits:* office, process flow, waiting.

**16. If you didn't measure it, don't claim it.**
Time saved was never measured on some of this work, so it was never claimed. What was counted was the steps removed and the hand checks removed. That honesty kept the work trusted.
*Check:* in your Lean Plan, which savings are measured and which are estimates? Label them.
*Fits:* all areas, the Lean Plan.

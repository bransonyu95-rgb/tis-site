# 5S for your Claude Code setup

Claude Code gets messy the same way a workbench does. Skills you installed once and never used. A CLAUDE.md that keeps growing and is read in full every session. Memory notes that were true last month. Two skills that do almost the same job, so Claude picks the wrong one. That's waste: slower answers, more tokens, and wrong tools picked.

This routine applies 5S to it. **It looks first, shows a plan, and changes nothing until the user says yes.** It never deletes: things it takes out go to an archive folder with an undo list.

## Step 0: Scan (read-only)
Run `python3 scripts/claude_5s_scan.py <project folder>` from this skill's folder (on Windows: `python scripts\claude_5s_scan.py <project folder>`). `<project folder>` is the folder the user works in most with Claude Code (ask; default: the current folder). The scan always reads the personal setup in the home folder (`~/.claude`) too.

**Proof the no-go files stay untouched:** before any change, record a checksum of `~/.claude/settings.json`, `~/.claude.json` and the project's `.claude/settings*.json` (Mac/Linux: `shasum`; Windows: `certutil -hashfile <file> SHA256`). Never print their contents. Compare again at the end and show "unchanged". It lists:
- the CLAUDE.md files and their size;
- the skills the user made, with how often each was used, when it was last used, and header problems;
- agents and slash commands;
- memory notes and their age;
- MCP server names;
- settings counts;
- disk use.
It never prints a setting value, key or token.
Then read the CLAUDE.md files and the descriptions of the user's own skills yourself, because the scan can't judge meaning.

## The no-go zone (never open, move, edit or show)
- The values in `~/.claude.json`, `.mcp.json`, `settings*.json` env blocks, and anything that looks like a key, token, password or `.env` file.
- `~/.claude/sessions`, `~/.claude/plugins`, policy or remote settings files, and anything IT manages.
- Skills or agents installed by a plugin or a package manager: their maker updates them. Only judge what the user made or copied in themselves.
- Permissions and hooks: you may point out a problem, but the user changes these themselves. Never edit them.
- Conversation history (`~/.claude/projects/*.jsonl`): report its size only. Never delete it.

## The 8 wastes in a Claude Code setup
| Waste | What it looks like |
|---|---|
| Transport | Pasting the same background into every chat instead of one line in CLAUDE.md |
| Inventory | Skills never used; old drafts and test folders; memory notes about finished work |
| Motion | The user can't remember which skill does what; Claude opens many files to find one fact |
| Waiting | Permission prompts on safe read-only commands every session (the user can allow them) |
| Overproduction | Skills that write long reports nobody reads |
| Over-processing | A huge CLAUDE.md read in full every session; the same rule written in three places |
| Defects | Two instructions that contradict; a skill header that doesn't load; a memory note that is no longer true; a file path that no longer exists |
| Skills not used | A task done by hand every week that could be one skill |

## Score each S from 0 to 5 (total out of 25)
**Sort: keep only what is used.**
- Candidates: skills with 0 recorded uses and more than 30 days old, or not used for more than 180 days; test or copy folders; duplicates ("seo" and "seo-old"); folders in the skills folder with no SKILL.md (not a skill: ask, archive if the user agrees); memory notes about finished work. Usage numbers are a hint, never the verdict: always ask.
- Score: 5 = no candidates; 4 = 1 or 2; 3 = 3 to 5; 2 = 6 to 10; 1 = more than 10; 0 = most of the setup.
- Action: move unused items to the archive (step 6). Ask about each one in a short table: keep / archive / not sure. "Not sure" stays.

**Set in order: a place for everything, and easy to find.**
- One naming rule for skills (what it does, in 2 or 3 words, with dashes). The folder name matches the `name:` in the header.
- Every skill description says what it does AND when to use it, with the words the user actually types.
- CLAUDE.md in clear sections: who I am, how I want answers, rules, where things live.
- Score: start at 5 and take off 1 for each kind of problem found (folder and `name:` differ; descriptions with no "use when"; vague or overlapping descriptions; CLAUDE.md with no sections; files in random places). Minimum 0.

**Shine: clean, so problems show.**
- Headers that won't load (for example an unquoted `: ` inside a description), contradictions between CLAUDE.md files, rules that point to files or tools that no longer exist, memory notes that are now wrong, servers that fail to connect.
- Score: 5 = none; take off 1 per broken header, contradiction, dead reference or wrong note, down to 0.

**Standardize: one way, written down.**
- A CLAUDE.md layout (see below), a skill template, and one memory note format.
- Score: 5 = all follow one pattern and the layout is written down; 3 = most do; 1 = few do; 0 = no pattern.

**Sustain: it stays clean.**
- A 10-minute "5S check" once a month, a date written in `waste-log.md`, and a rule in CLAUDE.md: "Before adding a new skill, check whether an existing one already does it."
- Score: 5 = a monthly check with a date, a log and the CLAUDE.md rule; 3 = some of these; 0 = none.
- Always put these two rows in the plan: the CLAUDE.md rule, and the next check date in `waste-log.md`.

Show the table: S | Score | What we found | The one action. Then the total, labelled "from the scan and your answers".

## Step 5: The plan (show it, change nothing yet)
One table: # | What | Where | Action (archive / rename / fix header / rewrite description / merge / trim CLAUDE.md) | Why. Group it by S. Then ask: "Shall I do all of it, some of it (give me the numbers), or none?"

## Step 6: Do it, only what was approved
- First make the archive folder `~/.claude/_5s-archive/<today's date>/` (if it already exists from an earlier run today, add `-2`, `-3`). Items from a project's `.claude` folder go to `<project>/.claude/_5s-archive/<date>/`. Copy every file you will edit into the archive's `edited/` folder BEFORE editing it.
- **Archive, never delete.** Move unused items into the archive folder, keeping their folder names.
- Write `UNDO.md` in the archive folder: one line per change, original path → new path or "edited, original copy here", so the user can put anything back.
- Renames: by default rename the FOLDER to match `name:` (the name is what the user types). Update the `# title` inside the file too. If a slash command, CLAUDE.md or another skill points to the old name, update it or mark it `[CHECK: ...]`.
- Contradictions: show the user both lines side by side and ask which one wins. Remove the other. Note it in UNDO.md.
- Stale facts (a path that no longer exists, a skill name that isn't there): never fix them silently. Mark the line `[CHECK: ...]` and ask the user for the right value.
- CLAUDE.md: keep the user's meaning. Remove repeats, merge rules that say the same thing, move long reference parts into a separate file and add one line pointing to it. Use only the layout sections that have content (no empty headings). Show the before and after word counts. A small file may grow slightly because of headings; that's fine. The goal is no repeats, no contradictions and clear sections.
- Never touch the no-go zone.
- Tell the user to restart Claude Code (or start a new session) so the changes load.

## Step 7: Check it worked
Run the scan again. Show the 5S score before and after, what moved, and the one-line undo instruction ("To put something back, move it from the archive folder to where UNDO.md says"). Log it in `waste-log.md` as: date | Claude Code 5S | hours found: n/a | 5S before → after | what moved or changed | re-check date (one month from today). Show the checksums of the no-go files: unchanged.

## The CLAUDE.md layout (standard)
```
# About me
One or two lines: my job, my industry, the language I prefer.

# How I want answers
Short, plain words, numbered steps. (the user's own preferences)

# Rules
Things Claude must always or never do. One rule per line, no repeats.

# Where things live
Folders and files Claude needs, one line each.

# Details
Long reference material lives in separate files; link them here.
```

## The skill template (standard)
```
---
name: verb-noun (same as the folder name)
description: "What it does, in one sentence. Use when the user says ..., ... or .... Never ...."
---
# Title
What it is for, in 2 lines.
## Steps
## Rules
```
Quote the whole description in double quotes if it contains `: `.

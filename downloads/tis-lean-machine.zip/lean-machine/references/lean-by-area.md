# Lean by area: how to walk it, and what waste looks like there

Read this before the walk. Pick the section for the area the user chose. Use the examples to help the user see waste they've stopped noticing. Never put an example into their map unless they confirm it happens.

The 8 wastes, in plain words (the order spells TIMWOODS, if the user knows it):
1. **Transport:** moving things, parts or files around without adding value.
2. **Inventory:** piles: parts, jobs, emails or files waiting.
3. **Motion:** people walking, reaching, searching, clicking around.
4. **Waiting:** for a machine, a part, a signature, an answer.
5. **Overproduction:** making more, or earlier, than anyone needs.
6. **Over-processing:** doing more than the customer pays for: extra checks, extra reports, extra polish.
7. **Defects:** mistakes, rework, scrap, wrong data.
8. **Skills not used:** people doing work below what they can do, or ideas nobody asks for.

---

## A. Shop floor (a machine, a cell, a line, a store)

**Walk it (gemba):** stand where the work happens for 20 minutes. If the user can't, ask them to go and come back with answers or photos.
- What comes in, what goes out, and what does the customer pay for here?
- Follow one part from the moment it arrives to the moment it leaves. How long did it take? How long was it actually being worked on?
- Changeover: from the last good part of job A to the first good part of job B, how long? What happens in that time? Which of those steps could be done while the machine still runs (external) instead of while it's stopped (internal)?
- Where do operators walk to? Count the trips for tools, gauges, drawings, material, the supervisor.
- Where does work pile up between steps? How many pieces or jobs, how many hours of work?
- What gets reworked or scrapped, how often, and where is it found?

**What waste looks like here:**
| Waste | Shop-floor example |
|---|---|
| Transport | Parts carried to a far inspection room and back |
| Inventory | WIP racks full between machines; material issued days before it's needed |
| Motion | Walking to the tool crib for every changeover; searching for the right gauge |
| Waiting | Machine stopped for first-article approval; operator waiting for the crane or forklift |
| Overproduction | Running the whole batch "while it's set up" when only half is ordered |
| Over-processing | Finishing a surface nobody asked for; 100% inspection on a stable process |
| Defects | Setup scrap; wrong revision drawing used |
| Skills not used | Operators who know the fix but are never asked |

**5S on the floor:** red-tag what hasn't been used in 30 days; shadow boards and labels so a missing tool is obvious; clean to inspect (leaks, chips, loose bolts seen while cleaning); a one-page standard with a photo of "how it should look"; a 5-minute end-of-shift check with an owner. **Safety first:** any change to guards, lifting, chemicals, electrical or layout needs the safety officer's OK.

---

## B. Engineering (drawings, programs, fixtures, changes, quality records)

**Walk it:** follow one engineering change, one new part or one customer drawing from arrival to release on the floor.
- Where does the latest drawing or program live? How does someone know it's the latest?
- How long from customer change request to the floor running the new revision? How much of that is waiting for review or approval?
- How many places hold the same information (drawing, ERP, program header, inspection plan, a personal folder)?
- What gets asked again and again ("which revision?", "where's the program?", "who approved this?")?
- What do new engineers struggle to find?

**What waste looks like here:**
| Waste | Engineering example |
|---|---|
| Transport | Drawings emailed, printed, scanned, re-filed |
| Inventory | A queue of change requests; old revisions kept "just in case" next to the live one |
| Motion | Searching three folders for the right program; opening ten files to find one fixture number |
| Waiting | Changes waiting for one person's signature; floor waiting for a released program |
| Overproduction | Full reports nobody reads; drawings detailed beyond what the process needs |
| Over-processing | Retyping the same data into the ERP, the inspection plan and the traveller |
| Defects | Wrong revision machined; a program edited on the machine and never saved back |
| Skills not used | Senior engineers doing filing; nobody writing down what the expert knows |

**5S in engineering:** archive superseded revisions out of the live folder; one naming rule (part number, revision, date); one master location per document type; a change checklist; a monthly check that the live folder holds live files only.

---

## C. Process flow (an order, a request or a job across departments)

**Walk it:** pick one real recent order and trace it from the first contact to cash. Draw the steps in a line.
For each step ask: who does it, how long the work takes (work time), and how long it sits before the next step (wait time). Mark every hand-over between people or departments.

Then add it up: **total lead time** = all work + all waiting. **Work share** = work time ÷ lead time. In most factories the work share is under 10%: the job spends most of its life waiting. Show it plainly: "2 hours of real work, 9 days of waiting."

Typical flow: enquiry → quote → PO → order entry → planning → material → production → inspection → packing → shipping → invoice → payment.

**What waste looks like here:**
| Waste | Process-flow example |
|---|---|
| Transport | Hand-overs that go through a person who adds nothing |
| Inventory | Orders waiting in someone's inbox; jobs released early that sit on the floor |
| Motion | Walking paperwork for signatures; chasing status by phone |
| Waiting | Quote waits for costing; PO waits for credit check; shipment waits for documents |
| Overproduction | Planning far ahead of real demand, then re-planning |
| Over-processing | Two approvals for the same thing; re-entering the PO into three systems |
| Defects | Wrong delivery date promised; wrong price on the invoice |
| Skills not used | One person is the only one who knows the flow end to end |

Look hardest at the biggest WAIT, not the biggest step. That's usually where days are lost.

---

## D. Office (reports, data entry, chasing, documents)

**Walk it:** one real task, trigger to hand-over, step by step: who, which system or file, what is copied from where to where, minutes each time, times a month, who waits, what is redone.

**What waste looks like here:**
| Waste | Office example |
|---|---|
| Transport | Exporting, emailing and re-importing the same data |
| Inventory | Unread emails; reports piling up; half-done files |
| Motion | Clicking through five screens; searching for the latest file |
| Waiting | For an input, a signature, someone back from leave |
| Overproduction | A report nobody reads; columns nobody uses |
| Over-processing | Reformatting the same numbers for each manager |
| Defects | Typing errors; formula errors; the wrong version sent |
| Skills not used | Experienced staff copy-pasting all day |

**5S in the office:** see Part 5 of the skill: files, folders, reports and templates.

---

## The 5 Whys (finding the real cause)
Take the biggest waste. Ask "why does this happen?" Then ask "why?" of the answer. Usually 3 to 5 times. Stop when you reach something a person can change: a rule, a layout, a template, an owner, a training gap. Never stop at "the operator was careless": ask why the process let that happen. Check the cause with the user before acting on it.

## The one-page Lean Plan (an A3 on one page)
1. **The problem**, in one line with a number ("Changeover takes 95 minutes; we lose about 19 machine hours a month").
2. **Now:** the map or walk summary.
3. **Waste found**, with hours or money per month from the user's numbers.
4. **Real cause** (5 Whys).
5. **Target:** a number and a date.
6. **Actions:** what, who, by when (cut first, then standardize, then automate).
7. **Check:** the date to re-measure, and who checks.

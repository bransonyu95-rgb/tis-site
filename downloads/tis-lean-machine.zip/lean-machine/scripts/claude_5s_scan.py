#!/usr/bin/env python3
"""Claude Code 5S scan: READ-ONLY inventory of a Claude Code setup.

Part of Agentic AI: The Lean Machine (The Industrial Scribe). It looks, it never changes
anything. It never prints the value of a setting, token, key, env variable
or MCP server config: only names, counts, sizes and dates.

Usage:  python3 claude_5s_scan.py [project_folder]  > scan.md
Works on Mac, Windows and Linux with plain Python 3 (no installs).
"""
import json, os, re, sys, time
from pathlib import Path

NOW = time.time()
DAY = 86400
HOME = Path.home()
CLAUDE = HOME / ".claude"
PROJECT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
SECRET_NAMES = re.compile(r"(^\.env.*|secret|token|credential|password|apikey|api_key)", re.I)

def days_old(p):
    try: return int((NOW - p.stat().st_mtime) / DAY)
    except OSError: return None

def read(p):
    try: return p.read_text(encoding="utf-8", errors="replace")
    except OSError: return ""

def header_check(text):
    """Check a SKILL.md / agent header without a YAML library."""
    m = re.match(r"\A---\r?\n(.*?)\r?\n---", text, re.S)
    if not m: return None, None, ["no header (--- block) at the top"]
    fm, issues, name, desc = m.group(1), [], None, None
    lines = fm.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("name:"): name = line[5:].strip().strip('"\'')
        if line.startswith("description:"):
            desc = line[12:].strip()
            if desc in ("", ">", "|", ">-", "|-", ">+", "|+"):
                block = []
                for nxt in lines[i+1:]:
                    if nxt.startswith((" ", "\t")) or not nxt.strip(): block.append(nxt.strip())
                    else: break
                desc = " ".join(b for b in block if b)
            elif desc[0] not in "\"'" and ": " in desc:
                issues.append("description has an unquoted ': ' (header may not load)")
            desc = desc.strip('"\'')
    if not name: issues.append("no name")
    if not desc: issues.append("no description")
    elif len(desc) < 40: issues.append("description very short: Claude may not know when to use it")
    elif len(desc) > 1024: issues.append("description over 1024 characters")
    return name, desc, issues

def dir_size(p):
    total = 0
    for root, _, files in os.walk(p):
        for f in files:
            try: total += os.path.getsize(os.path.join(root, f))
            except OSError: pass
    return total

def mb(n): return f"{n/1_048_576:.1f} MB"

out = []
P = out.append
P(f"# Claude Code 5S scan ({time.strftime('%Y-%m-%d')})")
P("Read-only. Nothing was changed. Values of settings, keys and tokens are never shown.\n")

# Usage data Claude Code keeps (names, counts and dates only)
usage, mcp_names = {}, []
cj = HOME / ".claude.json"
if cj.exists():
    try:
        d = json.loads(read(cj))
        usage = d.get("skillUsage") or {}
        mcp_names = sorted((d.get("mcpServers") or {}).keys())
    except ValueError:
        P("- Note: ~/.claude.json could not be read as JSON (left alone).")

# 1. Instructions loaded every session
P("## 1. Instruction files (CLAUDE.md)")
P("| File | Lines | Words | Days since edit |\n|---|---|---|---|")
for f in [CLAUDE / "CLAUDE.md", PROJECT / "CLAUDE.md", PROJECT / ".claude" / "CLAUDE.md", PROJECT / "CLAUDE.local.md"]:
    if f.exists():
        t = read(f)
        P(f"| {f} | {t.count(chr(10))+1} | {len(t.split())} | {days_old(f)} |")
P("")

# 2. Skills
def skills_in(base, scope):
    rows = []
    if not base.exists(): return rows
    for sk in sorted(base.iterdir()):
        if not sk.is_dir() or sk.name.startswith((".", "_")): continue
        f = sk / "SKILL.md"
        if not f.exists():
            rows.append((scope, sk.name, None, ["folder has no SKILL.md"], days_old(sk), None)); continue
        name, desc, issues = header_check(read(f))
        if name and name != sk.name: issues.append(f"folder '{sk.name}' but name '{name}'")
        u = usage.get(name or sk.name) or usage.get(sk.name) or {}
        last = u.get("lastUsedAt")
        last_days = int((NOW - last/1000) / DAY) if last else None
        rows.append((scope, sk.name, u.get("usageCount", 0), issues, days_old(f), last_days))
    return rows

rows = skills_in(CLAUDE / "skills", "personal") + skills_in(PROJECT / ".claude" / "skills", "project")
P("## 2. Skills you made (plugin skills are left out: their maker updates them)")
P("| Scope | Skill | Times used | Last used (days ago) | Days since edit | Issues |\n|---|---|---|---|---|---|")
for scope, n, cnt, issues, edited, last in rows:
    P(f"| {scope} | {n} | {cnt if cnt is not None else '?'} | {last if last is not None else 'never recorded'} | {edited} | {'; '.join(issues) or '-'} |")
seen = {}
for r in rows: seen.setdefault(r[1].lower(), []).append(r[0])
dups = [k for k, v in seen.items() if len(v) > 1]
if dups: P(f"\nSame skill name in more than one place: {', '.join(dups)}")
if not usage: P("\nNote: this Claude Code version keeps no usage record, so 'times used' is unknown. Ask the user instead.")
P("")

# 3. Agents and commands
for label, sub in [("Agents", "agents"), ("Slash commands", "commands")]:
    items = []
    for base in [CLAUDE / sub, PROJECT / ".claude" / sub]:
        if base.exists(): items += [p for p in base.rglob("*.md")]
    P(f"## 3{'a' if label == 'Agents' else 'b'}. {label}: {len(items)}")
    for p in items:
        _, _, issues = header_check(read(p))
        P(f"- {p.name} ({days_old(p)} days since edit){' - ' + '; '.join(issues) if issues and label=='Agents' else ''}")
    P("")

# 4. Memory notes
P("## 4. Memory notes")
mem_files = list((CLAUDE / "projects").glob("*/memory/*.md")) if (CLAUDE / "projects").exists() else []
old = [p for p in mem_files if (days_old(p) or 0) > 90]
P(f"- {len(mem_files)} memory files; {len(old)} not edited for 90+ days (check they are still true).")
for idx in (CLAUDE / "projects").glob("*/memory/MEMORY.md") if (CLAUDE / "projects").exists() else []:
    t = read(idx)
    links = re.findall(r"\]\(([^)]+\.md)\)", t)
    missing = [l for l in links if not (idx.parent / l).exists()]
    P(f"- {idx.parent.parent.name}: index has {len(links)} entries, {t.count(chr(10))+1} lines" + (f"; points to missing files: {', '.join(missing)}" if missing else ""))
P("")

# 5. Connections (names only)
P("## 5. MCP servers (names only, config never shown)")
P("- User-level: " + (", ".join(mcp_names) if mcp_names else "none listed"))
pm = PROJECT / ".mcp.json"
if pm.exists():
    try: P("- This project: " + ", ".join(sorted((json.loads(read(pm)).get("mcpServers") or {}).keys())))
    except ValueError: P("- This project: .mcp.json could not be read (left alone)")
P("")

# 6. Settings (shape only)
P("## 6. Settings files (counts only, values never shown)")
for f in [CLAUDE / "settings.json", PROJECT / ".claude" / "settings.json", PROJECT / ".claude" / "settings.local.json"]:
    if f.exists():
        try:
            d = json.loads(read(f)); perm = d.get("permissions") or {}
            P(f"- {f}: {len(perm.get('allow') or [])} allow rules, {len(perm.get('deny') or [])} deny rules, hooks on {len(d.get('hooks') or {})} events")
        except ValueError:
            P(f"- {f}: could not be read as JSON (left alone)")
P("")

# 7. Disk
P("## 7. Disk")
for sub in ["projects", "file-history", "debug", "shell-snapshots", "downloads"]:
    p = CLAUDE / sub
    if p.exists(): P(f"- ~/.claude/{sub}: {mb(dir_size(p))}")
P("")

# 8. Sensitive files: flagged by name, never opened, never moved
SKIP = {".venv", "venv", "node_modules", "site-packages", ".git"}
flag = []
for base in [CLAUDE / "skills", CLAUDE / "agents", CLAUDE / "commands", PROJECT / ".claude"]:
    if not base.exists(): continue
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in SKIP]
        flag += [os.path.join(root, f) for f in files if SECRET_NAMES.search(f)]
P("## 8. No-go zone (never opened, moved or shown)")
P("- Always off limits: ~/.claude.json values, ~/.claude/sessions, ~/.claude/plugins, policy and remote settings files, anything IT manages.")
P("- Files inside your skills or agents that look like secrets: " + (", ".join(flag[:20]) if flag else "none found"))
print("\n".join(out))
